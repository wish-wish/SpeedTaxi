System.register(["cc", "code-quality:cr", "../data/CustomEventListener.js", "../data/Constants.js", "../data/PoolMgr.js"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Component, Prefab, ParticleUtils, ParticleSystemComponent, instantiate, CustomEventListener, Constants, PoolMgr, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp, _crd, ccclass, property, EffectMgr;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfCustomEventListener(extras) {
    _reporterNs.report("CustomEventListener", "../data/CustomEventListener", _context.meta, extras);
  }

  function _reportPossibleCrUseOfConstants(extras) {
    _reporterNs.report("Constants", "../data/Constants", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPoolMgr(extras) {
    _reporterNs.report("PoolMgr", "../data/PoolMgr", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _dec2: void 0,
    _dec3: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _descriptor2: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Prefab = _cc.Prefab;
      ParticleUtils = _cc.ParticleUtils;
      ParticleSystemComponent = _cc.ParticleSystemComponent;
      instantiate = _cc.instantiate;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_dataCustomEventListenerJs) {
      CustomEventListener = _dataCustomEventListenerJs.CustomEventListener;
    }, function (_dataConstantsJs) {
      Constants = _dataConstantsJs.Constants;
    }, function (_dataPoolMgrJs) {
      PoolMgr = _dataPoolMgrJs.PoolMgr;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "0a3b3vl2r1AXKVUYNQFcHIR", "EffectMgr", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("EffectMgr", EffectMgr = (_dec = ccclass('EffectMgr'), _dec2 = property({
        type: Prefab
      }), _dec3 = property({
        type: Prefab
      }), _dec(_class = (_class2 = (_temp = /*#__PURE__*/function (_Component) {
        _inherits(EffectMgr, _Component);

        function EffectMgr() {
          var _getPrototypeOf2;

          var _this;

          _classCallCheck(this, EffectMgr);

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(EffectMgr)).call.apply(_getPrototypeOf2, [this].concat(args)));

          _initializerDefineProperty(_this, "breakTrail", _descriptor, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "coin", _descriptor2, _assertThisInitialized(_this));

          _this.followTarget = null;
          _this.currBreaking = null;
          return _this;
        }

        _createClass(EffectMgr, [{
          key: "start",
          value: function start() {
            // Your initialization goes here.
            (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
              error: Error()
            }), CustomEventListener) : CustomEventListener).on((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).EventName.STARTBREAKING, this.startBreaking, this);
            (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
              error: Error()
            }), CustomEventListener) : CustomEventListener).on((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).EventName.ENDBREAKING, this.endBreaking, this);
            (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
              error: Error()
            }), CustomEventListener) : CustomEventListener).on((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).EventName.SHOWCOIN, this.showCoin, this);
          }
        }, {
          key: "update",
          value: function update(dt) {
            if (this.currBreaking && this.followTarget) {
              this.currBreaking.setWorldPosition(this.followTarget.worldPosition);
            }
          }
        }, {
          key: "startBreaking",
          value: function startBreaking() {
            var follow = this.followTarget = arguments.length <= 0 ? undefined : arguments[0];
            this.currBreaking = (_crd && PoolMgr === void 0 ? (_reportPossibleCrUseOfPoolMgr({
              error: Error()
            }), PoolMgr) : PoolMgr).getNode(this.breakTrail, this.node);
            this.currBreaking.setWorldPosition(follow.worldPosition);
            ParticleUtils.play(this.currBreaking);
          }
        }, {
          key: "endBreaking",
          value: function endBreaking() {
            var currBreaking = this.currBreaking;
            ParticleUtils.stop(currBreaking);
            this.unscheduleAllCallbacks();
            this.scheduleOnce(function () {
              (_crd && PoolMgr === void 0 ? (_reportPossibleCrUseOfPoolMgr({
                error: Error()
              }), PoolMgr) : PoolMgr).setNode(currBreaking);
            }, 2);
            this.currBreaking = null;
            this.followTarget = null;
          }
        }, {
          key: "showCoin",
          value: function showCoin() {
            var pos = arguments.length <= 0 ? undefined : arguments[0];

            if (!this.coinparticle) {
              var coin = instantiate(this.coin);
              coin.setParent(this.node);
              this.coinparticle = coin.getComponent(ParticleSystemComponent);
            }

            this.coinparticle.node.setWorldPosition(pos);
            this.coinparticle.play();
          } // update (deltaTime: number) {
          //     // Your update function goes here.
          // }

        }]);

        return EffectMgr;
      }(Component), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "breakTrail", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "coin", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ3JlYXRvci9TcGVlZFRheGkvYXNzZXRzL3NjcmlwdC9nYW1lL0VmZmVjdE1nci50cyJdLCJuYW1lcyI6WyJfZGVjb3JhdG9yIiwiQ29tcG9uZW50IiwiUHJlZmFiIiwiUGFydGljbGVVdGlscyIsIlBhcnRpY2xlU3lzdGVtQ29tcG9uZW50IiwiaW5zdGFudGlhdGUiLCJDdXN0b21FdmVudExpc3RlbmVyIiwiQ29uc3RhbnRzIiwiUG9vbE1nciIsImNjY2xhc3MiLCJwcm9wZXJ0eSIsIkVmZmVjdE1nciIsInR5cGUiLCJmb2xsb3dUYXJnZXQiLCJjdXJyQnJlYWtpbmciLCJvbiIsIkV2ZW50TmFtZSIsIlNUQVJUQlJFQUtJTkciLCJzdGFydEJyZWFraW5nIiwiRU5EQlJFQUtJTkciLCJlbmRCcmVha2luZyIsIlNIT1dDT0lOIiwic2hvd0NvaW4iLCJkdCIsInNldFdvcmxkUG9zaXRpb24iLCJ3b3JsZFBvc2l0aW9uIiwiZm9sbG93IiwiZ2V0Tm9kZSIsImJyZWFrVHJhaWwiLCJub2RlIiwicGxheSIsInN0b3AiLCJ1bnNjaGVkdWxlQWxsQ2FsbGJhY2tzIiwic2NoZWR1bGVPbmNlIiwic2V0Tm9kZSIsInBvcyIsImNvaW5wYXJ0aWNsZSIsImNvaW4iLCJzZXRQYXJlbnQiLCJnZXRDb21wb25lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBU0EsTUFBQUEsVSxPQUFBQSxVO0FBQVlDLE1BQUFBLFMsT0FBQUEsUztBQUFpQkMsTUFBQUEsTSxPQUFBQSxNO0FBQVFDLE1BQUFBLGEsT0FBQUEsYTtBQUFlQyxNQUFBQSx1QixPQUFBQSx1QjtBQUF5QkMsTUFBQUEsVyxPQUFBQSxXOzs7O0FBQzdFQyxNQUFBQSxtQiw4QkFBQUEsbUI7O0FBQ0FDLE1BQUFBLFMsb0JBQUFBLFM7O0FBQ0FDLE1BQUFBLE8sa0JBQUFBLE87Ozs7OztBQUNEQyxNQUFBQSxPLEdBQXNCVCxVLENBQXRCUyxPO0FBQVNDLE1BQUFBLFEsR0FBYVYsVSxDQUFiVSxROzsyQkFHSkMsUyxXQURaRixPQUFPLENBQUMsV0FBRCxDLFVBRUhDLFFBQVEsQ0FBQztBQUNORSxRQUFBQSxJQUFJLEVBQUNWO0FBREMsT0FBRCxDLFVBS1JRLFFBQVEsQ0FBQztBQUNORSxRQUFBQSxJQUFJLEVBQUNWO0FBREMsT0FBRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnQkFLRFcsWSxHQUFvQixJO2dCQUNwQkMsWSxHQUFtQixJOzs7Ozs7a0NBR1g7QUFDWjtBQUNBO0FBQUE7QUFBQSw0REFBb0JDLEVBQXBCLENBQXVCO0FBQUE7QUFBQSx3Q0FBVUMsU0FBVixDQUFvQkMsYUFBM0MsRUFBeUQsS0FBS0MsYUFBOUQsRUFBNEUsSUFBNUU7QUFDQTtBQUFBO0FBQUEsNERBQW9CSCxFQUFwQixDQUF1QjtBQUFBO0FBQUEsd0NBQVVDLFNBQVYsQ0FBb0JHLFdBQTNDLEVBQXVELEtBQUtDLFdBQTVELEVBQXdFLElBQXhFO0FBQ0E7QUFBQTtBQUFBLDREQUFvQkwsRUFBcEIsQ0FBdUI7QUFBQTtBQUFBLHdDQUFVQyxTQUFWLENBQW9CSyxRQUEzQyxFQUFvRCxLQUFLQyxRQUF6RCxFQUFrRSxJQUFsRTtBQUNIOzs7aUNBRWFDLEUsRUFBVTtBQUNwQixnQkFBRyxLQUFLVCxZQUFMLElBQW1CLEtBQUtELFlBQTNCLEVBQXdDO0FBQ3BDLG1CQUFLQyxZQUFMLENBQWtCVSxnQkFBbEIsQ0FBbUMsS0FBS1gsWUFBTCxDQUFrQlksYUFBckQ7QUFDSDtBQUNKOzs7MENBR0Q7QUFDSSxnQkFBTUMsTUFBTSxHQUFHLEtBQUtiLFlBQUwsbURBQWY7QUFDQSxpQkFBS0MsWUFBTCxHQUFvQjtBQUFBO0FBQUEsb0NBQVFhLE9BQVIsQ0FBZ0IsS0FBS0MsVUFBckIsRUFBZ0MsS0FBS0MsSUFBckMsQ0FBcEI7QUFDQSxpQkFBS2YsWUFBTCxDQUFrQlUsZ0JBQWxCLENBQW1DRSxNQUFNLENBQUNELGFBQTFDO0FBQ0F0QixZQUFBQSxhQUFhLENBQUMyQixJQUFkLENBQW1CLEtBQUtoQixZQUF4QjtBQUNIOzs7d0NBR0Q7QUFDSSxnQkFBTUEsWUFBWSxHQUFDLEtBQUtBLFlBQXhCO0FBQ0FYLFlBQUFBLGFBQWEsQ0FBQzRCLElBQWQsQ0FBbUJqQixZQUFuQjtBQUNBLGlCQUFLa0Isc0JBQUw7QUFDQSxpQkFBS0MsWUFBTCxDQUFrQixZQUFJO0FBQ2xCO0FBQUE7QUFBQSxzQ0FBUUMsT0FBUixDQUFnQnBCLFlBQWhCO0FBQ0gsYUFGRCxFQUVFLENBRkY7QUFHQSxpQkFBS0EsWUFBTCxHQUFrQixJQUFsQjtBQUNBLGlCQUFLRCxZQUFMLEdBQWtCLElBQWxCO0FBQ0g7OztxQ0FHRDtBQUNJLGdCQUFNc0IsR0FBRyxtREFBVDs7QUFDQSxnQkFBRyxDQUFDLEtBQUtDLFlBQVQsRUFBc0I7QUFDbEIsa0JBQU1DLElBQUksR0FBR2hDLFdBQVcsQ0FBQyxLQUFLZ0MsSUFBTixDQUF4QjtBQUNBQSxjQUFBQSxJQUFJLENBQUNDLFNBQUwsQ0FBZSxLQUFLVCxJQUFwQjtBQUNBLG1CQUFLTyxZQUFMLEdBQWtCQyxJQUFJLENBQUNFLFlBQUwsQ0FBa0JuQyx1QkFBbEIsQ0FBbEI7QUFDSDs7QUFDRCxpQkFBS2dDLFlBQUwsQ0FBa0JQLElBQWxCLENBQXVCTCxnQkFBdkIsQ0FBd0NXLEdBQXhDO0FBQ0EsaUJBQUtDLFlBQUwsQ0FBa0JOLElBQWxCO0FBQ0gsVyxDQUVEO0FBQ0E7QUFDQTs7Ozs7UUE5RDJCN0IsUzs7Ozs7aUJBSVAsSTs7Ozs7OztpQkFLTixJIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgX2RlY29yYXRvciwgQ29tcG9uZW50LCBOb2RlLCBQcmVmYWIsIFBhcnRpY2xlVXRpbHMsIFBhcnRpY2xlU3lzdGVtQ29tcG9uZW50LCBpbnN0YW50aWF0ZSB9IGZyb20gJ2NjJztcclxuaW1wb3J0IHsgQ3VzdG9tRXZlbnRMaXN0ZW5lciB9IGZyb20gJy4uL2RhdGEvQ3VzdG9tRXZlbnRMaXN0ZW5lcic7XHJcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4uL2RhdGEvQ29uc3RhbnRzJztcclxuaW1wb3J0IHsgUG9vbE1nciB9IGZyb20gJy4uL2RhdGEvUG9vbE1ncic7XHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IF9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzcygnRWZmZWN0TWdyJylcclxuZXhwb3J0IGNsYXNzIEVmZmVjdE1nciBleHRlbmRzIENvbXBvbmVudCB7XHJcbiAgICBAcHJvcGVydHkoe1xyXG4gICAgICAgIHR5cGU6UHJlZmFiXHJcbiAgICB9KVxyXG4gICAgYnJlYWtUcmFpbDpQcmVmYWIgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7XHJcbiAgICAgICAgdHlwZTpQcmVmYWJcclxuICAgIH0pXHJcbiAgICBjb2luOlByZWZhYiA9IG51bGw7XHJcblxyXG4gICAgcHJpdmF0ZSBmb2xsb3dUYXJnZXQ6Tm9kZSA9IG51bGw7XHJcbiAgICBwcml2YXRlIGN1cnJCcmVha2luZzpOb2RlPSBudWxsO1xyXG4gICAgcHJpdmF0ZSBjb2lucGFydGljbGU6UGFydGljbGVTeXN0ZW1Db21wb25lbnQ7XHJcblxyXG4gICAgcHVibGljIHN0YXJ0ICgpIHtcclxuICAgICAgICAvLyBZb3VyIGluaXRpYWxpemF0aW9uIGdvZXMgaGVyZS5cclxuICAgICAgICBDdXN0b21FdmVudExpc3RlbmVyLm9uKENvbnN0YW50cy5FdmVudE5hbWUuU1RBUlRCUkVBS0lORyx0aGlzLnN0YXJ0QnJlYWtpbmcsdGhpcyk7XHJcbiAgICAgICAgQ3VzdG9tRXZlbnRMaXN0ZW5lci5vbihDb25zdGFudHMuRXZlbnROYW1lLkVOREJSRUFLSU5HLHRoaXMuZW5kQnJlYWtpbmcsdGhpcyk7XHJcbiAgICAgICAgQ3VzdG9tRXZlbnRMaXN0ZW5lci5vbihDb25zdGFudHMuRXZlbnROYW1lLlNIT1dDT0lOLHRoaXMuc2hvd0NvaW4sdGhpcyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHVwZGF0ZShkdDpudW1iZXIpe1xyXG4gICAgICAgIGlmKHRoaXMuY3VyckJyZWFraW5nJiZ0aGlzLmZvbGxvd1RhcmdldCl7XHJcbiAgICAgICAgICAgIHRoaXMuY3VyckJyZWFraW5nLnNldFdvcmxkUG9zaXRpb24odGhpcy5mb2xsb3dUYXJnZXQud29ybGRQb3NpdGlvbilcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBzdGFydEJyZWFraW5nKC4uLmFyZ3M6YW55W10pXHJcbiAgICB7XHJcbiAgICAgICAgY29uc3QgZm9sbG93ID0gdGhpcy5mb2xsb3dUYXJnZXQgPSBhcmdzWzBdO1xyXG4gICAgICAgIHRoaXMuY3VyckJyZWFraW5nID0gUG9vbE1nci5nZXROb2RlKHRoaXMuYnJlYWtUcmFpbCx0aGlzLm5vZGUpO1xyXG4gICAgICAgIHRoaXMuY3VyckJyZWFraW5nLnNldFdvcmxkUG9zaXRpb24oZm9sbG93LndvcmxkUG9zaXRpb24pO1xyXG4gICAgICAgIFBhcnRpY2xlVXRpbHMucGxheSh0aGlzLmN1cnJCcmVha2luZyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBlbmRCcmVha2luZygpXHJcbiAgICB7XHJcbiAgICAgICAgY29uc3QgY3VyckJyZWFraW5nPXRoaXMuY3VyckJyZWFraW5nO1xyXG4gICAgICAgIFBhcnRpY2xlVXRpbHMuc3RvcChjdXJyQnJlYWtpbmcpO1xyXG4gICAgICAgIHRoaXMudW5zY2hlZHVsZUFsbENhbGxiYWNrcygpO1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKCgpPT57XHJcbiAgICAgICAgICAgIFBvb2xNZ3Iuc2V0Tm9kZShjdXJyQnJlYWtpbmcpO1xyXG4gICAgICAgIH0sMilcclxuICAgICAgICB0aGlzLmN1cnJCcmVha2luZz1udWxsO1xyXG4gICAgICAgIHRoaXMuZm9sbG93VGFyZ2V0PW51bGw7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBzaG93Q29pbiguLi5hcmdzOmFueVtdKVxyXG4gICAge1xyXG4gICAgICAgIGNvbnN0IHBvcz1hcmdzWzBdO1xyXG4gICAgICAgIGlmKCF0aGlzLmNvaW5wYXJ0aWNsZSl7XHJcbiAgICAgICAgICAgIGNvbnN0IGNvaW4gPSBpbnN0YW50aWF0ZSh0aGlzLmNvaW4pIGFzIE5vZGU7XHJcbiAgICAgICAgICAgIGNvaW4uc2V0UGFyZW50KHRoaXMubm9kZSk7XHJcbiAgICAgICAgICAgIHRoaXMuY29pbnBhcnRpY2xlPWNvaW4uZ2V0Q29tcG9uZW50KFBhcnRpY2xlU3lzdGVtQ29tcG9uZW50KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5jb2lucGFydGljbGUubm9kZS5zZXRXb3JsZFBvc2l0aW9uKHBvcyk7XHJcbiAgICAgICAgdGhpcy5jb2lucGFydGljbGUucGxheSgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZGVsdGFUaW1lOiBudW1iZXIpIHtcclxuICAgIC8vICAgICAvLyBZb3VyIHVwZGF0ZSBmdW5jdGlvbiBnb2VzIGhlcmUuXHJcbiAgICAvLyB9XHJcbn1cclxuIl19