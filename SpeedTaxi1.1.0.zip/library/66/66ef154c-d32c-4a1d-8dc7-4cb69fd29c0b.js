System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, Node, Vec3, Enum, macro, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _class3, _temp, _crd, ccclass, property, ROAD_POINT_TYPE, ROAD_MOVE_TYPE, RoadPoint;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  _export({
    _dec: void 0,
    _dec2: void 0,
    _dec3: void 0,
    _dec4: void 0,
    _dec5: void 0,
    _dec6: void 0,
    _dec7: void 0,
    _dec8: void 0,
    _dec9: void 0,
    _dec10: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _descriptor2: void 0,
    _descriptor3: void 0,
    _descriptor4: void 0,
    _descriptor5: void 0,
    _descriptor6: void 0,
    _descriptor7: void 0,
    _descriptor8: void 0,
    _descriptor9: void 0,
    _class3: void 0,
    _temp: void 0,
    ROAD_POINT_TYPE: void 0,
    ROAD_MOVE_TYPE: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Vec3 = _cc.Vec3;
      Enum = _cc.Enum;
      macro = _cc.macro;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "66ef1VM0yxKHY3HTLaf0pwL", "RoadPoint", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      (function (ROAD_POINT_TYPE) {
        ROAD_POINT_TYPE[ROAD_POINT_TYPE["NORMAL"] = 1] = "NORMAL";
        ROAD_POINT_TYPE[ROAD_POINT_TYPE["START"] = 2] = "START";
        ROAD_POINT_TYPE[ROAD_POINT_TYPE["GREETING"] = 3] = "GREETING";
        ROAD_POINT_TYPE[ROAD_POINT_TYPE["GOODBYE"] = 4] = "GOODBYE";
        ROAD_POINT_TYPE[ROAD_POINT_TYPE["END"] = 5] = "END";
        ROAD_POINT_TYPE[ROAD_POINT_TYPE["AI_START"] = 6] = "AI_START";
      })(ROAD_POINT_TYPE || (ROAD_POINT_TYPE = {}));

      Enum(ROAD_POINT_TYPE);

      (function (ROAD_MOVE_TYPE) {
        ROAD_MOVE_TYPE[ROAD_MOVE_TYPE["LINE"] = 1] = "LINE";
        ROAD_MOVE_TYPE[ROAD_MOVE_TYPE["CURVE"] = 2] = "CURVE";
      })(ROAD_MOVE_TYPE || (ROAD_MOVE_TYPE = {}));

      Enum(ROAD_MOVE_TYPE);

      _export("RoadPoint", RoadPoint = (_dec = ccclass('RoadPoint'), _dec2 = property({
        type: ROAD_POINT_TYPE,
        displayOrder: 1
      }), _dec3 = property({
        type: Node,
        displayOrder: 2,
        visible: function visible() {
          return true; //this.type !==ROAD_POINT_TYPE.END;
        }
      }), _dec4 = property({
        type: ROAD_MOVE_TYPE,
        displayOrder: 3,
        visible: function visible() {
          return this.type !== ROAD_POINT_TYPE.END;
        }
      }), _dec5 = property({
        displayOrder: 4,
        visible: function visible() {
          return this.type !== ROAD_POINT_TYPE.END && this.moveType === ROAD_MOVE_TYPE.CURVE;
        }
      }), _dec6 = property({
        type: Vec3,
        visible: function visible() {
          return this.type === ROAD_POINT_TYPE.GOODBYE || this.type === ROAD_POINT_TYPE.GREETING;
        }
      }), _dec7 = property({
        visible: function visible() {
          return this.type === ROAD_POINT_TYPE.AI_START;
        }
      }), _dec8 = property({
        visible: function visible() {
          return this.type === ROAD_POINT_TYPE.AI_START;
        }
      }), _dec9 = property({
        visible: function visible() {
          return this.type === ROAD_POINT_TYPE.AI_START;
        }
      }), _dec10 = property({
        visible: function visible() {
          return this.type === ROAD_POINT_TYPE.AI_START;
        }
      }), _dec(_class = (_class2 = (_temp = _class3 = /*#__PURE__*/function (_Component) {
        _inherits(RoadPoint, _Component);

        function RoadPoint() {
          var _getPrototypeOf2;

          var _this;

          _classCallCheck(this, RoadPoint);

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(RoadPoint)).call.apply(_getPrototypeOf2, [this].concat(args)));

          _initializerDefineProperty(_this, "type", _descriptor, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "nextStation", _descriptor2, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "moveType", _descriptor3, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "clockwise", _descriptor4, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "direction", _descriptor5, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "interval", _descriptor6, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "delayTime", _descriptor7, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "speed", _descriptor8, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "cars", _descriptor9, _assertThisInitialized(_this));

          _this.arrCars = [];
          _this.cd = null;
          return _this;
        }

        _createClass(RoadPoint, [{
          key: "start",
          value: function start() {
            this.arrCars = this.cars.split(','); // Your initialization goes here.
          }
        }, {
          key: "startSchedule",
          value: function startSchedule(cd) {
            if (this.type !== ROAD_POINT_TYPE.AI_START) {
              return;
            }

            this.stopSchedule();
            this.cd = cd;
            this.scheduleOnce(this.startDelay, this.delayTime);
          }
        }, {
          key: "stopSchedule",
          value: function stopSchedule() {
            this.unschedule(this.startDelay);
            this.unschedule(this.scheduleCD);
          }
        }, {
          key: "startDelay",
          value: function startDelay() {
            //this.scheduleCD();
            this.unschedule(this.scheduleCD);
            this.schedule(this.scheduleCD, this.interval, macro.REPEAT_FOREVER);
          }
        }, {
          key: "scheduleCD",
          value: function scheduleCD() {
            var index = Math.floor(Math.random() * this.arrCars.length);

            if (this.cd) {
              this.cd(this, this.arrCars[index]);
            }
          } // update (deltaTime: number) {
          //     // Your update function goes here.
          // }

        }]);

        return RoadPoint;
      }(Component), _class3.RoadPointType = ROAD_POINT_TYPE, _class3.RoadMoveType = ROAD_MOVE_TYPE, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "type", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return ROAD_POINT_TYPE.NORMAL;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "nextStation", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "moveType", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return ROAD_MOVE_TYPE.LINE;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "clockwise", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return true;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "direction", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return new Vec3(1, 0, 0);
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "interval", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 3;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "delayTime", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 0;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "speed", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 0.05;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "cars", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return "201";
        }
      })), _class2)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ3JlYXRvci9TcGVlZFRheGkvYXNzZXRzL3NjcmlwdC9nYW1lL1JvYWRQb2ludC50cyJdLCJuYW1lcyI6WyJfZGVjb3JhdG9yIiwiQ29tcG9uZW50IiwiTm9kZSIsIlZlYzMiLCJFbnVtIiwibWFjcm8iLCJjY2NsYXNzIiwicHJvcGVydHkiLCJST0FEX1BPSU5UX1RZUEUiLCJST0FEX01PVkVfVFlQRSIsIlJvYWRQb2ludCIsInR5cGUiLCJkaXNwbGF5T3JkZXIiLCJ2aXNpYmxlIiwiRU5EIiwibW92ZVR5cGUiLCJDVVJWRSIsIkdPT0RCWUUiLCJHUkVFVElORyIsIkFJX1NUQVJUIiwiYXJyQ2FycyIsImNkIiwiY2FycyIsInNwbGl0Iiwic3RvcFNjaGVkdWxlIiwic2NoZWR1bGVPbmNlIiwic3RhcnREZWxheSIsImRlbGF5VGltZSIsInVuc2NoZWR1bGUiLCJzY2hlZHVsZUNEIiwic2NoZWR1bGUiLCJpbnRlcnZhbCIsIlJFUEVBVF9GT1JFVkVSIiwiaW5kZXgiLCJNYXRoIiwiZmxvb3IiLCJyYW5kb20iLCJsZW5ndGgiLCJSb2FkUG9pbnRUeXBlIiwiUm9hZE1vdmVUeXBlIiwiTk9STUFMIiwiTElORSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQVNBLE1BQUFBLFUsT0FBQUEsVTtBQUFZQyxNQUFBQSxTLE9BQUFBLFM7QUFBV0MsTUFBQUEsSSxPQUFBQSxJO0FBQU1DLE1BQUFBLEksT0FBQUEsSTtBQUFNQyxNQUFBQSxJLE9BQUFBLEk7QUFBTUMsTUFBQUEsSyxPQUFBQSxLOzs7Ozs7QUFDMUNDLE1BQUFBLE8sR0FBc0JOLFUsQ0FBdEJNLE87QUFBU0MsTUFBQUEsUSxHQUFhUCxVLENBQWJPLFE7O2lCQUVaQyxlO0FBQUFBLFFBQUFBLGUsQ0FBQUEsZTtBQUFBQSxRQUFBQSxlLENBQUFBLGU7QUFBQUEsUUFBQUEsZSxDQUFBQSxlO0FBQUFBLFFBQUFBLGUsQ0FBQUEsZTtBQUFBQSxRQUFBQSxlLENBQUFBLGU7QUFBQUEsUUFBQUEsZSxDQUFBQSxlO1NBQUFBLGUsS0FBQUEsZTs7QUFRTEosTUFBQUEsSUFBSSxDQUFDSSxlQUFELENBQUo7O2lCQUVLQyxjO0FBQUFBLFFBQUFBLGMsQ0FBQUEsYztBQUFBQSxRQUFBQSxjLENBQUFBLGM7U0FBQUEsYyxLQUFBQSxjOztBQUlMTCxNQUFBQSxJQUFJLENBQUNLLGNBQUQsQ0FBSjs7MkJBR2FDLFMsV0FEWkosT0FBTyxDQUFDLFdBQUQsQyxVQUtIQyxRQUFRLENBQUM7QUFDTkksUUFBQUEsSUFBSSxFQUFDSCxlQURDO0FBRU5JLFFBQUFBLFlBQVksRUFBQztBQUZQLE9BQUQsQyxVQU1STCxRQUFRLENBQUM7QUFDTkksUUFBQUEsSUFBSSxFQUFDVCxJQURDO0FBRU5VLFFBQUFBLFlBQVksRUFBQyxDQUZQO0FBR05DLFFBQUFBLE9BQU8sRUFBQyxtQkFBd0I7QUFDNUIsaUJBQU8sSUFBUCxDQUQ0QixDQUNoQjtBQUNmO0FBTEssT0FBRCxDLFVBU1JOLFFBQVEsQ0FBQztBQUNOSSxRQUFBQSxJQUFJLEVBQUNGLGNBREM7QUFFTkcsUUFBQUEsWUFBWSxFQUFDLENBRlA7QUFHTkMsUUFBQUEsT0FBTyxFQUFDLG1CQUF3QjtBQUM1QixpQkFBTyxLQUFLRixJQUFMLEtBQWFILGVBQWUsQ0FBQ00sR0FBcEM7QUFDSDtBQUxLLE9BQUQsQyxVQVNSUCxRQUFRLENBQUM7QUFDTkssUUFBQUEsWUFBWSxFQUFDLENBRFA7QUFFTkMsUUFBQUEsT0FBTyxFQUFDLG1CQUF3QjtBQUM1QixpQkFBTyxLQUFLRixJQUFMLEtBQWFILGVBQWUsQ0FBQ00sR0FBN0IsSUFBb0MsS0FBS0MsUUFBTCxLQUFrQk4sY0FBYyxDQUFDTyxLQUE1RTtBQUNIO0FBSkssT0FBRCxDLFVBUVJULFFBQVEsQ0FBQztBQUNOSSxRQUFBQSxJQUFJLEVBQUNSLElBREM7QUFFTlUsUUFBQUEsT0FBTyxFQUFDLG1CQUF3QjtBQUM1QixpQkFBTyxLQUFLRixJQUFMLEtBQWNILGVBQWUsQ0FBQ1MsT0FBOUIsSUFBeUMsS0FBS04sSUFBTCxLQUFjSCxlQUFlLENBQUNVLFFBQTlFO0FBQ0g7QUFKSyxPQUFELEMsVUFRUlgsUUFBUSxDQUFDO0FBQ05NLFFBQUFBLE9BQU8sRUFBQyxtQkFBd0I7QUFDNUIsaUJBQU8sS0FBS0YsSUFBTCxLQUFjSCxlQUFlLENBQUNXLFFBQXJDO0FBQ0g7QUFISyxPQUFELEMsVUFPUlosUUFBUSxDQUFDO0FBQ05NLFFBQUFBLE9BQU8sRUFBQyxtQkFBd0I7QUFDNUIsaUJBQU8sS0FBS0YsSUFBTCxLQUFjSCxlQUFlLENBQUNXLFFBQXJDO0FBQ0g7QUFISyxPQUFELEMsVUFPUlosUUFBUSxDQUFDO0FBQ05NLFFBQUFBLE9BQU8sRUFBQyxtQkFBd0I7QUFDNUIsaUJBQU8sS0FBS0YsSUFBTCxLQUFjSCxlQUFlLENBQUNXLFFBQXJDO0FBQ0g7QUFISyxPQUFELEMsV0FRUlosUUFBUSxDQUFDO0FBQ05NLFFBQUFBLE9BQU8sRUFBQyxtQkFBd0I7QUFDNUIsaUJBQU8sS0FBS0YsSUFBTCxLQUFjSCxlQUFlLENBQUNXLFFBQXJDO0FBQ0g7QUFISyxPQUFELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0JBT0RDLE8sR0FBaUIsRTtnQkFDakJDLEUsR0FBYyxJOzs7Ozs7a0NBRU47QUFDWixpQkFBS0QsT0FBTCxHQUFhLEtBQUtFLElBQUwsQ0FBVUMsS0FBVixDQUFnQixHQUFoQixDQUFiLENBRFksQ0FFWjtBQUNIOzs7d0NBRW9CRixFLEVBQVk7QUFDN0IsZ0JBQUcsS0FBS1YsSUFBTCxLQUFZSCxlQUFlLENBQUNXLFFBQS9CLEVBQ0E7QUFDSTtBQUNIOztBQUNELGlCQUFLSyxZQUFMO0FBQ0EsaUJBQUtILEVBQUwsR0FBUUEsRUFBUjtBQUNBLGlCQUFLSSxZQUFMLENBQWtCLEtBQUtDLFVBQXZCLEVBQWtDLEtBQUtDLFNBQXZDO0FBQ0g7Ozt5Q0FFb0I7QUFDakIsaUJBQUtDLFVBQUwsQ0FBZ0IsS0FBS0YsVUFBckI7QUFDQSxpQkFBS0UsVUFBTCxDQUFnQixLQUFLQyxVQUFyQjtBQUNIOzs7dUNBRW1CO0FBQ2hCO0FBQ0EsaUJBQUtELFVBQUwsQ0FBZ0IsS0FBS0MsVUFBckI7QUFDQSxpQkFBS0MsUUFBTCxDQUFjLEtBQUtELFVBQW5CLEVBQThCLEtBQUtFLFFBQW5DLEVBQTRDMUIsS0FBSyxDQUFDMkIsY0FBbEQ7QUFDSDs7O3VDQUVtQjtBQUNoQixnQkFBTUMsS0FBSyxHQUFDQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWMsS0FBS2hCLE9BQUwsQ0FBYWlCLE1BQXRDLENBQVo7O0FBQ0EsZ0JBQUcsS0FBS2hCLEVBQVIsRUFBVztBQUNQLG1CQUFLQSxFQUFMLENBQVEsSUFBUixFQUFhLEtBQUtELE9BQUwsQ0FBYWEsS0FBYixDQUFiO0FBQ0g7QUFDSixXLENBRUQ7QUFDQTtBQUNBOzs7OztRQS9HMkJoQyxTLFdBQ2JxQyxhLEdBQWdCOUIsZSxVQUNoQitCLFksR0FBZTlCLGM7Ozs7O2lCQU10QkQsZUFBZSxDQUFDZ0MsTTs7Ozs7OztpQkFTSixJOzs7Ozs7O2lCQVNSL0IsY0FBYyxDQUFDZ0MsSTs7Ozs7OztpQkFRZCxJOzs7Ozs7O2lCQVFBLElBQUl0QyxJQUFKLENBQVMsQ0FBVCxFQUFXLENBQVgsRUFBYSxDQUFiLEM7Ozs7Ozs7aUJBT0QsQzs7Ozs7OztpQkFPQyxDOzs7Ozs7O2lCQU9KLEk7Ozs7Ozs7aUJBUUQsSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IF9kZWNvcmF0b3IsIENvbXBvbmVudCwgTm9kZSwgVmVjMywgRW51bSwgbWFjcm8gfSBmcm9tICdjYyc7XHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IF9kZWNvcmF0b3I7XHJcblxyXG5lbnVtIFJPQURfUE9JTlRfVFlQRXtcclxuICAgIE5PUk1BTD0xLFxyXG4gICAgU1RBUlQsXHJcbiAgICBHUkVFVElORyxcclxuICAgIEdPT0RCWUUsXHJcbiAgICBFTkQsXHJcbiAgICBBSV9TVEFSVCxcclxufVxyXG5FbnVtKFJPQURfUE9JTlRfVFlQRSk7XHJcblxyXG5lbnVtIFJPQURfTU9WRV9UWVBFe1xyXG4gICAgTElORT0xLFxyXG4gICAgQ1VSVkUsXHJcbn1cclxuRW51bShST0FEX01PVkVfVFlQRSk7XHJcblxyXG5AY2NjbGFzcygnUm9hZFBvaW50JylcclxuZXhwb3J0IGNsYXNzIFJvYWRQb2ludCBleHRlbmRzIENvbXBvbmVudCB7XHJcbiAgICBwdWJsaWMgc3RhdGljIFJvYWRQb2ludFR5cGUgPSBST0FEX1BPSU5UX1RZUEU7XHJcbiAgICBwdWJsaWMgc3RhdGljIFJvYWRNb3ZlVHlwZSA9IFJPQURfTU9WRV9UWVBFO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7XHJcbiAgICAgICAgdHlwZTpST0FEX1BPSU5UX1RZUEUsXHJcbiAgICAgICAgZGlzcGxheU9yZGVyOjEsXHJcbiAgICB9KVxyXG4gICAgdHlwZSA9IFJPQURfUE9JTlRfVFlQRS5OT1JNQUw7XHJcblxyXG4gICAgQHByb3BlcnR5KHtcclxuICAgICAgICB0eXBlOk5vZGUsXHJcbiAgICAgICAgZGlzcGxheU9yZGVyOjIsXHJcbiAgICAgICAgdmlzaWJsZTpmdW5jdGlvbih0aGlzOlJvYWRQb2ludCl7XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlOy8vdGhpcy50eXBlICE9PVJPQURfUE9JTlRfVFlQRS5FTkQ7XHJcbiAgICAgICAgfVxyXG4gICAgfSlcclxuICAgIG5leHRTdGF0aW9uOk5vZGUgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7XHJcbiAgICAgICAgdHlwZTpST0FEX01PVkVfVFlQRSxcclxuICAgICAgICBkaXNwbGF5T3JkZXI6MyxcclxuICAgICAgICB2aXNpYmxlOmZ1bmN0aW9uKHRoaXM6Um9hZFBvaW50KXtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMudHlwZSAhPT1ST0FEX1BPSU5UX1RZUEUuRU5EO1xyXG4gICAgICAgIH1cclxuICAgIH0pXHJcbiAgICBtb3ZlVHlwZSA9IFJPQURfTU9WRV9UWVBFLkxJTkU7XHJcblxyXG4gICAgQHByb3BlcnR5KHtcclxuICAgICAgICBkaXNwbGF5T3JkZXI6NCxcclxuICAgICAgICB2aXNpYmxlOmZ1bmN0aW9uKHRoaXM6Um9hZFBvaW50KXtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMudHlwZSAhPT1ST0FEX1BPSU5UX1RZUEUuRU5EICYmIHRoaXMubW92ZVR5cGUgPT09IFJPQURfTU9WRV9UWVBFLkNVUlZFO1xyXG4gICAgICAgIH1cclxuICAgIH0pXHJcbiAgICBjbG9ja3dpc2UgPSB0cnVlO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7XHJcbiAgICAgICAgdHlwZTpWZWMzLFxyXG4gICAgICAgIHZpc2libGU6ZnVuY3Rpb24odGhpczpSb2FkUG9pbnQpe1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy50eXBlID09PSBST0FEX1BPSU5UX1RZUEUuR09PREJZRSB8fCB0aGlzLnR5cGUgPT09IFJPQURfUE9JTlRfVFlQRS5HUkVFVElORztcclxuICAgICAgICB9XHJcbiAgICB9KVxyXG4gICAgZGlyZWN0aW9uID0gbmV3IFZlYzMoMSwwLDApXHJcblxyXG4gICAgQHByb3BlcnR5KHtcclxuICAgICAgICB2aXNpYmxlOmZ1bmN0aW9uKHRoaXM6Um9hZFBvaW50KXtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMudHlwZSA9PT0gUk9BRF9QT0lOVF9UWVBFLkFJX1NUQVJUO1xyXG4gICAgICAgIH1cclxuICAgIH0pXHJcbiAgICBpbnRlcnZhbCA9IDM7XHJcblxyXG4gICAgQHByb3BlcnR5KHtcclxuICAgICAgICB2aXNpYmxlOmZ1bmN0aW9uKHRoaXM6Um9hZFBvaW50KXtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMudHlwZSA9PT0gUk9BRF9QT0lOVF9UWVBFLkFJX1NUQVJUO1xyXG4gICAgICAgIH1cclxuICAgIH0pXHJcbiAgICBkZWxheVRpbWUgPSAwO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7XHJcbiAgICAgICAgdmlzaWJsZTpmdW5jdGlvbih0aGlzOlJvYWRQb2ludCl7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnR5cGUgPT09IFJPQURfUE9JTlRfVFlQRS5BSV9TVEFSVDtcclxuICAgICAgICB9XHJcbiAgICB9KVxyXG4gICAgc3BlZWQgPSAwLjA1O1xyXG5cclxuICAgIC8vMjAxLDIwMlxyXG4gICAgQHByb3BlcnR5KHtcclxuICAgICAgICB2aXNpYmxlOmZ1bmN0aW9uKHRoaXM6Um9hZFBvaW50KXtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMudHlwZSA9PT0gUk9BRF9QT0lOVF9UWVBFLkFJX1NUQVJUO1xyXG4gICAgICAgIH1cclxuICAgIH0pXHJcbiAgICBjYXJzID0gXCIyMDFcIjtcclxuXHJcbiAgICBwcml2YXRlIGFyckNhcnM6c3RyaW5nW109W107XHJcbiAgICBwcml2YXRlIGNkOkZ1bmN0aW9uID0gbnVsbDtcclxuXHJcbiAgICBwdWJsaWMgc3RhcnQgKCkge1xyXG4gICAgICAgIHRoaXMuYXJyQ2Fycz10aGlzLmNhcnMuc3BsaXQoJywnKTtcclxuICAgICAgICAvLyBZb3VyIGluaXRpYWxpemF0aW9uIGdvZXMgaGVyZS5cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc3RhcnRTY2hlZHVsZShjZDpGdW5jdGlvbil7XHJcbiAgICAgICAgaWYodGhpcy50eXBlIT09Uk9BRF9QT0lOVF9UWVBFLkFJX1NUQVJUKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnN0b3BTY2hlZHVsZSgpO1xyXG4gICAgICAgIHRoaXMuY2Q9Y2Q7XHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UodGhpcy5zdGFydERlbGF5LHRoaXMuZGVsYXlUaW1lKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc3RvcFNjaGVkdWxlKCl7XHJcbiAgICAgICAgdGhpcy51bnNjaGVkdWxlKHRoaXMuc3RhcnREZWxheSk7XHJcbiAgICAgICAgdGhpcy51bnNjaGVkdWxlKHRoaXMuc2NoZWR1bGVDRCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBzdGFydERlbGF5KCl7XHJcbiAgICAgICAgLy90aGlzLnNjaGVkdWxlQ0QoKTtcclxuICAgICAgICB0aGlzLnVuc2NoZWR1bGUodGhpcy5zY2hlZHVsZUNEKTtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlKHRoaXMuc2NoZWR1bGVDRCx0aGlzLmludGVydmFsLG1hY3JvLlJFUEVBVF9GT1JFVkVSKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIHNjaGVkdWxlQ0QoKXtcclxuICAgICAgICBjb25zdCBpbmRleD1NYXRoLmZsb29yKE1hdGgucmFuZG9tKCkqdGhpcy5hcnJDYXJzLmxlbmd0aCk7XHJcbiAgICAgICAgaWYodGhpcy5jZCl7XHJcbiAgICAgICAgICAgIHRoaXMuY2QodGhpcyx0aGlzLmFyckNhcnNbaW5kZXhdKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gdXBkYXRlIChkZWx0YVRpbWU6IG51bWJlcikge1xyXG4gICAgLy8gICAgIC8vIFlvdXIgdXBkYXRlIGZ1bmN0aW9uIGdvZXMgaGVyZS5cclxuICAgIC8vIH1cclxufVxyXG4iXX0=