System.register(["cc", "code-quality:cr", "./MapMgr.js", "./CarMgr.js", "./AudioMgr.js", "../data/Constants.js", "../data/CustomEventListener.js", "../ui/UIMgr.js", "../data/GameData.js", "../ui/LoadingUI.js", "../data/ConfigMgr.js"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Component, Node, BoxColliderComponent, loader, Prefab, instantiate, MapMgr, CarMgr, AudioMgr, Constants, CustomEventListener, UIMgr, RunTimeData, PlayerData, LoadingUI, ConfigMgr, _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _temp, _crd, ccclass, property, GameCtrl;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfMapMgr(extras) {
    _reporterNs.report("MapMgr", "./MapMgr", _context.meta, extras);
  }

  function _reportPossibleCrUseOfCarMgr(extras) {
    _reporterNs.report("CarMgr", "./CarMgr", _context.meta, extras);
  }

  function _reportPossibleCrUseOfAudioMgr(extras) {
    _reporterNs.report("AudioMgr", "./AudioMgr", _context.meta, extras);
  }

  function _reportPossibleCrUseOfConstants(extras) {
    _reporterNs.report("Constants", "../data/Constants", _context.meta, extras);
  }

  function _reportPossibleCrUseOfCustomEventListener(extras) {
    _reporterNs.report("CustomEventListener", "../data/CustomEventListener", _context.meta, extras);
  }

  function _reportPossibleCrUseOfUIMgr(extras) {
    _reporterNs.report("UIMgr", "../ui/UIMgr", _context.meta, extras);
  }

  function _reportPossibleCrUseOfRunTimeData(extras) {
    _reporterNs.report("RunTimeData", "../data/GameData", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlayerData(extras) {
    _reporterNs.report("PlayerData", "../data/GameData", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLoadingUI(extras) {
    _reporterNs.report("LoadingUI", "../ui/LoadingUI", _context.meta, extras);
  }

  function _reportPossibleCrUseOfConfigMgr(extras) {
    _reporterNs.report("ConfigMgr", "../data/ConfigMgr", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _dec2: void 0,
    _dec3: void 0,
    _dec4: void 0,
    _dec5: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _descriptor2: void 0,
    _descriptor3: void 0,
    _descriptor4: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      BoxColliderComponent = _cc.BoxColliderComponent;
      loader = _cc.loader;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_MapMgrJs) {
      MapMgr = _MapMgrJs.MapMgr;
    }, function (_CarMgrJs) {
      CarMgr = _CarMgrJs.CarMgr;
    }, function (_AudioMgrJs) {
      AudioMgr = _AudioMgrJs.AudioMgr;
    }, function (_dataConstantsJs) {
      Constants = _dataConstantsJs.Constants;
    }, function (_dataCustomEventListenerJs) {
      CustomEventListener = _dataCustomEventListenerJs.CustomEventListener;
    }, function (_uiUIMgrJs) {
      UIMgr = _uiUIMgrJs.UIMgr;
    }, function (_dataGameDataJs) {
      RunTimeData = _dataGameDataJs.RunTimeData;
      PlayerData = _dataGameDataJs.PlayerData;
    }, function (_uiLoadingUIJs) {
      LoadingUI = _uiLoadingUIJs.LoadingUI;
    }, function (_dataConfigMgrJs) {
      ConfigMgr = _dataConfigMgrJs.ConfigMgr;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "0c2b5v062xBmJLmyhN38Z5k", "GameCtrl", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("GameCtrl", GameCtrl = (_dec = ccclass('GameCtrl'), _dec2 = property({
        type: _crd && MapMgr === void 0 ? (_reportPossibleCrUseOfMapMgr({
          error: Error()
        }), MapMgr) : MapMgr
      }), _dec3 = property({
        type: _crd && CarMgr === void 0 ? (_reportPossibleCrUseOfCarMgr({
          error: Error()
        }), CarMgr) : CarMgr
      }), _dec4 = property({
        type: Node
      }), _dec5 = property({
        type: _crd && LoadingUI === void 0 ? (_reportPossibleCrUseOfLoadingUI({
          error: Error()
        }), LoadingUI) : LoadingUI
      }), _dec(_class = (_class2 = (_temp = /*#__PURE__*/function (_Component) {
        _inherits(GameCtrl, _Component);

        function GameCtrl() {
          var _getPrototypeOf2;

          var _this;

          _classCallCheck(this, GameCtrl);

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(GameCtrl)).call.apply(_getPrototypeOf2, [this].concat(args)));

          _initializerDefineProperty(_this, "mapMgr", _descriptor, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "carMgr", _descriptor2, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "group", _descriptor3, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "LoadingUI", _descriptor4, _assertThisInitialized(_this));

          _this.progress = 5;
          _this.runTimeData = null;
          return _this;
        }

        _createClass(GameCtrl, [{
          key: "onLoad",
          value: function onLoad() {
            //this.reset();
            this.runTimeData = (_crd && RunTimeData === void 0 ? (_reportPossibleCrUseOfRunTimeData({
              error: Error()
            }), RunTimeData) : RunTimeData).instance();
            (_crd && ConfigMgr === void 0 ? (_reportPossibleCrUseOfConfigMgr({
              error: Error()
            }), ConfigMgr) : ConfigMgr).instance().init();
            (_crd && PlayerData === void 0 ? (_reportPossibleCrUseOfPlayerData({
              error: Error()
            }), PlayerData) : PlayerData).instance().loadFormCache();
            this.loadMap();
            var collider = this.group.getComponent(BoxColliderComponent);
            collider.setGroup((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).CarGroup.NORMAL);
            collider.setMask(-1);
            cc.debug.setDisplayStats(false);
          }
        }, {
          key: "start",
          value: function start() {
            (_crd && UIMgr === void 0 ? (_reportPossibleCrUseOfUIMgr({
              error: Error()
            }), UIMgr) : UIMgr).showDialog((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).UIPage.mainUI);
            this.node.on(Node.EventType.TOUCH_START, this.touchStart, this);
            this.node.on(Node.EventType.TOUCH_END, this.touchEnd, this);
            (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
              error: Error()
            }), CustomEventListener) : CustomEventListener).on((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).EventName.GAMESTART, this.gameStart, this);
            (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
              error: Error()
            }), CustomEventListener) : CustomEventListener).on((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).EventName.GAMEOVER, this.gameOver, this);
            (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
              error: Error()
            }), CustomEventListener) : CustomEventListener).on((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).EventName.NEWLEVEL, this.newLevel, this);
            (_crd && AudioMgr === void 0 ? (_reportPossibleCrUseOfAudioMgr({
              error: Error()
            }), AudioMgr) : AudioMgr).playMusic((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).AudioFiles.BG);
          }
        }, {
          key: "gameStart",
          value: function gameStart() {
            (_crd && UIMgr === void 0 ? (_reportPossibleCrUseOfUIMgr({
              error: Error()
            }), UIMgr) : UIMgr).hideDialog((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).UIPage.mainUI);
            (_crd && UIMgr === void 0 ? (_reportPossibleCrUseOfUIMgr({
              error: Error()
            }), UIMgr) : UIMgr).showDialog((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).UIPage.gameUI);
          }
        }, {
          key: "gameOver",
          value: function gameOver() {
            (_crd && UIMgr === void 0 ? (_reportPossibleCrUseOfUIMgr({
              error: Error()
            }), UIMgr) : UIMgr).hideDialog((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).UIPage.gameUI);
            (_crd && UIMgr === void 0 ? (_reportPossibleCrUseOfUIMgr({
              error: Error()
            }), UIMgr) : UIMgr).showDialog((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).UIPage.resultUI);
          }
        }, {
          key: "newLevel",
          value: function newLevel() {
            (_crd && UIMgr === void 0 ? (_reportPossibleCrUseOfUIMgr({
              error: Error()
            }), UIMgr) : UIMgr).hideDialog((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).UIPage.resultUI);
            (_crd && UIMgr === void 0 ? (_reportPossibleCrUseOfUIMgr({
              error: Error()
            }), UIMgr) : UIMgr).showDialog((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).UIPage.mainUI);

            if ((_crd && RunTimeData === void 0 ? (_reportPossibleCrUseOfRunTimeData({
              error: Error()
            }), RunTimeData) : RunTimeData).instance().currProgress === (_crd && RunTimeData === void 0 ? (_reportPossibleCrUseOfRunTimeData({
              error: Error()
            }), RunTimeData) : RunTimeData).instance().maxProgress) {
              this.mapMgr.recycle(); //this.reset();

              this.unschedule(this.loadMap);
              this.scheduleOnce(this.loadMap, 0.01); //this.loadMap(1);
            } else {
              this.reset();
            }
          }
        }, {
          key: "touchStart",
          value: function touchStart(touch, event) {
            this.carMgr.controlMoving(true);
          }
        }, {
          key: "touchEnd",
          value: function touchEnd(touch, event) {
            this.carMgr.controlMoving(false);
          }
        }, {
          key: "reset",
          value: function reset() {
            this.mapMgr.resetMap();
            this.carMgr.reset(this.mapMgr.currPath);
            this.runTimeData.maxProgress = this.mapMgr.maxProgress;
            this.runTimeData.currProgress = 0;
            this.runTimeData.isTakeOver = true;
            this.runTimeData.money = 0;
          }
        }, {
          key: "loadMap",
          value: function loadMap(cb) {
            var _this2 = this;

            this.LoadingUI.show();
            var map = 'map/map';
            var level = this.runTimeData.currLevel;

            if (level > (_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).MaxLevel) {
              level = Math.ceil(Math.random() * (_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
                error: Error()
              }), Constants) : Constants).MaxLevel);

              if (level < 1) {
                level = 1;
              }

              ;
            }

            if (level >= 100) {
              map += "".concat(level);
            } else if (level >= 10) {
              map += "1".concat(level);
            } else if (level > 0) {
              map += "10".concat(level);
            }

            this.progress = 5;
            this.unschedule(this.loadingSchedule);
            this.scheduleOnce(this.loadingSchedule, 0.2); //console.log("map load start:"+map);

            loader.loadRes(map, Prefab, function (err, prefab) {
              if (err) {
                console.warn(err);
                return;
              }

              ;
              var mapNode = instantiate(prefab);
              mapNode.parent = _this2.mapMgr.node; // if(cb){
              //     cb();
              // }

              _this2.progress = 0; //console.log("map load done");

              _this2.reset();

              _this2.LoadingUI.finishLoading();
            });
          }
        }, {
          key: "loadingSchedule",
          value: function loadingSchedule() {
            if (this.progress < 0) {
              return;
            }

            this.progress--;
            (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
              error: Error()
            }), CustomEventListener) : CustomEventListener).dispatchEvent((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).EventName.UPDATEPROGRESS, 40 / 5);
            this.unschedule(this.loadingSchedule);
            this.scheduleOnce(this.loadingSchedule, 0.2);
          } // update (deltaTime: number) {
          //     // Your update function goes here.
          // }

        }]);

        return GameCtrl;
      }(Component), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "mapMgr", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "carMgr", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "group", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "LoadingUI", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ3JlYXRvci9TcGVlZFRheGkvYXNzZXRzL3NjcmlwdC9nYW1lL0dhbWVDdHJsLnRzIl0sIm5hbWVzIjpbIl9kZWNvcmF0b3IiLCJDb21wb25lbnQiLCJOb2RlIiwiQm94Q29sbGlkZXJDb21wb25lbnQiLCJsb2FkZXIiLCJQcmVmYWIiLCJpbnN0YW50aWF0ZSIsIk1hcE1nciIsIkNhck1nciIsIkF1ZGlvTWdyIiwiQ29uc3RhbnRzIiwiQ3VzdG9tRXZlbnRMaXN0ZW5lciIsIlVJTWdyIiwiUnVuVGltZURhdGEiLCJQbGF5ZXJEYXRhIiwiTG9hZGluZ1VJIiwiQ29uZmlnTWdyIiwiY2NjbGFzcyIsInByb3BlcnR5IiwiR2FtZUN0cmwiLCJ0eXBlIiwicHJvZ3Jlc3MiLCJydW5UaW1lRGF0YSIsImluc3RhbmNlIiwiaW5pdCIsImxvYWRGb3JtQ2FjaGUiLCJsb2FkTWFwIiwiY29sbGlkZXIiLCJncm91cCIsImdldENvbXBvbmVudCIsInNldEdyb3VwIiwiQ2FyR3JvdXAiLCJOT1JNQUwiLCJzZXRNYXNrIiwiY2MiLCJkZWJ1ZyIsInNldERpc3BsYXlTdGF0cyIsInNob3dEaWFsb2ciLCJVSVBhZ2UiLCJtYWluVUkiLCJub2RlIiwib24iLCJFdmVudFR5cGUiLCJUT1VDSF9TVEFSVCIsInRvdWNoU3RhcnQiLCJUT1VDSF9FTkQiLCJ0b3VjaEVuZCIsIkV2ZW50TmFtZSIsIkdBTUVTVEFSVCIsImdhbWVTdGFydCIsIkdBTUVPVkVSIiwiZ2FtZU92ZXIiLCJORVdMRVZFTCIsIm5ld0xldmVsIiwicGxheU11c2ljIiwiQXVkaW9GaWxlcyIsIkJHIiwiaGlkZURpYWxvZyIsImdhbWVVSSIsInJlc3VsdFVJIiwiY3VyclByb2dyZXNzIiwibWF4UHJvZ3Jlc3MiLCJtYXBNZ3IiLCJyZWN5Y2xlIiwidW5zY2hlZHVsZSIsInNjaGVkdWxlT25jZSIsInJlc2V0IiwidG91Y2giLCJldmVudCIsImNhck1nciIsImNvbnRyb2xNb3ZpbmciLCJyZXNldE1hcCIsImN1cnJQYXRoIiwiaXNUYWtlT3ZlciIsIm1vbmV5IiwiY2IiLCJzaG93IiwibWFwIiwibGV2ZWwiLCJjdXJyTGV2ZWwiLCJNYXhMZXZlbCIsIk1hdGgiLCJjZWlsIiwicmFuZG9tIiwibG9hZGluZ1NjaGVkdWxlIiwibG9hZFJlcyIsImVyciIsInByZWZhYiIsImNvbnNvbGUiLCJ3YXJuIiwibWFwTm9kZSIsInBhcmVudCIsImZpbmlzaExvYWRpbmciLCJkaXNwYXRjaEV2ZW50IiwiVVBEQVRFUFJPR1JFU1MiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFTQSxNQUFBQSxVLE9BQUFBLFU7QUFBWUMsTUFBQUEsUyxPQUFBQSxTO0FBQVdDLE1BQUFBLEksT0FBQUEsSTtBQUFrQkMsTUFBQUEsb0IsT0FBQUEsb0I7QUFBNEJDLE1BQUFBLE0sT0FBQUEsTTtBQUFRQyxNQUFBQSxNLE9BQUFBLE07QUFBUUMsTUFBQUEsVyxPQUFBQSxXOzs7O0FBQ3JGQyxNQUFBQSxNLGFBQUFBLE07O0FBQ0FDLE1BQUFBLE0sYUFBQUEsTTs7QUFDQUMsTUFBQUEsUSxlQUFBQSxROztBQUNBQyxNQUFBQSxTLG9CQUFBQSxTOztBQUNBQyxNQUFBQSxtQiw4QkFBQUEsbUI7O0FBQ0FDLE1BQUFBLEssY0FBQUEsSzs7QUFDQUMsTUFBQUEsVyxtQkFBQUEsVztBQUFhQyxNQUFBQSxVLG1CQUFBQSxVOztBQUNiQyxNQUFBQSxTLGtCQUFBQSxTOztBQUNBQyxNQUFBQSxTLG9CQUFBQSxTOzs7Ozs7QUFDREMsTUFBQUEsTyxHQUFzQmpCLFUsQ0FBdEJpQixPO0FBQVNDLE1BQUFBLFEsR0FBYWxCLFUsQ0FBYmtCLFE7OzBCQUdKQyxRLFdBRFpGLE9BQU8sQ0FBQyxVQUFELEMsVUFFSEMsUUFBUSxDQUFDO0FBQ05FLFFBQUFBLElBQUk7QUFBQTtBQUFBO0FBREUsT0FBRCxDLFVBS1JGLFFBQVEsQ0FBQztBQUNORSxRQUFBQSxJQUFJO0FBQUE7QUFBQTtBQURFLE9BQUQsQyxVQUtSRixRQUFRLENBQUM7QUFDTkUsUUFBQUEsSUFBSSxFQUFDbEI7QUFEQyxPQUFELEMsVUFLUmdCLFFBQVEsQ0FBQztBQUNORSxRQUFBQSxJQUFJO0FBQUE7QUFBQTtBQURFLE9BQUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2dCQU1EQyxRLEdBQVMsQztnQkFHVEMsVyxHQUEwQixJOzs7Ozs7bUNBR25CO0FBQ1g7QUFDQSxpQkFBS0EsV0FBTCxHQUFtQjtBQUFBO0FBQUEsNENBQVlDLFFBQVosRUFBbkI7QUFDQTtBQUFBO0FBQUEsd0NBQVVBLFFBQVYsR0FBcUJDLElBQXJCO0FBQ0E7QUFBQTtBQUFBLDBDQUFXRCxRQUFYLEdBQXNCRSxhQUF0QjtBQUNBLGlCQUFLQyxPQUFMO0FBQ0EsZ0JBQU1DLFFBQVEsR0FBQyxLQUFLQyxLQUFMLENBQVdDLFlBQVgsQ0FBd0IxQixvQkFBeEIsQ0FBZjtBQUNBd0IsWUFBQUEsUUFBUSxDQUFDRyxRQUFULENBQWtCO0FBQUE7QUFBQSx3Q0FBVUMsUUFBVixDQUFtQkMsTUFBckM7QUFDQUwsWUFBQUEsUUFBUSxDQUFDTSxPQUFULENBQWlCLENBQUMsQ0FBbEI7QUFDQUMsWUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLGVBQVQsQ0FBeUIsS0FBekI7QUFDSDs7O2tDQUVRO0FBRUw7QUFBQTtBQUFBLGdDQUFNQyxVQUFOLENBQWlCO0FBQUE7QUFBQSx3Q0FBVUMsTUFBVixDQUFpQkMsTUFBbEM7QUFFQSxpQkFBS0MsSUFBTCxDQUFVQyxFQUFWLENBQWF2QyxJQUFJLENBQUN3QyxTQUFMLENBQWVDLFdBQTVCLEVBQXdDLEtBQUtDLFVBQTdDLEVBQXdELElBQXhEO0FBQ0EsaUJBQUtKLElBQUwsQ0FBVUMsRUFBVixDQUFhdkMsSUFBSSxDQUFDd0MsU0FBTCxDQUFlRyxTQUE1QixFQUFzQyxLQUFLQyxRQUEzQyxFQUFvRCxJQUFwRDtBQUVBO0FBQUE7QUFBQSw0REFBb0JMLEVBQXBCLENBQXVCO0FBQUE7QUFBQSx3Q0FBVU0sU0FBVixDQUFvQkMsU0FBM0MsRUFBcUQsS0FBS0MsU0FBMUQsRUFBb0UsSUFBcEU7QUFDQTtBQUFBO0FBQUEsNERBQW9CUixFQUFwQixDQUF1QjtBQUFBO0FBQUEsd0NBQVVNLFNBQVYsQ0FBb0JHLFFBQTNDLEVBQW9ELEtBQUtDLFFBQXpELEVBQWtFLElBQWxFO0FBQ0E7QUFBQTtBQUFBLDREQUFvQlYsRUFBcEIsQ0FBdUI7QUFBQTtBQUFBLHdDQUFVTSxTQUFWLENBQW9CSyxRQUEzQyxFQUFvRCxLQUFLQyxRQUF6RCxFQUFrRSxJQUFsRTtBQUVBO0FBQUE7QUFBQSxzQ0FBU0MsU0FBVCxDQUFtQjtBQUFBO0FBQUEsd0NBQVVDLFVBQVYsQ0FBcUJDLEVBQXhDO0FBQ0g7OztzQ0FFaUI7QUFDZDtBQUFBO0FBQUEsZ0NBQU1DLFVBQU4sQ0FBaUI7QUFBQTtBQUFBLHdDQUFVbkIsTUFBVixDQUFpQkMsTUFBbEM7QUFDQTtBQUFBO0FBQUEsZ0NBQU1GLFVBQU4sQ0FBaUI7QUFBQTtBQUFBLHdDQUFVQyxNQUFWLENBQWlCb0IsTUFBbEM7QUFDSDs7O3FDQUVnQjtBQUNiO0FBQUE7QUFBQSxnQ0FBTUQsVUFBTixDQUFpQjtBQUFBO0FBQUEsd0NBQVVuQixNQUFWLENBQWlCb0IsTUFBbEM7QUFDQTtBQUFBO0FBQUEsZ0NBQU1yQixVQUFOLENBQWlCO0FBQUE7QUFBQSx3Q0FBVUMsTUFBVixDQUFpQnFCLFFBQWxDO0FBQ0g7OztxQ0FFZ0I7QUFDYjtBQUFBO0FBQUEsZ0NBQU1GLFVBQU4sQ0FBaUI7QUFBQTtBQUFBLHdDQUFVbkIsTUFBVixDQUFpQnFCLFFBQWxDO0FBQ0E7QUFBQTtBQUFBLGdDQUFNdEIsVUFBTixDQUFpQjtBQUFBO0FBQUEsd0NBQVVDLE1BQVYsQ0FBaUJDLE1BQWxDOztBQUNBLGdCQUFHO0FBQUE7QUFBQSw0Q0FBWWhCLFFBQVosR0FBdUJxQyxZQUF2QixLQUFzQztBQUFBO0FBQUEsNENBQVlyQyxRQUFaLEdBQXVCc0MsV0FBaEUsRUFBNEU7QUFDeEUsbUJBQUtDLE1BQUwsQ0FBWUMsT0FBWixHQUR3RSxDQUV4RTs7QUFDQSxtQkFBS0MsVUFBTCxDQUFnQixLQUFLdEMsT0FBckI7QUFDQSxtQkFBS3VDLFlBQUwsQ0FBa0IsS0FBS3ZDLE9BQXZCLEVBQStCLElBQS9CLEVBSndFLENBS3hFO0FBQ0gsYUFORCxNQVFBO0FBQ0ksbUJBQUt3QyxLQUFMO0FBQ0g7QUFDSjs7O3FDQUVrQkMsSyxFQUFZQyxLLEVBQy9CO0FBQ0ksaUJBQUtDLE1BQUwsQ0FBWUMsYUFBWixDQUEwQixJQUExQjtBQUNIOzs7bUNBRWVILEssRUFBWUMsSyxFQUM1QjtBQUNJLGlCQUFLQyxNQUFMLENBQVlDLGFBQVosQ0FBMEIsS0FBMUI7QUFDSDs7O2tDQUVjO0FBQ1gsaUJBQUtSLE1BQUwsQ0FBWVMsUUFBWjtBQUNBLGlCQUFLRixNQUFMLENBQVlILEtBQVosQ0FBa0IsS0FBS0osTUFBTCxDQUFZVSxRQUE5QjtBQUNBLGlCQUFLbEQsV0FBTCxDQUFpQnVDLFdBQWpCLEdBQStCLEtBQUtDLE1BQUwsQ0FBWUQsV0FBM0M7QUFDQSxpQkFBS3ZDLFdBQUwsQ0FBaUJzQyxZQUFqQixHQUFnQyxDQUFoQztBQUNBLGlCQUFLdEMsV0FBTCxDQUFpQm1ELFVBQWpCLEdBQThCLElBQTlCO0FBQ0EsaUJBQUtuRCxXQUFMLENBQWlCb0QsS0FBakIsR0FBeUIsQ0FBekI7QUFDSDs7O2tDQUVlQyxFLEVBQWE7QUFBQTs7QUFDekIsaUJBQUs1RCxTQUFMLENBQWU2RCxJQUFmO0FBQ0EsZ0JBQUlDLEdBQUcsR0FBRyxTQUFWO0FBQ0EsZ0JBQUlDLEtBQUssR0FBQyxLQUFLeEQsV0FBTCxDQUFpQnlELFNBQTNCOztBQUNBLGdCQUFHRCxLQUFLLEdBQUM7QUFBQTtBQUFBLHdDQUFVRSxRQUFuQixFQUE0QjtBQUN4QkYsY0FBQUEsS0FBSyxHQUFDRyxJQUFJLENBQUNDLElBQUwsQ0FBVUQsSUFBSSxDQUFDRSxNQUFMLEtBQWM7QUFBQTtBQUFBLDBDQUFVSCxRQUFsQyxDQUFOOztBQUNBLGtCQUFHRixLQUFLLEdBQUMsQ0FBVCxFQUFXO0FBQUNBLGdCQUFBQSxLQUFLLEdBQUMsQ0FBTjtBQUFROztBQUFBO0FBQ3ZCOztBQUNELGdCQUFHQSxLQUFLLElBQUUsR0FBVixFQUFjO0FBQ1ZELGNBQUFBLEdBQUcsY0FBTUMsS0FBTixDQUFIO0FBQ0gsYUFGRCxNQUVNLElBQUdBLEtBQUssSUFBRSxFQUFWLEVBQWE7QUFDZkQsY0FBQUEsR0FBRyxlQUFPQyxLQUFQLENBQUg7QUFDSCxhQUZLLE1BRUEsSUFBR0EsS0FBSyxHQUFDLENBQVQsRUFBVztBQUNiRCxjQUFBQSxHQUFHLGdCQUFRQyxLQUFSLENBQUg7QUFDSDs7QUFDRCxpQkFBS3pELFFBQUwsR0FBZ0IsQ0FBaEI7QUFDQSxpQkFBSzJDLFVBQUwsQ0FBZ0IsS0FBS29CLGVBQXJCO0FBQ0EsaUJBQUtuQixZQUFMLENBQWtCLEtBQUttQixlQUF2QixFQUF1QyxHQUF2QyxFQWpCeUIsQ0FrQnpCOztBQUNBaEYsWUFBQUEsTUFBTSxDQUFDaUYsT0FBUCxDQUFlUixHQUFmLEVBQW1CeEUsTUFBbkIsRUFBMEIsVUFBQ2lGLEdBQUQsRUFBU0MsTUFBVCxFQUF5QjtBQUMvQyxrQkFBR0QsR0FBSCxFQUFPO0FBQ0hFLGdCQUFBQSxPQUFPLENBQUNDLElBQVIsQ0FBYUgsR0FBYjtBQUNBO0FBQ0g7O0FBQUE7QUFDRCxrQkFBTUksT0FBTyxHQUFDcEYsV0FBVyxDQUFDaUYsTUFBRCxDQUF6QjtBQUNBRyxjQUFBQSxPQUFPLENBQUNDLE1BQVIsR0FBaUIsTUFBSSxDQUFDN0IsTUFBTCxDQUFZdEIsSUFBN0IsQ0FOK0MsQ0FPL0M7QUFDQTtBQUNBOztBQUNBLGNBQUEsTUFBSSxDQUFDbkIsUUFBTCxHQUFjLENBQWQsQ0FWK0MsQ0FXL0M7O0FBQ0EsY0FBQSxNQUFJLENBQUM2QyxLQUFMOztBQUNBLGNBQUEsTUFBSSxDQUFDbkQsU0FBTCxDQUFlNkUsYUFBZjtBQUNILGFBZEQ7QUFlSDs7OzRDQUV3QjtBQUNyQixnQkFBRyxLQUFLdkUsUUFBTCxHQUFjLENBQWpCLEVBQW1CO0FBQ2Y7QUFDSDs7QUFDRCxpQkFBS0EsUUFBTDtBQUNBO0FBQUE7QUFBQSw0REFBb0J3RSxhQUFwQixDQUFrQztBQUFBO0FBQUEsd0NBQVU5QyxTQUFWLENBQW9CK0MsY0FBdEQsRUFBcUUsS0FBRyxDQUF4RTtBQUNBLGlCQUFLOUIsVUFBTCxDQUFnQixLQUFLb0IsZUFBckI7QUFDQSxpQkFBS25CLFlBQUwsQ0FBa0IsS0FBS21CLGVBQXZCLEVBQXVDLEdBQXZDO0FBQ0gsVyxDQUVEO0FBQ0E7QUFDQTs7Ozs7UUFuSjBCbkYsUzs7Ozs7aUJBSVYsSTs7Ozs7OztpQkFLQSxJOzs7Ozs7O2lCQUtILEk7Ozs7Ozs7aUJBS1MsSSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IF9kZWNvcmF0b3IsIENvbXBvbmVudCwgTm9kZSwgRXZlbnRUb3VjaCwgQm94Q29sbGlkZXJDb21wb25lbnQsIFZlYzMsIGxvYWRlciwgUHJlZmFiLCBpbnN0YW50aWF0ZSB9IGZyb20gJ2NjJztcclxuaW1wb3J0IHsgTWFwTWdyIH0gZnJvbSAnLi9NYXBNZ3InO1xyXG5pbXBvcnQgeyBDYXJNZ3IgfSBmcm9tICcuL0Nhck1ncic7XHJcbmltcG9ydCB7IEF1ZGlvTWdyIH0gZnJvbSAnLi9BdWRpb01ncic7XHJcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4uL2RhdGEvQ29uc3RhbnRzJztcclxuaW1wb3J0IHsgQ3VzdG9tRXZlbnRMaXN0ZW5lciB9IGZyb20gJy4uL2RhdGEvQ3VzdG9tRXZlbnRMaXN0ZW5lcic7XHJcbmltcG9ydCB7IFVJTWdyIH0gZnJvbSAnLi4vdWkvVUlNZ3InO1xyXG5pbXBvcnQgeyBSdW5UaW1lRGF0YSwgUGxheWVyRGF0YSB9IGZyb20gJy4uL2RhdGEvR2FtZURhdGEnO1xyXG5pbXBvcnQgeyBMb2FkaW5nVUkgfSBmcm9tICcuLi91aS9Mb2FkaW5nVUknO1xyXG5pbXBvcnQgeyBDb25maWdNZ3IgfSBmcm9tICcuLi9kYXRhL0NvbmZpZ01ncic7XHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IF9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzcygnR2FtZUN0cmwnKVxyXG5leHBvcnQgY2xhc3MgR2FtZUN0cmwgZXh0ZW5kcyBDb21wb25lbnQge1xyXG4gICAgQHByb3BlcnR5KHtcclxuICAgICAgICB0eXBlOk1hcE1ncixcclxuICAgIH0pXHJcbiAgICBtYXBNZ3I6TWFwTWdyID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoe1xyXG4gICAgICAgIHR5cGU6Q2FyTWdyLFxyXG4gICAgfSlcclxuICAgIGNhck1ncjpDYXJNZ3IgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7XHJcbiAgICAgICAgdHlwZTpOb2RlLFxyXG4gICAgfSlcclxuICAgIGdyb3VwOk5vZGUgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7XHJcbiAgICAgICAgdHlwZTpMb2FkaW5nVUlcclxuICAgIH0pXHJcbiAgICBMb2FkaW5nVUk6TG9hZGluZ1VJID0gbnVsbDtcclxuXHJcblxyXG4gICAgcHJpdmF0ZSBwcm9ncmVzcz01O1xyXG4gICAgLy9wcml2YXRlIGxldmVsPTE7XHJcblxyXG4gICAgcHJpdmF0ZSBydW5UaW1lRGF0YTpSdW5UaW1lRGF0YSA9IG51bGw7XHJcblxyXG5cclxuICAgIHB1YmxpYyBvbkxvYWQoKXtcclxuICAgICAgICAvL3RoaXMucmVzZXQoKTtcclxuICAgICAgICB0aGlzLnJ1blRpbWVEYXRhID0gUnVuVGltZURhdGEuaW5zdGFuY2UoKTtcclxuICAgICAgICBDb25maWdNZ3IuaW5zdGFuY2UoKS5pbml0KCk7XHJcbiAgICAgICAgUGxheWVyRGF0YS5pbnN0YW5jZSgpLmxvYWRGb3JtQ2FjaGUoKTtcclxuICAgICAgICB0aGlzLmxvYWRNYXAoKTtcclxuICAgICAgICBjb25zdCBjb2xsaWRlcj10aGlzLmdyb3VwLmdldENvbXBvbmVudChCb3hDb2xsaWRlckNvbXBvbmVudCk7XHJcbiAgICAgICAgY29sbGlkZXIuc2V0R3JvdXAoQ29uc3RhbnRzLkNhckdyb3VwLk5PUk1BTCk7XHJcbiAgICAgICAgY29sbGlkZXIuc2V0TWFzaygtMSk7XHJcbiAgICAgICAgY2MuZGVidWcuc2V0RGlzcGxheVN0YXRzKGZhbHNlKTtcclxuICAgIH1cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgICAgIFVJTWdyLnNob3dEaWFsb2coQ29uc3RhbnRzLlVJUGFnZS5tYWluVUkpO1xyXG5cclxuICAgICAgICB0aGlzLm5vZGUub24oTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsdGhpcy50b3VjaFN0YXJ0LHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihOb2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsdGhpcy50b3VjaEVuZCx0aGlzKTtcclxuXHJcbiAgICAgICAgQ3VzdG9tRXZlbnRMaXN0ZW5lci5vbihDb25zdGFudHMuRXZlbnROYW1lLkdBTUVTVEFSVCx0aGlzLmdhbWVTdGFydCx0aGlzKTtcclxuICAgICAgICBDdXN0b21FdmVudExpc3RlbmVyLm9uKENvbnN0YW50cy5FdmVudE5hbWUuR0FNRU9WRVIsdGhpcy5nYW1lT3Zlcix0aGlzKTtcclxuICAgICAgICBDdXN0b21FdmVudExpc3RlbmVyLm9uKENvbnN0YW50cy5FdmVudE5hbWUuTkVXTEVWRUwsdGhpcy5uZXdMZXZlbCx0aGlzKTtcclxuXHJcbiAgICAgICAgQXVkaW9NZ3IucGxheU11c2ljKENvbnN0YW50cy5BdWRpb0ZpbGVzLkJHKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2FtZVN0YXJ0KCl7XHJcbiAgICAgICAgVUlNZ3IuaGlkZURpYWxvZyhDb25zdGFudHMuVUlQYWdlLm1haW5VSSk7XHJcbiAgICAgICAgVUlNZ3Iuc2hvd0RpYWxvZyhDb25zdGFudHMuVUlQYWdlLmdhbWVVSSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdhbWVPdmVyKCl7XHJcbiAgICAgICAgVUlNZ3IuaGlkZURpYWxvZyhDb25zdGFudHMuVUlQYWdlLmdhbWVVSSk7XHJcbiAgICAgICAgVUlNZ3Iuc2hvd0RpYWxvZyhDb25zdGFudHMuVUlQYWdlLnJlc3VsdFVJKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgbmV3TGV2ZWwoKXtcclxuICAgICAgICBVSU1nci5oaWRlRGlhbG9nKENvbnN0YW50cy5VSVBhZ2UucmVzdWx0VUkpO1xyXG4gICAgICAgIFVJTWdyLnNob3dEaWFsb2coQ29uc3RhbnRzLlVJUGFnZS5tYWluVUkpO1xyXG4gICAgICAgIGlmKFJ1blRpbWVEYXRhLmluc3RhbmNlKCkuY3VyclByb2dyZXNzPT09UnVuVGltZURhdGEuaW5zdGFuY2UoKS5tYXhQcm9ncmVzcyl7XHJcbiAgICAgICAgICAgIHRoaXMubWFwTWdyLnJlY3ljbGUoKTtcclxuICAgICAgICAgICAgLy90aGlzLnJlc2V0KCk7XHJcbiAgICAgICAgICAgIHRoaXMudW5zY2hlZHVsZSh0aGlzLmxvYWRNYXApO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZSh0aGlzLmxvYWRNYXAsMC4wMSlcclxuICAgICAgICAgICAgLy90aGlzLmxvYWRNYXAoMSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2VcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHRoaXMucmVzZXQoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSB0b3VjaFN0YXJ0KHRvdWNoOlRvdWNoLGV2ZW50OkV2ZW50VG91Y2gpXHJcbiAgICB7XHJcbiAgICAgICAgdGhpcy5jYXJNZ3IuY29udHJvbE1vdmluZyh0cnVlKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgdG91Y2hFbmQodG91Y2g6VG91Y2gsZXZlbnQ6RXZlbnRUb3VjaClcclxuICAgIHtcclxuICAgICAgICB0aGlzLmNhck1nci5jb250cm9sTW92aW5nKGZhbHNlKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIHJlc2V0KCl7XHJcbiAgICAgICAgdGhpcy5tYXBNZ3IucmVzZXRNYXAoKTtcclxuICAgICAgICB0aGlzLmNhck1nci5yZXNldCh0aGlzLm1hcE1nci5jdXJyUGF0aCk7XHJcbiAgICAgICAgdGhpcy5ydW5UaW1lRGF0YS5tYXhQcm9ncmVzcyA9IHRoaXMubWFwTWdyLm1heFByb2dyZXNzO1xyXG4gICAgICAgIHRoaXMucnVuVGltZURhdGEuY3VyclByb2dyZXNzID0gMDtcclxuICAgICAgICB0aGlzLnJ1blRpbWVEYXRhLmlzVGFrZU92ZXIgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMucnVuVGltZURhdGEubW9uZXkgPSAwO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgbG9hZE1hcChjYj86RnVuY3Rpb24pe1xyXG4gICAgICAgIHRoaXMuTG9hZGluZ1VJLnNob3coKTtcclxuICAgICAgICBsZXQgbWFwID0gJ21hcC9tYXAnO1xyXG4gICAgICAgIGxldCBsZXZlbD10aGlzLnJ1blRpbWVEYXRhLmN1cnJMZXZlbDtcclxuICAgICAgICBpZihsZXZlbD5Db25zdGFudHMuTWF4TGV2ZWwpe1xyXG4gICAgICAgICAgICBsZXZlbD1NYXRoLmNlaWwoTWF0aC5yYW5kb20oKSpDb25zdGFudHMuTWF4TGV2ZWwpO1xyXG4gICAgICAgICAgICBpZihsZXZlbDwxKXtsZXZlbD0xfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYobGV2ZWw+PTEwMCl7XHJcbiAgICAgICAgICAgIG1hcCArPWAke2xldmVsfWA7XHJcbiAgICAgICAgfWVsc2UgaWYobGV2ZWw+PTEwKXtcclxuICAgICAgICAgICAgbWFwICs9YDEke2xldmVsfWBcclxuICAgICAgICB9ZWxzZSBpZihsZXZlbD4wKXtcclxuICAgICAgICAgICAgbWFwICs9YDEwJHtsZXZlbH1gXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMucHJvZ3Jlc3MgPSA1O1xyXG4gICAgICAgIHRoaXMudW5zY2hlZHVsZSh0aGlzLmxvYWRpbmdTY2hlZHVsZSk7XHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UodGhpcy5sb2FkaW5nU2NoZWR1bGUsMC4yKTtcclxuICAgICAgICAvL2NvbnNvbGUubG9nKFwibWFwIGxvYWQgc3RhcnQ6XCIrbWFwKTtcclxuICAgICAgICBsb2FkZXIubG9hZFJlcyhtYXAsUHJlZmFiLChlcnI6YW55LHByZWZhYjpQcmVmYWIpPT57XHJcbiAgICAgICAgICAgIGlmKGVycil7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oZXJyKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgY29uc3QgbWFwTm9kZT1pbnN0YW50aWF0ZShwcmVmYWIpIGFzIE5vZGU7XHJcbiAgICAgICAgICAgIG1hcE5vZGUucGFyZW50ID0gdGhpcy5tYXBNZ3Iubm9kZTtcclxuICAgICAgICAgICAgLy8gaWYoY2Ipe1xyXG4gICAgICAgICAgICAvLyAgICAgY2IoKTtcclxuICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgICAgICB0aGlzLnByb2dyZXNzPTA7XHJcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJtYXAgbG9hZCBkb25lXCIpO1xyXG4gICAgICAgICAgICB0aGlzLnJlc2V0KCk7XHJcbiAgICAgICAgICAgIHRoaXMuTG9hZGluZ1VJLmZpbmlzaExvYWRpbmcoKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGxvYWRpbmdTY2hlZHVsZSgpe1xyXG4gICAgICAgIGlmKHRoaXMucHJvZ3Jlc3M8MCl7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5wcm9ncmVzcyAtLTtcclxuICAgICAgICBDdXN0b21FdmVudExpc3RlbmVyLmRpc3BhdGNoRXZlbnQoQ29uc3RhbnRzLkV2ZW50TmFtZS5VUERBVEVQUk9HUkVTUyw0MC81KTtcclxuICAgICAgICB0aGlzLnVuc2NoZWR1bGUodGhpcy5sb2FkaW5nU2NoZWR1bGUpO1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKHRoaXMubG9hZGluZ1NjaGVkdWxlLDAuMik7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gdXBkYXRlIChkZWx0YVRpbWU6IG51bWJlcikge1xyXG4gICAgLy8gICAgIC8vIFlvdXIgdXBkYXRlIGZ1bmN0aW9uIGdvZXMgaGVyZS5cclxuICAgIC8vIH1cclxufVxyXG4iXX0=