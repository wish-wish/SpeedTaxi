System.register(["cc", "code-quality:cr", "../data/GameData.js", "../data/CustomEventListener.js", "../data/Constants.js"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Component, SpriteFrame, LabelComponent, SpriteComponent, RunTimeData, PlayerData, CustomEventListener, Constants, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _temp, _crd, ccclass, property, ResultUI;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfRunTimeData(extras) {
    _reporterNs.report("RunTimeData", "../data/GameData", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlayerData(extras) {
    _reporterNs.report("PlayerData", "../data/GameData", _context.meta, extras);
  }

  function _reportPossibleCrUseOfCustomEventListener(extras) {
    _reporterNs.report("CustomEventListener", "../data/CustomEventListener", _context.meta, extras);
  }

  function _reportPossibleCrUseOfConstants(extras) {
    _reporterNs.report("Constants", "../data/Constants", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _dec2: void 0,
    _dec3: void 0,
    _dec4: void 0,
    _dec5: void 0,
    _dec6: void 0,
    _dec7: void 0,
    _dec8: void 0,
    _dec9: void 0,
    _dec10: void 0,
    _dec11: void 0,
    _dec12: void 0,
    _dec13: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _descriptor2: void 0,
    _descriptor3: void 0,
    _descriptor4: void 0,
    _descriptor5: void 0,
    _descriptor6: void 0,
    _descriptor7: void 0,
    _descriptor8: void 0,
    _descriptor9: void 0,
    _descriptor10: void 0,
    _descriptor11: void 0,
    _descriptor12: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      SpriteFrame = _cc.SpriteFrame;
      LabelComponent = _cc.LabelComponent;
      SpriteComponent = _cc.SpriteComponent;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_dataGameDataJs) {
      RunTimeData = _dataGameDataJs.RunTimeData;
      PlayerData = _dataGameDataJs.PlayerData;
    }, function (_dataCustomEventListenerJs) {
      CustomEventListener = _dataCustomEventListenerJs.CustomEventListener;
    }, function (_dataConstantsJs) {
      Constants = _dataConstantsJs.Constants;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "307d2AMrK5PGKvyG965uc6N", "ResultUI", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("ResultUI", ResultUI = (_dec = ccclass('ResultUI'), _dec2 = property({
        type: LabelComponent,
        displayOrder: 1
      }), _dec3 = property({
        type: LabelComponent,
        displayOrder: 2
      }), _dec4 = property({
        type: SpriteComponent,
        displayOrder: 3
      }), _dec5 = property({
        type: SpriteComponent,
        displayOrder: 4
      }), _dec6 = property({
        type: SpriteFrame,
        displayOrder: 5
      }), _dec7 = property({
        type: SpriteFrame,
        displayOrder: 6
      }), _dec8 = property({
        type: [SpriteComponent],
        displayOrder: 7
      }), _dec9 = property({
        type: SpriteFrame,
        displayOrder: 8
      }), _dec10 = property({
        type: SpriteFrame,
        displayOrder: 9
      }), _dec11 = property({
        type: SpriteFrame,
        displayOrder: 10
      }), _dec12 = property({
        type: LabelComponent,
        displayOrder: 11
      }), _dec13 = property({
        type: LabelComponent,
        displayOrder: 12
      }), _dec(_class = (_class2 = (_temp = /*#__PURE__*/function (_Component) {
        _inherits(ResultUI, _Component);

        function ResultUI() {
          var _getPrototypeOf2;

          var _this;

          _classCallCheck(this, ResultUI);

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(ResultUI)).call.apply(_getPrototypeOf2, [this].concat(args)));

          _initializerDefineProperty(_this, "targetLevel", _descriptor, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "srcLevel", _descriptor2, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "targetSP", _descriptor3, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "srcSP", _descriptor4, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "LevelFinished", _descriptor5, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "LevelUnFinished", _descriptor6, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "progress", _descriptor7, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "progress1", _descriptor8, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "progress2", _descriptor9, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "progress3", _descriptor10, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "progressLabel", _descriptor11, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "moneyLabel", _descriptor12, _assertThisInitialized(_this));

          return _this;
        }

        _createClass(ResultUI, [{
          key: "show",
          value: function show() {
            var runtimeData = (_crd && RunTimeData === void 0 ? (_reportPossibleCrUseOfRunTimeData({
              error: Error()
            }), RunTimeData) : RunTimeData).instance();
            var maxProgress = runtimeData.maxProgress;
            var currProgress = runtimeData.currProgress;
            var index = 0;

            for (var i = 0; i < this.progress.length; i++) {
              var elem = this.progress[i];

              if (i >= maxProgress) {
                elem.node.active = false;
              } else {
                elem.node.active = true; //elem.spriteFrame = this.progress3;

                index = maxProgress - 1 - i;

                if (index >= currProgress) {
                  //elem.spriteFrame = (index===currProgress&&!runtimeData.isTakeOver)?this.progress2:this.progress3;//当前进行中，否则未开始
                  var sp = index === currProgress && !runtimeData.isTakeOver ? this.progress2 : this.progress3;
                  elem.spriteFrame = sp;
                } else {
                  elem.spriteFrame = this.progress1;
                }
              }
            }

            this.srcSP.spriteFrame = this.LevelFinished;
            this.targetSP.spriteFrame = currProgress === maxProgress ? this.LevelFinished : this.LevelUnFinished;
            this.progressLabel.string = "\u4F60\u5B8C\u6210\u4E86".concat(currProgress, "\u4E2A\u8BA2\u5355");
            this.srcLevel.string = "".concat(runtimeData.currLevel);
            this.targetLevel.string = "".concat(runtimeData.currLevel + 1);
            this.moneyLabel.string = "".concat(runtimeData.money);
          }
        }, {
          key: "hide",
          value: function hide() {}
        }, {
          key: "clickBtnNormal",
          value: function clickBtnNormal() {
            if ((_crd && RunTimeData === void 0 ? (_reportPossibleCrUseOfRunTimeData({
              error: Error()
            }), RunTimeData) : RunTimeData).instance().currProgress === (_crd && RunTimeData === void 0 ? (_reportPossibleCrUseOfRunTimeData({
              error: Error()
            }), RunTimeData) : RunTimeData).instance().maxProgress) {
              (_crd && PlayerData === void 0 ? (_reportPossibleCrUseOfPlayerData({
                error: Error()
              }), PlayerData) : PlayerData).instance().passLevel((_crd && RunTimeData === void 0 ? (_reportPossibleCrUseOfRunTimeData({
                error: Error()
              }), RunTimeData) : RunTimeData).instance().money);
            } else {
              (_crd && PlayerData === void 0 ? (_reportPossibleCrUseOfPlayerData({
                error: Error()
              }), PlayerData) : PlayerData).instance().earnMoney((_crd && RunTimeData === void 0 ? (_reportPossibleCrUseOfRunTimeData({
                error: Error()
              }), RunTimeData) : RunTimeData).instance().money);
            }

            (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
              error: Error()
            }), CustomEventListener) : CustomEventListener).dispatchEvent((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).EventName.NEWLEVEL);
          }
        }, {
          key: "start",
          value: function start() {} // Your initialization goes here.
          // update (deltaTime: number) {
          //     // Your update function goes here.
          // }

        }]);

        return ResultUI;
      }(Component), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "targetLevel", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "srcLevel", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "targetSP", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "srcSP", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "LevelFinished", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "LevelUnFinished", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "progress", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "progress1", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "progress2", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "progress3", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "progressLabel", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "moneyLabel", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ3JlYXRvci9TcGVlZFRheGkvYXNzZXRzL3NjcmlwdC91aS9SZXN1bHRVSS50cyJdLCJuYW1lcyI6WyJfZGVjb3JhdG9yIiwiQ29tcG9uZW50IiwiU3ByaXRlRnJhbWUiLCJMYWJlbENvbXBvbmVudCIsIlNwcml0ZUNvbXBvbmVudCIsIlJ1blRpbWVEYXRhIiwiUGxheWVyRGF0YSIsIkN1c3RvbUV2ZW50TGlzdGVuZXIiLCJDb25zdGFudHMiLCJjY2NsYXNzIiwicHJvcGVydHkiLCJSZXN1bHRVSSIsInR5cGUiLCJkaXNwbGF5T3JkZXIiLCJydW50aW1lRGF0YSIsImluc3RhbmNlIiwibWF4UHJvZ3Jlc3MiLCJjdXJyUHJvZ3Jlc3MiLCJpbmRleCIsImkiLCJwcm9ncmVzcyIsImxlbmd0aCIsImVsZW0iLCJub2RlIiwiYWN0aXZlIiwic3AiLCJpc1Rha2VPdmVyIiwicHJvZ3Jlc3MyIiwicHJvZ3Jlc3MzIiwic3ByaXRlRnJhbWUiLCJwcm9ncmVzczEiLCJzcmNTUCIsIkxldmVsRmluaXNoZWQiLCJ0YXJnZXRTUCIsIkxldmVsVW5GaW5pc2hlZCIsInByb2dyZXNzTGFiZWwiLCJzdHJpbmciLCJzcmNMZXZlbCIsImN1cnJMZXZlbCIsInRhcmdldExldmVsIiwibW9uZXlMYWJlbCIsIm1vbmV5IiwicGFzc0xldmVsIiwiZWFybk1vbmV5IiwiZGlzcGF0Y2hFdmVudCIsIkV2ZW50TmFtZSIsIk5FV0xFVkVMIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQVNBLE1BQUFBLFUsT0FBQUEsVTtBQUFZQyxNQUFBQSxTLE9BQUFBLFM7QUFBaUJDLE1BQUFBLFcsT0FBQUEsVztBQUFhQyxNQUFBQSxjLE9BQUFBLGM7QUFBZ0JDLE1BQUFBLGUsT0FBQUEsZTs7OztBQUMxREMsTUFBQUEsVyxtQkFBQUEsVztBQUFhQyxNQUFBQSxVLG1CQUFBQSxVOztBQUNiQyxNQUFBQSxtQiw4QkFBQUEsbUI7O0FBQ0FDLE1BQUFBLFMsb0JBQUFBLFM7Ozs7OztBQUNEQyxNQUFBQSxPLEdBQXNCVCxVLENBQXRCUyxPO0FBQVNDLE1BQUFBLFEsR0FBYVYsVSxDQUFiVSxROzswQkFHSkMsUSxXQURaRixPQUFPLENBQUMsVUFBRCxDLFVBRUhDLFFBQVEsQ0FBQztBQUNORSxRQUFBQSxJQUFJLEVBQUNULGNBREM7QUFFTlUsUUFBQUEsWUFBWSxFQUFDO0FBRlAsT0FBRCxDLFVBTVJILFFBQVEsQ0FBQztBQUNORSxRQUFBQSxJQUFJLEVBQUNULGNBREM7QUFFTlUsUUFBQUEsWUFBWSxFQUFDO0FBRlAsT0FBRCxDLFVBTVJILFFBQVEsQ0FBQztBQUNORSxRQUFBQSxJQUFJLEVBQUNSLGVBREM7QUFFTlMsUUFBQUEsWUFBWSxFQUFDO0FBRlAsT0FBRCxDLFVBTVJILFFBQVEsQ0FBQztBQUNORSxRQUFBQSxJQUFJLEVBQUNSLGVBREM7QUFFTlMsUUFBQUEsWUFBWSxFQUFDO0FBRlAsT0FBRCxDLFVBTVJILFFBQVEsQ0FBQztBQUNORSxRQUFBQSxJQUFJLEVBQUNWLFdBREM7QUFFTlcsUUFBQUEsWUFBWSxFQUFDO0FBRlAsT0FBRCxDLFVBTVJILFFBQVEsQ0FBQztBQUNORSxRQUFBQSxJQUFJLEVBQUNWLFdBREM7QUFFTlcsUUFBQUEsWUFBWSxFQUFDO0FBRlAsT0FBRCxDLFVBTVJILFFBQVEsQ0FBQztBQUNORSxRQUFBQSxJQUFJLEVBQUMsQ0FBQ1IsZUFBRCxDQURDO0FBRU5TLFFBQUFBLFlBQVksRUFBQztBQUZQLE9BQUQsQyxVQU1SSCxRQUFRLENBQUM7QUFDTkUsUUFBQUEsSUFBSSxFQUFDVixXQURDO0FBRU5XLFFBQUFBLFlBQVksRUFBQztBQUZQLE9BQUQsQyxXQU1SSCxRQUFRLENBQUM7QUFDTkUsUUFBQUEsSUFBSSxFQUFDVixXQURDO0FBRU5XLFFBQUFBLFlBQVksRUFBQztBQUZQLE9BQUQsQyxXQU1SSCxRQUFRLENBQUM7QUFDTkUsUUFBQUEsSUFBSSxFQUFDVixXQURDO0FBRU5XLFFBQUFBLFlBQVksRUFBQztBQUZQLE9BQUQsQyxXQU1SSCxRQUFRLENBQUM7QUFDTkUsUUFBQUEsSUFBSSxFQUFDVCxjQURDO0FBRU5VLFFBQUFBLFlBQVksRUFBQztBQUZQLE9BQUQsQyxXQU1SSCxRQUFRLENBQUM7QUFDTkUsUUFBQUEsSUFBSSxFQUFDVCxjQURDO0FBRU5VLFFBQUFBLFlBQVksRUFBQztBQUZQLE9BQUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQU9JO0FBQ1QsZ0JBQU1DLFdBQVcsR0FBQztBQUFBO0FBQUEsNENBQVlDLFFBQVosRUFBbEI7QUFDQSxnQkFBTUMsV0FBVyxHQUFDRixXQUFXLENBQUNFLFdBQTlCO0FBQ0EsZ0JBQU1DLFlBQVksR0FBQ0gsV0FBVyxDQUFDRyxZQUEvQjtBQUNBLGdCQUFJQyxLQUFLLEdBQUMsQ0FBVjs7QUFDQSxpQkFBSSxJQUFJQyxDQUFDLEdBQUMsQ0FBVixFQUFZQSxDQUFDLEdBQUMsS0FBS0MsUUFBTCxDQUFjQyxNQUE1QixFQUFtQ0YsQ0FBQyxFQUFwQyxFQUF1QztBQUNuQyxrQkFBTUcsSUFBSSxHQUFDLEtBQUtGLFFBQUwsQ0FBY0QsQ0FBZCxDQUFYOztBQUNBLGtCQUFHQSxDQUFDLElBQUVILFdBQU4sRUFBa0I7QUFDZE0sZ0JBQUFBLElBQUksQ0FBQ0MsSUFBTCxDQUFVQyxNQUFWLEdBQW1CLEtBQW5CO0FBQ0gsZUFGRCxNQUdBO0FBQ0lGLGdCQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVUMsTUFBVixHQUFtQixJQUFuQixDQURKLENBRUk7O0FBQ0FOLGdCQUFBQSxLQUFLLEdBQUdGLFdBQVcsR0FBRyxDQUFkLEdBQWtCRyxDQUExQjs7QUFDQSxvQkFBR0QsS0FBSyxJQUFFRCxZQUFWLEVBQXVCO0FBQ25CO0FBRUEsc0JBQU1RLEVBQUUsR0FBRVAsS0FBSyxLQUFLRCxZQUFWLElBQTBCLENBQUNILFdBQVcsQ0FBQ1ksVUFBeEMsR0FBc0QsS0FBS0MsU0FBM0QsR0FBdUUsS0FBS0MsU0FBckY7QUFDQU4sa0JBQUFBLElBQUksQ0FBQ08sV0FBTCxHQUFtQkosRUFBbkI7QUFDSCxpQkFMRCxNQU1BO0FBQ0lILGtCQUFBQSxJQUFJLENBQUNPLFdBQUwsR0FBbUIsS0FBS0MsU0FBeEI7QUFDSDtBQUNKO0FBQ0o7O0FBQ0QsaUJBQUtDLEtBQUwsQ0FBV0YsV0FBWCxHQUF5QixLQUFLRyxhQUE5QjtBQUNBLGlCQUFLQyxRQUFMLENBQWNKLFdBQWQsR0FBNEJaLFlBQVksS0FBR0QsV0FBZixHQUEyQixLQUFLZ0IsYUFBaEMsR0FBOEMsS0FBS0UsZUFBL0U7QUFDQSxpQkFBS0MsYUFBTCxDQUFtQkMsTUFBbkIscUNBQW1DbkIsWUFBbkM7QUFDQSxpQkFBS29CLFFBQUwsQ0FBY0QsTUFBZCxhQUEwQnRCLFdBQVcsQ0FBQ3dCLFNBQXRDO0FBQ0EsaUJBQUtDLFdBQUwsQ0FBaUJILE1BQWpCLGFBQTZCdEIsV0FBVyxDQUFDd0IsU0FBWixHQUFzQixDQUFuRDtBQUNBLGlCQUFLRSxVQUFMLENBQWdCSixNQUFoQixhQUE0QnRCLFdBQVcsQ0FBQzJCLEtBQXhDO0FBQ0g7OztpQ0FFWSxDQUVaOzs7MkNBR0Q7QUFDSSxnQkFBRztBQUFBO0FBQUEsNENBQVkxQixRQUFaLEdBQXVCRSxZQUF2QixLQUFzQztBQUFBO0FBQUEsNENBQVlGLFFBQVosR0FBdUJDLFdBQWhFLEVBQTRFO0FBQ3hFO0FBQUE7QUFBQSw0Q0FBV0QsUUFBWCxHQUFzQjJCLFNBQXRCLENBQWdDO0FBQUE7QUFBQSw4Q0FBWTNCLFFBQVosR0FBdUIwQixLQUF2RDtBQUNILGFBRkQsTUFHQTtBQUNJO0FBQUE7QUFBQSw0Q0FBVzFCLFFBQVgsR0FBc0I0QixTQUF0QixDQUFnQztBQUFBO0FBQUEsOENBQVk1QixRQUFaLEdBQXVCMEIsS0FBdkQ7QUFDSDs7QUFDRDtBQUFBO0FBQUEsNERBQW9CRyxhQUFwQixDQUFrQztBQUFBO0FBQUEsd0NBQVVDLFNBQVYsQ0FBb0JDLFFBQXREO0FBQ0g7OztrQ0FFUSxDQUVSLEMsQ0FERztBQUdKO0FBQ0E7QUFDQTs7Ozs7UUFoSTBCN0MsUzs7Ozs7aUJBS0csSTs7Ozs7OztpQkFNSCxJOzs7Ozs7O2lCQU1DLEk7Ozs7Ozs7aUJBTUgsSTs7Ozs7OztpQkFNSSxJOzs7Ozs7O2lCQU1FLEk7Ozs7Ozs7aUJBTUQsRTs7Ozs7OztpQkFNTCxJOzs7Ozs7O2lCQU1BLEk7Ozs7Ozs7aUJBTUEsSTs7Ozs7OztpQkFNTyxJOzs7Ozs7O2lCQU1ILEkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBfZGVjb3JhdG9yLCBDb21wb25lbnQsIE5vZGUsIFNwcml0ZUZyYW1lLCBMYWJlbENvbXBvbmVudCwgU3ByaXRlQ29tcG9uZW50LCBDb25zdGFudEZvcmNlIH0gZnJvbSAnY2MnO1xyXG5pbXBvcnQgeyBSdW5UaW1lRGF0YSwgUGxheWVyRGF0YSB9IGZyb20gJy4uL2RhdGEvR2FtZURhdGEnO1xyXG5pbXBvcnQgeyBDdXN0b21FdmVudExpc3RlbmVyIH0gZnJvbSAnLi4vZGF0YS9DdXN0b21FdmVudExpc3RlbmVyJztcclxuaW1wb3J0IHsgQ29uc3RhbnRzIH0gZnJvbSAnLi4vZGF0YS9Db25zdGFudHMnO1xyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBfZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3MoJ1Jlc3VsdFVJJylcclxuZXhwb3J0IGNsYXNzIFJlc3VsdFVJIGV4dGVuZHMgQ29tcG9uZW50IHtcclxuICAgIEBwcm9wZXJ0eSh7XHJcbiAgICAgICAgdHlwZTpMYWJlbENvbXBvbmVudCxcclxuICAgICAgICBkaXNwbGF5T3JkZXI6MSxcclxuICAgIH0pXHJcbiAgICB0YXJnZXRMZXZlbDpMYWJlbENvbXBvbmVudCA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KHtcclxuICAgICAgICB0eXBlOkxhYmVsQ29tcG9uZW50LFxyXG4gICAgICAgIGRpc3BsYXlPcmRlcjoyLFxyXG4gICAgfSlcclxuICAgIHNyY0xldmVsOkxhYmVsQ29tcG9uZW50ID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoe1xyXG4gICAgICAgIHR5cGU6U3ByaXRlQ29tcG9uZW50LFxyXG4gICAgICAgIGRpc3BsYXlPcmRlcjozLFxyXG4gICAgfSlcclxuICAgIHRhcmdldFNQOlNwcml0ZUNvbXBvbmVudCA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KHtcclxuICAgICAgICB0eXBlOlNwcml0ZUNvbXBvbmVudCxcclxuICAgICAgICBkaXNwbGF5T3JkZXI6NCxcclxuICAgIH0pXHJcbiAgICBzcmNTUDpTcHJpdGVDb21wb25lbnQgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7XHJcbiAgICAgICAgdHlwZTpTcHJpdGVGcmFtZSxcclxuICAgICAgICBkaXNwbGF5T3JkZXI6NSxcclxuICAgIH0pXHJcbiAgICBMZXZlbEZpbmlzaGVkOlNwcml0ZUZyYW1lID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoe1xyXG4gICAgICAgIHR5cGU6U3ByaXRlRnJhbWUsXHJcbiAgICAgICAgZGlzcGxheU9yZGVyOjYsXHJcbiAgICB9KVxyXG4gICAgTGV2ZWxVbkZpbmlzaGVkOlNwcml0ZUZyYW1lID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoe1xyXG4gICAgICAgIHR5cGU6W1Nwcml0ZUNvbXBvbmVudF0sXHJcbiAgICAgICAgZGlzcGxheU9yZGVyOjcsXHJcbiAgICB9KVxyXG4gICAgcHJvZ3Jlc3M6U3ByaXRlQ29tcG9uZW50W10gPSBbXTtcclxuXHJcbiAgICBAcHJvcGVydHkoe1xyXG4gICAgICAgIHR5cGU6U3ByaXRlRnJhbWUsXHJcbiAgICAgICAgZGlzcGxheU9yZGVyOjgsXHJcbiAgICB9KVxyXG4gICAgcHJvZ3Jlc3MxOlNwcml0ZUZyYW1lID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoe1xyXG4gICAgICAgIHR5cGU6U3ByaXRlRnJhbWUsXHJcbiAgICAgICAgZGlzcGxheU9yZGVyOjksXHJcbiAgICB9KVxyXG4gICAgcHJvZ3Jlc3MyOlNwcml0ZUZyYW1lID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoe1xyXG4gICAgICAgIHR5cGU6U3ByaXRlRnJhbWUsXHJcbiAgICAgICAgZGlzcGxheU9yZGVyOjEwLFxyXG4gICAgfSlcclxuICAgIHByb2dyZXNzMzpTcHJpdGVGcmFtZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KHtcclxuICAgICAgICB0eXBlOkxhYmVsQ29tcG9uZW50LFxyXG4gICAgICAgIGRpc3BsYXlPcmRlcjoxMSxcclxuICAgIH0pXHJcbiAgICBwcm9ncmVzc0xhYmVsOkxhYmVsQ29tcG9uZW50ID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoe1xyXG4gICAgICAgIHR5cGU6TGFiZWxDb21wb25lbnQsXHJcbiAgICAgICAgZGlzcGxheU9yZGVyOjEyLFxyXG4gICAgfSlcclxuICAgIG1vbmV5TGFiZWw6TGFiZWxDb21wb25lbnQgPSBudWxsO1xyXG5cclxuXHJcbiAgICBwdWJsaWMgc2hvdygpe1xyXG4gICAgICAgIGNvbnN0IHJ1bnRpbWVEYXRhPVJ1blRpbWVEYXRhLmluc3RhbmNlKCk7XHJcbiAgICAgICAgY29uc3QgbWF4UHJvZ3Jlc3M9cnVudGltZURhdGEubWF4UHJvZ3Jlc3M7XHJcbiAgICAgICAgY29uc3QgY3VyclByb2dyZXNzPXJ1bnRpbWVEYXRhLmN1cnJQcm9ncmVzcztcclxuICAgICAgICBsZXQgaW5kZXg9MDtcclxuICAgICAgICBmb3IobGV0IGk9MDtpPHRoaXMucHJvZ3Jlc3MubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIGNvbnN0IGVsZW09dGhpcy5wcm9ncmVzc1tpXTtcclxuICAgICAgICAgICAgaWYoaT49bWF4UHJvZ3Jlc3Mpe1xyXG4gICAgICAgICAgICAgICAgZWxlbS5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9ZWxzZVxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBlbGVtLm5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIC8vZWxlbS5zcHJpdGVGcmFtZSA9IHRoaXMucHJvZ3Jlc3MzO1xyXG4gICAgICAgICAgICAgICAgaW5kZXggPSBtYXhQcm9ncmVzcyAtIDEgLSBpO1xyXG4gICAgICAgICAgICAgICAgaWYoaW5kZXg+PWN1cnJQcm9ncmVzcyl7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9lbGVtLnNwcml0ZUZyYW1lID0gKGluZGV4PT09Y3VyclByb2dyZXNzJiYhcnVudGltZURhdGEuaXNUYWtlT3Zlcik/dGhpcy5wcm9ncmVzczI6dGhpcy5wcm9ncmVzczM7Ly/lvZPliY3ov5vooYzkuK3vvIzlkKbliJnmnKrlvIDlp4tcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3A9KGluZGV4ID09PSBjdXJyUHJvZ3Jlc3MgJiYgIXJ1bnRpbWVEYXRhLmlzVGFrZU92ZXIpID8gdGhpcy5wcm9ncmVzczIgOiB0aGlzLnByb2dyZXNzMztcclxuICAgICAgICAgICAgICAgICAgICBlbGVtLnNwcml0ZUZyYW1lID0gc3A7XHJcbiAgICAgICAgICAgICAgICB9ZWxzZVxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIGVsZW0uc3ByaXRlRnJhbWUgPSB0aGlzLnByb2dyZXNzMTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnNyY1NQLnNwcml0ZUZyYW1lID0gdGhpcy5MZXZlbEZpbmlzaGVkO1xyXG4gICAgICAgIHRoaXMudGFyZ2V0U1Auc3ByaXRlRnJhbWUgPSBjdXJyUHJvZ3Jlc3M9PT1tYXhQcm9ncmVzcz90aGlzLkxldmVsRmluaXNoZWQ6dGhpcy5MZXZlbFVuRmluaXNoZWQ7XHJcbiAgICAgICAgdGhpcy5wcm9ncmVzc0xhYmVsLnN0cmluZyA9IGDkvaDlrozmiJDkuoYke2N1cnJQcm9ncmVzc33kuKrorqLljZVgO1xyXG4gICAgICAgIHRoaXMuc3JjTGV2ZWwuc3RyaW5nID0gYCR7cnVudGltZURhdGEuY3VyckxldmVsfWA7XHJcbiAgICAgICAgdGhpcy50YXJnZXRMZXZlbC5zdHJpbmcgPSBgJHtydW50aW1lRGF0YS5jdXJyTGV2ZWwrMX1gO1xyXG4gICAgICAgIHRoaXMubW9uZXlMYWJlbC5zdHJpbmcgPSBgJHtydW50aW1lRGF0YS5tb25leX1gO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBoaWRlKCl7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBjbGlja0J0bk5vcm1hbCgpXHJcbiAgICB7XHJcbiAgICAgICAgaWYoUnVuVGltZURhdGEuaW5zdGFuY2UoKS5jdXJyUHJvZ3Jlc3M9PT1SdW5UaW1lRGF0YS5pbnN0YW5jZSgpLm1heFByb2dyZXNzKXtcclxuICAgICAgICAgICAgUGxheWVyRGF0YS5pbnN0YW5jZSgpLnBhc3NMZXZlbChSdW5UaW1lRGF0YS5pbnN0YW5jZSgpLm1vbmV5KTtcclxuICAgICAgICB9ZWxzZVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgUGxheWVyRGF0YS5pbnN0YW5jZSgpLmVhcm5Nb25leShSdW5UaW1lRGF0YS5pbnN0YW5jZSgpLm1vbmV5KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgQ3VzdG9tRXZlbnRMaXN0ZW5lci5kaXNwYXRjaEV2ZW50KENvbnN0YW50cy5FdmVudE5hbWUuTkVXTEVWRUwpO1xyXG4gICAgfVxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICAvLyBZb3VyIGluaXRpYWxpemF0aW9uIGdvZXMgaGVyZS5cclxuICAgIH1cclxuXHJcbiAgICAvLyB1cGRhdGUgKGRlbHRhVGltZTogbnVtYmVyKSB7XHJcbiAgICAvLyAgICAgLy8gWW91ciB1cGRhdGUgZnVuY3Rpb24gZ29lcyBoZXJlLlxyXG4gICAgLy8gfVxyXG59XHJcbiJdfQ==