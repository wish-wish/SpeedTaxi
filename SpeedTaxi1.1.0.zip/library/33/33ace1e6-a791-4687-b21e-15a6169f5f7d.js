System.register(["cc", "code-quality:cr", "./GameMap.js"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Component, GameMap, _dec, _class, _temp, _crd, ccclass, property, MapMgr;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _reportPossibleCrUseOfGameMap(extras) {
    _reporterNs.report("GameMap", "./GameMap", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _class: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_GameMapJs) {
      GameMap = _GameMapJs.GameMap;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "33aceHmp5FGh7IeFaYWn199", "MapMgr", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("MapMgr", MapMgr = (_dec = ccclass('MapMgr'), _dec(_class = (_temp = /*#__PURE__*/function (_Component) {
        _inherits(MapMgr, _Component);

        function MapMgr() {
          var _getPrototypeOf2;

          var _this;

          _classCallCheck(this, MapMgr);

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(MapMgr)).call.apply(_getPrototypeOf2, [this].concat(args)));
          _this.currPath = [];
          _this.maxProgress = 0;
          _this.currMap = null;
          return _this;
        }

        _createClass(MapMgr, [{
          key: "resetMap",
          value: function resetMap() {
            this.currMap = this.node.children[0];
            var currMap = this.node.children[0].getComponent(_crd && GameMap === void 0 ? (_reportPossibleCrUseOfGameMap({
              error: Error()
            }), GameMap) : GameMap);
            this.currPath = currMap.path;
            this.maxProgress = currMap.maxProgress;
          }
        }, {
          key: "recycle",
          value: function recycle() {
            if (this.currMap) {
              //console.log("map destory");
              this.currMap.destroy();
              this.currMap = null;
            }
          }
        }, {
          key: "start",
          value: function start() {} // Your initialization goes here.
          // update (deltaTime: number) {
          //     // Your update function goes here.
          // }

        }]);

        return MapMgr;
      }(Component), _temp)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ3JlYXRvci9TcGVlZFRheGkvYXNzZXRzL3NjcmlwdC9nYW1lL01hcE1nci50cyJdLCJuYW1lcyI6WyJfZGVjb3JhdG9yIiwiQ29tcG9uZW50IiwiR2FtZU1hcCIsImNjY2xhc3MiLCJwcm9wZXJ0eSIsIk1hcE1nciIsImN1cnJQYXRoIiwibWF4UHJvZ3Jlc3MiLCJjdXJyTWFwIiwibm9kZSIsImNoaWxkcmVuIiwiZ2V0Q29tcG9uZW50IiwicGF0aCIsImRlc3Ryb3kiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFTQSxNQUFBQSxVLE9BQUFBLFU7QUFBWUMsTUFBQUEsUyxPQUFBQSxTOzs7O0FBQ1pDLE1BQUFBLE8sY0FBQUEsTzs7Ozs7O0FBQ0RDLE1BQUFBLE8sR0FBc0JILFUsQ0FBdEJHLE87QUFBU0MsTUFBQUEsUSxHQUFhSixVLENBQWJJLFE7O3dCQUdKQyxNLFdBRFpGLE9BQU8sQ0FBQyxRQUFELEM7Ozs7Ozs7Ozs7Ozs7OztnQkFHR0csUSxHQUFrQixFO2dCQUNsQkMsVyxHQUFjLEM7Z0JBRWJDLE8sR0FBZSxJOzs7Ozs7cUNBRU47QUFDYixpQkFBS0EsT0FBTCxHQUFlLEtBQUtDLElBQUwsQ0FBVUMsUUFBVixDQUFtQixDQUFuQixDQUFmO0FBQ0EsZ0JBQU1GLE9BQU8sR0FBRyxLQUFLQyxJQUFMLENBQVVDLFFBQVYsQ0FBbUIsQ0FBbkIsRUFBc0JDLFlBQXRCO0FBQUE7QUFBQSxtQ0FBaEI7QUFDQSxpQkFBS0wsUUFBTCxHQUFnQkUsT0FBTyxDQUFDSSxJQUF4QjtBQUNBLGlCQUFLTCxXQUFMLEdBQW1CQyxPQUFPLENBQUNELFdBQTNCO0FBQ0g7OztvQ0FFZTtBQUNaLGdCQUFHLEtBQUtDLE9BQVIsRUFBZ0I7QUFDWjtBQUNBLG1CQUFLQSxPQUFMLENBQWFLLE9BQWI7QUFDQSxtQkFBS0wsT0FBTCxHQUFlLElBQWY7QUFDSDtBQUNKOzs7a0NBRVEsQ0FFUixDLENBREc7QUFHSjtBQUNBO0FBQ0E7Ozs7O1FBNUJ3QlAsUyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IF9kZWNvcmF0b3IsIENvbXBvbmVudCwgTm9kZSB9IGZyb20gJ2NjJztcclxuaW1wb3J0IHsgR2FtZU1hcCB9IGZyb20gJy4vR2FtZU1hcCc7XHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IF9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzcygnTWFwTWdyJylcclxuZXhwb3J0IGNsYXNzIE1hcE1nciBleHRlbmRzIENvbXBvbmVudCB7XHJcbiAgICBcclxuICAgIHB1YmxpYyBjdXJyUGF0aDpOb2RlW10gPSBbXTtcclxuICAgIHB1YmxpYyBtYXhQcm9ncmVzcyA9IDA7XHJcblxyXG4gICAgcHJpdmF0ZSBjdXJyTWFwOk5vZGUgPSBudWxsO1xyXG5cclxuICAgIHB1YmxpYyByZXNldE1hcCgpe1xyXG4gICAgICAgIHRoaXMuY3Vyck1hcCA9IHRoaXMubm9kZS5jaGlsZHJlblswXTtcclxuICAgICAgICBjb25zdCBjdXJyTWFwID0gdGhpcy5ub2RlLmNoaWxkcmVuWzBdLmdldENvbXBvbmVudChHYW1lTWFwKTtcclxuICAgICAgICB0aGlzLmN1cnJQYXRoID0gY3Vyck1hcC5wYXRoO1xyXG4gICAgICAgIHRoaXMubWF4UHJvZ3Jlc3MgPSBjdXJyTWFwLm1heFByb2dyZXNzO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyByZWN5Y2xlKCl7XHJcbiAgICAgICAgaWYodGhpcy5jdXJyTWFwKXtcclxuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcIm1hcCBkZXN0b3J5XCIpO1xyXG4gICAgICAgICAgICB0aGlzLmN1cnJNYXAuZGVzdHJveSgpO1xyXG4gICAgICAgICAgICB0aGlzLmN1cnJNYXAgPSBudWxsO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgLy8gWW91ciBpbml0aWFsaXphdGlvbiBnb2VzIGhlcmUuXHJcbiAgICB9XHJcblxyXG4gICAgLy8gdXBkYXRlIChkZWx0YVRpbWU6IG51bWJlcikge1xyXG4gICAgLy8gICAgIC8vIFlvdXIgdXBkYXRlIGZ1bmN0aW9uIGdvZXMgaGVyZS5cclxuICAgIC8vIH1cclxufVxyXG4iXX0=