System.register(["cc", "code-quality:cr", "../data/CustomEventListener.js", "../data/Constants.js", "./AudioMgr.js", "../data/GameData.js"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Component, Node, Vec3, AnimationComponent, CustomEventListener, Constants, AudioMgr, RunTimeData, _dec, _dec2, _class, _class2, _descriptor, _descriptor2, _temp, _crd, ccclass, property, EventName, tempVec, CustomerMgr;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfCustomEventListener(extras) {
    _reporterNs.report("CustomEventListener", "../data/CustomEventListener", _context.meta, extras);
  }

  function _reportPossibleCrUseOfConstants(extras) {
    _reporterNs.report("Constants", "../data/Constants", _context.meta, extras);
  }

  function _reportPossibleCrUseOfAudioMgr(extras) {
    _reporterNs.report("AudioMgr", "./AudioMgr", _context.meta, extras);
  }

  function _reportPossibleCrUseOfRunTimeData(extras) {
    _reporterNs.report("RunTimeData", "../data/GameData", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _dec2: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _descriptor2: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Vec3 = _cc.Vec3;
      AnimationComponent = _cc.AnimationComponent;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_dataCustomEventListenerJs) {
      CustomEventListener = _dataCustomEventListenerJs.CustomEventListener;
    }, function (_dataConstantsJs) {
      Constants = _dataConstantsJs.Constants;
    }, function (_AudioMgrJs) {
      AudioMgr = _AudioMgrJs.AudioMgr;
    }, function (_dataGameDataJs) {
      RunTimeData = _dataGameDataJs.RunTimeData;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "3c8a7koBRZDM7pcdxfwceGv", "CustomerMgr", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;
      EventName = (_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
        error: Error()
      }), Constants) : Constants).EventName;
      tempVec = new Vec3();

      _export("CustomerMgr", CustomerMgr = (_dec = ccclass('CustomerMgr'), _dec2 = property({
        type: [Node]
      }), _dec(_class = (_class2 = (_temp = /*#__PURE__*/function (_Component) {
        _inherits(CustomerMgr, _Component);

        function CustomerMgr() {
          var _getPrototypeOf2;

          var _this;

          _classCallCheck(this, CustomerMgr);

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(CustomerMgr)).call.apply(_getPrototypeOf2, [this].concat(args)));

          _initializerDefineProperty(_this, "customers", _descriptor, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "walkTime", _descriptor2, _assertThisInitialized(_this));

          _this.currCustomer = null;
          _this.startPos = new Vec3();
          _this.endPos = new Vec3();
          _this.InTheOrder = false;
          _this.deltaTime = 0;
          _this.state = (_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
            error: Error()
          }), Constants) : Constants).CustomerState.NONE;
          _this.customerID = -1;
          return _this;
        }

        _createClass(CustomerMgr, [{
          key: "start",
          value: function start() {
            // Your initialization goes here.
            (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
              error: Error()
            }), CustomEventListener) : CustomEventListener).on(EventName.GREETING, this.greetingCustomer, this);
            (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
              error: Error()
            }), CustomEventListener) : CustomEventListener).on(EventName.GOODBYE, this.goodbyeCustomer, this);
          }
        }, {
          key: "update",
          value: function update(dt) {
            if (this.InTheOrder) {
              this.deltaTime += dt;

              if (this.deltaTime < this.walkTime) {
                Vec3.lerp(tempVec, this.startPos, this.endPos, this.deltaTime / this.walkTime);
                this.currCustomer.setWorldPosition(tempVec);
              } else {
                this.deltaTime = 0;
                this.InTheOrder = false;
                this.currCustomer.active = false;

                if (this.state === (_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
                  error: Error()
                }), Constants) : Constants).CustomerState.GOODBYE) {
                  this.currCustomer = null;
                }

                if (this.state == (_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
                  error: Error()
                }), Constants) : Constants).CustomerState.GREETING) {
                  (_crd && AudioMgr === void 0 ? (_reportPossibleCrUseOfAudioMgr({
                    error: Error()
                  }), AudioMgr) : AudioMgr).playSound((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
                    error: Error()
                  }), Constants) : Constants).AudioFiles.INCAR);
                }

                (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
                  error: Error()
                }), CustomEventListener) : CustomEventListener).dispatchEvent(EventName.FINISHEDWALK);
                (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
                  error: Error()
                }), CustomEventListener) : CustomEventListener).dispatchEvent((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
                  error: Error()
                }), Constants) : Constants).EventName.SHOWGUIDE, true);
              }
            }
          }
        }, {
          key: "greetingCustomer",
          value: function greetingCustomer() {
            var cusidx = Math.floor(Math.random() * this.customers.length);
            this.customerID = cusidx;
            this.currCustomer = this.customers[cusidx];
            this.state = (_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).CustomerState.GREETING;

            if (!this.currCustomer) {
              return;
            }

            this.InTheOrder = true;
            var carPos = arguments.length <= 0 ? undefined : arguments[0];
            var direction = arguments.length <= 1 ? undefined : arguments[1];
            Vec3.multiplyScalar(this.startPos, direction, 1.4);
            this.startPos.add(carPos);
            Vec3.multiplyScalar(this.endPos, direction, 0.5);
            this.endPos.add(carPos);
            this.currCustomer.setWorldPosition(this.startPos);
            this.currCustomer.active = true;

            if (direction.x !== 0) {
              if (direction.x > 0) {
                this.currCustomer.eulerAngles = new Vec3(0, -90, 0);
              } else {
                this.currCustomer.eulerAngles = new Vec3(0, 90, 0);
              }
            } else {
              if (direction.z > 0) {
                this.currCustomer.eulerAngles = new Vec3(0, 180, 0);
              }
            }

            var animComp = this.currCustomer.getComponent(AnimationComponent);
            animComp.play("walk");
            (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
              error: Error()
            }), CustomEventListener) : CustomEventListener).dispatchEvent((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).EventName.SHOWTALK, cusidx);
            (_crd && AudioMgr === void 0 ? (_reportPossibleCrUseOfAudioMgr({
              error: Error()
            }), AudioMgr) : AudioMgr).playSound((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).AudioFiles.NEWORDER);
          }
        }, {
          key: "goodbyeCustomer",
          value: function goodbyeCustomer() {
            this.state = (_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).CustomerState.GOODBYE;
            this.InTheOrder = true;
            var carPos = arguments.length <= 0 ? undefined : arguments[0];
            var direction = arguments.length <= 1 ? undefined : arguments[1];
            Vec3.multiplyScalar(this.startPos, direction, 0.5);
            this.startPos.add(carPos);
            Vec3.multiplyScalar(this.endPos, direction, 1.4);
            this.endPos.add(carPos);
            this.currCustomer.setWorldPosition(this.startPos);
            this.currCustomer.active = true;
            var money = 30 + (_crd && RunTimeData === void 0 ? (_reportPossibleCrUseOfRunTimeData({
              error: Error()
            }), RunTimeData) : RunTimeData).instance().currLevel / 2 + Math.random() * 10;
            (_crd && RunTimeData === void 0 ? (_reportPossibleCrUseOfRunTimeData({
              error: Error()
            }), RunTimeData) : RunTimeData).instance().money += Math.floor(money);

            if (direction.x !== 0) {
              if (direction.x > 0) {
                this.currCustomer.eulerAngles = new Vec3(0, 90, 0);
              } else {
                this.currCustomer.eulerAngles = new Vec3(0, -90, 0);
              }
            } else {
              if (direction.z < 0) {
                this.currCustomer.eulerAngles = new Vec3(0, 180, 0);
              }
            }

            var animComp = this.currCustomer.getComponent(AnimationComponent);
            animComp.play("walk");
            (_crd && AudioMgr === void 0 ? (_reportPossibleCrUseOfAudioMgr({
              error: Error()
            }), AudioMgr) : AudioMgr).playSound((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).AudioFiles.GETMONEY);
            (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
              error: Error()
            }), CustomEventListener) : CustomEventListener).dispatchEvent((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).EventName.SHOWTALK, this.customerID);
          } // update (deltaTime: number) {
          //     // Your update function goes here.
          // }

        }]);

        return CustomerMgr;
      }(Component), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "customers", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "walkTime", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 1;
        }
      })), _class2)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ3JlYXRvci9TcGVlZFRheGkvYXNzZXRzL3NjcmlwdC9nYW1lL0N1c3RvbWVyTWdyLnRzIl0sIm5hbWVzIjpbIl9kZWNvcmF0b3IiLCJDb21wb25lbnQiLCJOb2RlIiwiVmVjMyIsIkFuaW1hdGlvbkNvbXBvbmVudCIsIkN1c3RvbUV2ZW50TGlzdGVuZXIiLCJDb25zdGFudHMiLCJBdWRpb01nciIsIlJ1blRpbWVEYXRhIiwiY2NjbGFzcyIsInByb3BlcnR5IiwiRXZlbnROYW1lIiwidGVtcFZlYyIsIkN1c3RvbWVyTWdyIiwidHlwZSIsImN1cnJDdXN0b21lciIsInN0YXJ0UG9zIiwiZW5kUG9zIiwiSW5UaGVPcmRlciIsImRlbHRhVGltZSIsInN0YXRlIiwiQ3VzdG9tZXJTdGF0ZSIsIk5PTkUiLCJjdXN0b21lcklEIiwib24iLCJHUkVFVElORyIsImdyZWV0aW5nQ3VzdG9tZXIiLCJHT09EQllFIiwiZ29vZGJ5ZUN1c3RvbWVyIiwiZHQiLCJ3YWxrVGltZSIsImxlcnAiLCJzZXRXb3JsZFBvc2l0aW9uIiwiYWN0aXZlIiwicGxheVNvdW5kIiwiQXVkaW9GaWxlcyIsIklOQ0FSIiwiZGlzcGF0Y2hFdmVudCIsIkZJTklTSEVEV0FMSyIsIlNIT1dHVUlERSIsImN1c2lkeCIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSIsImN1c3RvbWVycyIsImxlbmd0aCIsImNhclBvcyIsImRpcmVjdGlvbiIsIm11bHRpcGx5U2NhbGFyIiwiYWRkIiwieCIsImV1bGVyQW5nbGVzIiwieiIsImFuaW1Db21wIiwiZ2V0Q29tcG9uZW50IiwicGxheSIsIlNIT1dUQUxLIiwiTkVXT1JERVIiLCJtb25leSIsImluc3RhbmNlIiwiY3VyckxldmVsIiwiR0VUTU9ORVkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBU0EsTUFBQUEsVSxPQUFBQSxVO0FBQVlDLE1BQUFBLFMsT0FBQUEsUztBQUFXQyxNQUFBQSxJLE9BQUFBLEk7QUFBaUJDLE1BQUFBLEksT0FBQUEsSTtBQUFNQyxNQUFBQSxrQixPQUFBQSxrQjs7OztBQUM5Q0MsTUFBQUEsbUIsOEJBQUFBLG1COztBQUNBQyxNQUFBQSxTLG9CQUFBQSxTOztBQUNBQyxNQUFBQSxRLGVBQUFBLFE7O0FBQ0FDLE1BQUFBLFcsbUJBQUFBLFc7Ozs7OztBQUNEQyxNQUFBQSxPLEdBQXNCVCxVLENBQXRCUyxPO0FBQVNDLE1BQUFBLFEsR0FBYVYsVSxDQUFiVSxRO0FBRVhDLE1BQUFBLFMsR0FBWTtBQUFBO0FBQUEsa0NBQVVBLFM7QUFDdEJDLE1BQUFBLE8sR0FBUSxJQUFJVCxJQUFKLEU7OzZCQUdEVSxXLFdBRFpKLE9BQU8sQ0FBQyxhQUFELEMsVUFFSEMsUUFBUSxDQUFDO0FBQ05JLFFBQUFBLElBQUksRUFBQyxDQUFDWixJQUFEO0FBREMsT0FBRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnQkFRRGEsWSxHQUFvQixJO2dCQUNwQkMsUSxHQUFTLElBQUliLElBQUosRTtnQkFDVGMsTSxHQUFPLElBQUlkLElBQUosRTtnQkFDUGUsVSxHQUFXLEs7Z0JBQ1hDLFMsR0FBVSxDO2dCQUNWQyxLLEdBQVE7QUFBQTtBQUFBLHNDQUFVQyxhQUFWLENBQXdCQyxJO2dCQUNoQ0MsVSxHQUFhLENBQUMsQzs7Ozs7O2tDQUViO0FBQ0w7QUFDQTtBQUFBO0FBQUEsNERBQW9CQyxFQUFwQixDQUF1QmIsU0FBUyxDQUFDYyxRQUFqQyxFQUEwQyxLQUFLQyxnQkFBL0MsRUFBZ0UsSUFBaEU7QUFDQTtBQUFBO0FBQUEsNERBQW9CRixFQUFwQixDQUF1QmIsU0FBUyxDQUFDZ0IsT0FBakMsRUFBeUMsS0FBS0MsZUFBOUMsRUFBOEQsSUFBOUQ7QUFDSDs7O2lDQUVhQyxFLEVBQ2Q7QUFDSSxnQkFBRyxLQUFLWCxVQUFSLEVBQ0E7QUFDSSxtQkFBS0MsU0FBTCxJQUFnQlUsRUFBaEI7O0FBQ0Esa0JBQUcsS0FBS1YsU0FBTCxHQUFlLEtBQUtXLFFBQXZCLEVBQWdDO0FBQzVCM0IsZ0JBQUFBLElBQUksQ0FBQzRCLElBQUwsQ0FBVW5CLE9BQVYsRUFBa0IsS0FBS0ksUUFBdkIsRUFBZ0MsS0FBS0MsTUFBckMsRUFBNEMsS0FBS0UsU0FBTCxHQUFlLEtBQUtXLFFBQWhFO0FBQ0EscUJBQUtmLFlBQUwsQ0FBa0JpQixnQkFBbEIsQ0FBbUNwQixPQUFuQztBQUNILGVBSEQsTUFHSztBQUNELHFCQUFLTyxTQUFMLEdBQWUsQ0FBZjtBQUNBLHFCQUFLRCxVQUFMLEdBQWdCLEtBQWhCO0FBQ0EscUJBQUtILFlBQUwsQ0FBa0JrQixNQUFsQixHQUF5QixLQUF6Qjs7QUFDQSxvQkFBRyxLQUFLYixLQUFMLEtBQWE7QUFBQTtBQUFBLDRDQUFVQyxhQUFWLENBQXdCTSxPQUF4QyxFQUNBO0FBQ0ksdUJBQUtaLFlBQUwsR0FBb0IsSUFBcEI7QUFDSDs7QUFDRCxvQkFBRyxLQUFLSyxLQUFMLElBQVk7QUFBQTtBQUFBLDRDQUFVQyxhQUFWLENBQXdCSSxRQUF2QyxFQUNBO0FBQ0k7QUFBQTtBQUFBLDRDQUFTUyxTQUFULENBQW1CO0FBQUE7QUFBQSw4Q0FBVUMsVUFBVixDQUFxQkMsS0FBeEM7QUFDSDs7QUFDRDtBQUFBO0FBQUEsZ0VBQW9CQyxhQUFwQixDQUFrQzFCLFNBQVMsQ0FBQzJCLFlBQTVDO0FBQ0E7QUFBQTtBQUFBLGdFQUFvQkQsYUFBcEIsQ0FBa0M7QUFBQTtBQUFBLDRDQUFVMUIsU0FBVixDQUFvQjRCLFNBQXRELEVBQWdFLElBQWhFO0FBQ0g7QUFDSjtBQUNKOzs7NkNBR0Q7QUFDSSxnQkFBTUMsTUFBTSxHQUFDQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWMsS0FBS0MsU0FBTCxDQUFlQyxNQUF4QyxDQUFiO0FBQ0EsaUJBQUt0QixVQUFMLEdBQWdCaUIsTUFBaEI7QUFDQSxpQkFBS3pCLFlBQUwsR0FBa0IsS0FBSzZCLFNBQUwsQ0FBZUosTUFBZixDQUFsQjtBQUNBLGlCQUFLcEIsS0FBTCxHQUFhO0FBQUE7QUFBQSx3Q0FBVUMsYUFBVixDQUF3QkksUUFBckM7O0FBQ0EsZ0JBQUcsQ0FBQyxLQUFLVixZQUFULEVBQXNCO0FBQUM7QUFBUTs7QUFDL0IsaUJBQUtHLFVBQUwsR0FBZ0IsSUFBaEI7QUFDQSxnQkFBTTRCLE1BQU0sbURBQVo7QUFDQSxnQkFBTUMsU0FBUyxtREFBZjtBQUNBNUMsWUFBQUEsSUFBSSxDQUFDNkMsY0FBTCxDQUFvQixLQUFLaEMsUUFBekIsRUFBa0MrQixTQUFsQyxFQUE0QyxHQUE1QztBQUNBLGlCQUFLL0IsUUFBTCxDQUFjaUMsR0FBZCxDQUFrQkgsTUFBbEI7QUFDQTNDLFlBQUFBLElBQUksQ0FBQzZDLGNBQUwsQ0FBb0IsS0FBSy9CLE1BQXpCLEVBQWdDOEIsU0FBaEMsRUFBMEMsR0FBMUM7QUFDQSxpQkFBSzlCLE1BQUwsQ0FBWWdDLEdBQVosQ0FBZ0JILE1BQWhCO0FBRUEsaUJBQUsvQixZQUFMLENBQWtCaUIsZ0JBQWxCLENBQW1DLEtBQUtoQixRQUF4QztBQUNBLGlCQUFLRCxZQUFMLENBQWtCa0IsTUFBbEIsR0FBMkIsSUFBM0I7O0FBRUEsZ0JBQUdjLFNBQVMsQ0FBQ0csQ0FBVixLQUFjLENBQWpCLEVBQW1CO0FBQ2Ysa0JBQUdILFNBQVMsQ0FBQ0csQ0FBVixHQUFZLENBQWYsRUFBaUI7QUFDYixxQkFBS25DLFlBQUwsQ0FBa0JvQyxXQUFsQixHQUFnQyxJQUFJaEQsSUFBSixDQUFTLENBQVQsRUFBVyxDQUFDLEVBQVosRUFBZSxDQUFmLENBQWhDO0FBQ0gsZUFGRCxNQUlBO0FBQ0kscUJBQUtZLFlBQUwsQ0FBa0JvQyxXQUFsQixHQUFnQyxJQUFJaEQsSUFBSixDQUFTLENBQVQsRUFBVyxFQUFYLEVBQWMsQ0FBZCxDQUFoQztBQUNIO0FBQ0osYUFSRCxNQVNBO0FBQ0ksa0JBQUc0QyxTQUFTLENBQUNLLENBQVYsR0FBWSxDQUFmLEVBQWlCO0FBQ2IscUJBQUtyQyxZQUFMLENBQWtCb0MsV0FBbEIsR0FBZ0MsSUFBSWhELElBQUosQ0FBUyxDQUFULEVBQVcsR0FBWCxFQUFlLENBQWYsQ0FBaEM7QUFDSDtBQUNKOztBQUVELGdCQUFNa0QsUUFBUSxHQUFHLEtBQUt0QyxZQUFMLENBQWtCdUMsWUFBbEIsQ0FBK0JsRCxrQkFBL0IsQ0FBakI7QUFDQWlELFlBQUFBLFFBQVEsQ0FBQ0UsSUFBVCxDQUFjLE1BQWQ7QUFFQTtBQUFBO0FBQUEsNERBQW9CbEIsYUFBcEIsQ0FBa0M7QUFBQTtBQUFBLHdDQUFVMUIsU0FBVixDQUFvQjZDLFFBQXRELEVBQStEaEIsTUFBL0Q7QUFDQTtBQUFBO0FBQUEsc0NBQVNOLFNBQVQsQ0FBbUI7QUFBQTtBQUFBLHdDQUFVQyxVQUFWLENBQXFCc0IsUUFBeEM7QUFDSDs7OzRDQUdEO0FBQ0ksaUJBQUtyQyxLQUFMLEdBQWE7QUFBQTtBQUFBLHdDQUFVQyxhQUFWLENBQXdCTSxPQUFyQztBQUNBLGlCQUFLVCxVQUFMLEdBQWdCLElBQWhCO0FBQ0EsZ0JBQU00QixNQUFNLG1EQUFaO0FBQ0EsZ0JBQU1DLFNBQVMsbURBQWY7QUFDQTVDLFlBQUFBLElBQUksQ0FBQzZDLGNBQUwsQ0FBb0IsS0FBS2hDLFFBQXpCLEVBQWtDK0IsU0FBbEMsRUFBNEMsR0FBNUM7QUFDQSxpQkFBSy9CLFFBQUwsQ0FBY2lDLEdBQWQsQ0FBa0JILE1BQWxCO0FBQ0EzQyxZQUFBQSxJQUFJLENBQUM2QyxjQUFMLENBQW9CLEtBQUsvQixNQUF6QixFQUFnQzhCLFNBQWhDLEVBQTBDLEdBQTFDO0FBQ0EsaUJBQUs5QixNQUFMLENBQVlnQyxHQUFaLENBQWdCSCxNQUFoQjtBQUVBLGlCQUFLL0IsWUFBTCxDQUFrQmlCLGdCQUFsQixDQUFtQyxLQUFLaEIsUUFBeEM7QUFDQSxpQkFBS0QsWUFBTCxDQUFrQmtCLE1BQWxCLEdBQTJCLElBQTNCO0FBRUEsZ0JBQU15QixLQUFLLEdBQUcsS0FBTTtBQUFBO0FBQUEsNENBQVlDLFFBQVosR0FBdUJDLFNBQXZCLEdBQWlDLENBQXZDLEdBQTZDbkIsSUFBSSxDQUFDRSxNQUFMLEtBQWMsRUFBekU7QUFDQTtBQUFBO0FBQUEsNENBQVlnQixRQUFaLEdBQXVCRCxLQUF2QixJQUFnQ2pCLElBQUksQ0FBQ0MsS0FBTCxDQUFXZ0IsS0FBWCxDQUFoQzs7QUFFQSxnQkFBR1gsU0FBUyxDQUFDRyxDQUFWLEtBQWMsQ0FBakIsRUFBbUI7QUFDZixrQkFBR0gsU0FBUyxDQUFDRyxDQUFWLEdBQVksQ0FBZixFQUFpQjtBQUNiLHFCQUFLbkMsWUFBTCxDQUFrQm9DLFdBQWxCLEdBQWdDLElBQUloRCxJQUFKLENBQVMsQ0FBVCxFQUFXLEVBQVgsRUFBYyxDQUFkLENBQWhDO0FBQ0gsZUFGRCxNQUlBO0FBQ0kscUJBQUtZLFlBQUwsQ0FBa0JvQyxXQUFsQixHQUFnQyxJQUFJaEQsSUFBSixDQUFTLENBQVQsRUFBVyxDQUFDLEVBQVosRUFBZSxDQUFmLENBQWhDO0FBQ0g7QUFDSixhQVJELE1BU0E7QUFDSSxrQkFBRzRDLFNBQVMsQ0FBQ0ssQ0FBVixHQUFZLENBQWYsRUFBaUI7QUFDYixxQkFBS3JDLFlBQUwsQ0FBa0JvQyxXQUFsQixHQUFnQyxJQUFJaEQsSUFBSixDQUFTLENBQVQsRUFBVyxHQUFYLEVBQWUsQ0FBZixDQUFoQztBQUNIO0FBQ0o7O0FBRUQsZ0JBQU1rRCxRQUFRLEdBQUcsS0FBS3RDLFlBQUwsQ0FBa0J1QyxZQUFsQixDQUErQmxELGtCQUEvQixDQUFqQjtBQUNBaUQsWUFBQUEsUUFBUSxDQUFDRSxJQUFULENBQWMsTUFBZDtBQUVBO0FBQUE7QUFBQSxzQ0FBU3JCLFNBQVQsQ0FBbUI7QUFBQTtBQUFBLHdDQUFVQyxVQUFWLENBQXFCMEIsUUFBeEM7QUFDQTtBQUFBO0FBQUEsNERBQW9CeEIsYUFBcEIsQ0FBa0M7QUFBQTtBQUFBLHdDQUFVMUIsU0FBVixDQUFvQjZDLFFBQXRELEVBQStELEtBQUtqQyxVQUFwRTtBQUNILFcsQ0FFRDtBQUNBO0FBQ0E7Ozs7O1FBbEk2QnRCLFM7Ozs7O2lCQUlaLEU7O21GQUVoQlMsUTs7Ozs7aUJBQ1EsQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IF9kZWNvcmF0b3IsIENvbXBvbmVudCwgTm9kZSwgRXZlbnRUeXBlLCBWZWMzLCBBbmltYXRpb25Db21wb25lbnQgfSBmcm9tICdjYyc7XHJcbmltcG9ydCB7IEN1c3RvbUV2ZW50TGlzdGVuZXIgfSBmcm9tICcuLi9kYXRhL0N1c3RvbUV2ZW50TGlzdGVuZXInO1xyXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuLi9kYXRhL0NvbnN0YW50cyc7XHJcbmltcG9ydCB7IEF1ZGlvTWdyIH0gZnJvbSAnLi9BdWRpb01ncic7XHJcbmltcG9ydCB7IFJ1blRpbWVEYXRhIH0gZnJvbSAnLi4vZGF0YS9HYW1lRGF0YSc7XHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IF9kZWNvcmF0b3I7XHJcblxyXG5jb25zdCBFdmVudE5hbWUgPSBDb25zdGFudHMuRXZlbnROYW1lO1xyXG5jb25zdCB0ZW1wVmVjPW5ldyBWZWMzO1xyXG5cclxuQGNjY2xhc3MoJ0N1c3RvbWVyTWdyJylcclxuZXhwb3J0IGNsYXNzIEN1c3RvbWVyTWdyIGV4dGVuZHMgQ29tcG9uZW50IHtcclxuICAgIEBwcm9wZXJ0eSh7XHJcbiAgICAgICAgdHlwZTpbTm9kZV0sXHJcbiAgICB9KVxyXG4gICAgY3VzdG9tZXJzOk5vZGVbXT1bXTtcclxuXHJcbiAgICBAcHJvcGVydHlcclxuICAgIHdhbGtUaW1lPTE7XHJcblxyXG4gICAgcHJpdmF0ZSBjdXJyQ3VzdG9tZXI6Tm9kZSA9IG51bGw7XHJcbiAgICBwcml2YXRlIHN0YXJ0UG9zPW5ldyBWZWMzKCk7XHJcbiAgICBwcml2YXRlIGVuZFBvcz1uZXcgVmVjMygpO1xyXG4gICAgcHJpdmF0ZSBJblRoZU9yZGVyPWZhbHNlO1xyXG4gICAgcHJpdmF0ZSBkZWx0YVRpbWU9MDtcclxuICAgIHByaXZhdGUgc3RhdGUgPSBDb25zdGFudHMuQ3VzdG9tZXJTdGF0ZS5OT05FO1xyXG4gICAgcHJpdmF0ZSBjdXN0b21lcklEID0gLTE7XHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIC8vIFlvdXIgaW5pdGlhbGl6YXRpb24gZ29lcyBoZXJlLlxyXG4gICAgICAgIEN1c3RvbUV2ZW50TGlzdGVuZXIub24oRXZlbnROYW1lLkdSRUVUSU5HLHRoaXMuZ3JlZXRpbmdDdXN0b21lcix0aGlzKTtcclxuICAgICAgICBDdXN0b21FdmVudExpc3RlbmVyLm9uKEV2ZW50TmFtZS5HT09EQllFLHRoaXMuZ29vZGJ5ZUN1c3RvbWVyLHRoaXMpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyB1cGRhdGUoZHQ6bnVtYmVyKVxyXG4gICAge1xyXG4gICAgICAgIGlmKHRoaXMuSW5UaGVPcmRlcilcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHRoaXMuZGVsdGFUaW1lKz1kdDtcclxuICAgICAgICAgICAgaWYodGhpcy5kZWx0YVRpbWU8dGhpcy53YWxrVGltZSl7XHJcbiAgICAgICAgICAgICAgICBWZWMzLmxlcnAodGVtcFZlYyx0aGlzLnN0YXJ0UG9zLHRoaXMuZW5kUG9zLHRoaXMuZGVsdGFUaW1lL3RoaXMud2Fsa1RpbWUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyQ3VzdG9tZXIuc2V0V29ybGRQb3NpdGlvbih0ZW1wVmVjKTtcclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmRlbHRhVGltZT0wO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5JblRoZU9yZGVyPWZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyQ3VzdG9tZXIuYWN0aXZlPWZhbHNlO1xyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5zdGF0ZT09PUNvbnN0YW50cy5DdXN0b21lclN0YXRlLkdPT0RCWUUpXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXJyQ3VzdG9tZXIgPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5zdGF0ZT09Q29uc3RhbnRzLkN1c3RvbWVyU3RhdGUuR1JFRVRJTkcpXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgQXVkaW9NZ3IucGxheVNvdW5kKENvbnN0YW50cy5BdWRpb0ZpbGVzLklOQ0FSKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIEN1c3RvbUV2ZW50TGlzdGVuZXIuZGlzcGF0Y2hFdmVudChFdmVudE5hbWUuRklOSVNIRURXQUxLKTtcclxuICAgICAgICAgICAgICAgIEN1c3RvbUV2ZW50TGlzdGVuZXIuZGlzcGF0Y2hFdmVudChDb25zdGFudHMuRXZlbnROYW1lLlNIT1dHVUlERSx0cnVlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGdyZWV0aW5nQ3VzdG9tZXIoLi4uYXJnczphbnlbXSlcclxuICAgIHtcclxuICAgICAgICBjb25zdCBjdXNpZHg9TWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpKnRoaXMuY3VzdG9tZXJzLmxlbmd0aCk7XHJcbiAgICAgICAgdGhpcy5jdXN0b21lcklEPWN1c2lkeDtcclxuICAgICAgICB0aGlzLmN1cnJDdXN0b21lcj10aGlzLmN1c3RvbWVyc1tjdXNpZHhdO1xyXG4gICAgICAgIHRoaXMuc3RhdGUgPSBDb25zdGFudHMuQ3VzdG9tZXJTdGF0ZS5HUkVFVElORztcclxuICAgICAgICBpZighdGhpcy5jdXJyQ3VzdG9tZXIpe3JldHVybjt9XHJcbiAgICAgICAgdGhpcy5JblRoZU9yZGVyPXRydWU7XHJcbiAgICAgICAgY29uc3QgY2FyUG9zPWFyZ3NbMF07XHJcbiAgICAgICAgY29uc3QgZGlyZWN0aW9uPWFyZ3NbMV07XHJcbiAgICAgICAgVmVjMy5tdWx0aXBseVNjYWxhcih0aGlzLnN0YXJ0UG9zLGRpcmVjdGlvbiwxLjQpO1xyXG4gICAgICAgIHRoaXMuc3RhcnRQb3MuYWRkKGNhclBvcyk7XHJcbiAgICAgICAgVmVjMy5tdWx0aXBseVNjYWxhcih0aGlzLmVuZFBvcyxkaXJlY3Rpb24sMC41KTtcclxuICAgICAgICB0aGlzLmVuZFBvcy5hZGQoY2FyUG9zKTtcclxuXHJcbiAgICAgICAgdGhpcy5jdXJyQ3VzdG9tZXIuc2V0V29ybGRQb3NpdGlvbih0aGlzLnN0YXJ0UG9zKTtcclxuICAgICAgICB0aGlzLmN1cnJDdXN0b21lci5hY3RpdmUgPSB0cnVlO1xyXG5cclxuICAgICAgICBpZihkaXJlY3Rpb24ueCE9PTApe1xyXG4gICAgICAgICAgICBpZihkaXJlY3Rpb24ueD4wKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuY3VyckN1c3RvbWVyLmV1bGVyQW5nbGVzID0gbmV3IFZlYzMoMCwtOTAsMCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmN1cnJDdXN0b21lci5ldWxlckFuZ2xlcyA9IG5ldyBWZWMzKDAsOTAsMCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9ZWxzZVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaWYoZGlyZWN0aW9uLno+MCl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmN1cnJDdXN0b21lci5ldWxlckFuZ2xlcyA9IG5ldyBWZWMzKDAsMTgwLDApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSAgICBcclxuICAgICAgICBcclxuICAgICAgICBjb25zdCBhbmltQ29tcCA9IHRoaXMuY3VyckN1c3RvbWVyLmdldENvbXBvbmVudChBbmltYXRpb25Db21wb25lbnQpO1xyXG4gICAgICAgIGFuaW1Db21wLnBsYXkoXCJ3YWxrXCIpO1xyXG5cclxuICAgICAgICBDdXN0b21FdmVudExpc3RlbmVyLmRpc3BhdGNoRXZlbnQoQ29uc3RhbnRzLkV2ZW50TmFtZS5TSE9XVEFMSyxjdXNpZHgpO1xyXG4gICAgICAgIEF1ZGlvTWdyLnBsYXlTb3VuZChDb25zdGFudHMuQXVkaW9GaWxlcy5ORVdPUkRFUik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBnb29kYnllQ3VzdG9tZXIoLi4uYXJnczphbnlbXSlcclxuICAgIHtcclxuICAgICAgICB0aGlzLnN0YXRlID0gQ29uc3RhbnRzLkN1c3RvbWVyU3RhdGUuR09PREJZRTtcclxuICAgICAgICB0aGlzLkluVGhlT3JkZXI9dHJ1ZTtcclxuICAgICAgICBjb25zdCBjYXJQb3M9YXJnc1swXTtcclxuICAgICAgICBjb25zdCBkaXJlY3Rpb249YXJnc1sxXTtcclxuICAgICAgICBWZWMzLm11bHRpcGx5U2NhbGFyKHRoaXMuc3RhcnRQb3MsZGlyZWN0aW9uLDAuNSk7XHJcbiAgICAgICAgdGhpcy5zdGFydFBvcy5hZGQoY2FyUG9zKTtcclxuICAgICAgICBWZWMzLm11bHRpcGx5U2NhbGFyKHRoaXMuZW5kUG9zLGRpcmVjdGlvbiwxLjQpO1xyXG4gICAgICAgIHRoaXMuZW5kUG9zLmFkZChjYXJQb3MpO1xyXG5cclxuICAgICAgICB0aGlzLmN1cnJDdXN0b21lci5zZXRXb3JsZFBvc2l0aW9uKHRoaXMuc3RhcnRQb3MpO1xyXG4gICAgICAgIHRoaXMuY3VyckN1c3RvbWVyLmFjdGl2ZSA9IHRydWU7XHJcblxyXG4gICAgICAgIGNvbnN0IG1vbmV5ID0gMzAgKyAoUnVuVGltZURhdGEuaW5zdGFuY2UoKS5jdXJyTGV2ZWwvMikgKyAoTWF0aC5yYW5kb20oKSoxMCk7XHJcbiAgICAgICAgUnVuVGltZURhdGEuaW5zdGFuY2UoKS5tb25leSArPSBNYXRoLmZsb29yKG1vbmV5KTtcclxuXHJcbiAgICAgICAgaWYoZGlyZWN0aW9uLnghPT0wKXtcclxuICAgICAgICAgICAgaWYoZGlyZWN0aW9uLng+MCl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmN1cnJDdXN0b21lci5ldWxlckFuZ2xlcyA9IG5ldyBWZWMzKDAsOTAsMCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmN1cnJDdXN0b21lci5ldWxlckFuZ2xlcyA9IG5ldyBWZWMzKDAsLTkwLDApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfWVsc2VcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGlmKGRpcmVjdGlvbi56PDApe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyQ3VzdG9tZXIuZXVsZXJBbmdsZXMgPSBuZXcgVmVjMygwLDE4MCwwKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgY29uc3QgYW5pbUNvbXAgPSB0aGlzLmN1cnJDdXN0b21lci5nZXRDb21wb25lbnQoQW5pbWF0aW9uQ29tcG9uZW50KTtcclxuICAgICAgICBhbmltQ29tcC5wbGF5KFwid2Fsa1wiKTtcclxuXHJcbiAgICAgICAgQXVkaW9NZ3IucGxheVNvdW5kKENvbnN0YW50cy5BdWRpb0ZpbGVzLkdFVE1PTkVZKTtcclxuICAgICAgICBDdXN0b21FdmVudExpc3RlbmVyLmRpc3BhdGNoRXZlbnQoQ29uc3RhbnRzLkV2ZW50TmFtZS5TSE9XVEFMSyx0aGlzLmN1c3RvbWVySUQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZGVsdGFUaW1lOiBudW1iZXIpIHtcclxuICAgIC8vICAgICAvLyBZb3VyIHVwZGF0ZSBmdW5jdGlvbiBnb2VzIGhlcmUuXHJcbiAgICAvLyB9XHJcbn1cclxuIl19