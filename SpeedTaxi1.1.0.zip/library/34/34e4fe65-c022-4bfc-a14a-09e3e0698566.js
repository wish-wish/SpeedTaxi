System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, instantiate, _dec, _class, _class2, _temp, _crd, ccclass, property, PoolMgr;

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  _export({
    _dec: void 0,
    _class: void 0,
    _class2: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      instantiate = _cc.instantiate;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "34e4f5lwCJL/KFKCePgaYVm", "PoolMgr", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("PoolMgr", PoolMgr = (_dec = ccclass('PoolMgr'), _dec(_class = (_temp = _class2 = /*#__PURE__*/function () {
        function PoolMgr() {
          _classCallCheck(this, PoolMgr);
        }

        _createClass(PoolMgr, [{
          key: "start",
          value: function start() {} // Your initialization goes here.
          // update (deltaTime: number) {
          //     // Your update function goes here.
          // }

        }], [{
          key: "getNode",
          value: function getNode(perfab, parent) {
            var name = perfab.name;
            var node = null;

            if (this.handle.has(name)) {
              node = this.handle.get(name).pop();
            } else {
              node = instantiate(perfab);
            }

            node.setParent(parent);
            return node;
          }
        }, {
          key: "setNode",
          value: function setNode(target) {
            var name = target.name;
            target.parent = null;

            if (this.handle.has(name)) {
              this.handle.get(name).push(target);
            } else {
              this.handle.set(name, [target]);
            }
          }
        }]);

        return PoolMgr;
      }(), _class2.handle = new Map(), _temp)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ3JlYXRvci9TcGVlZFRheGkvYXNzZXRzL3NjcmlwdC9kYXRhL1Bvb2xNZ3IudHMiXSwibmFtZXMiOlsiX2RlY29yYXRvciIsImluc3RhbnRpYXRlIiwiY2NjbGFzcyIsInByb3BlcnR5IiwiUG9vbE1nciIsInBlcmZhYiIsInBhcmVudCIsIm5hbWUiLCJub2RlIiwiaGFuZGxlIiwiaGFzIiwiZ2V0IiwicG9wIiwic2V0UGFyZW50IiwidGFyZ2V0IiwicHVzaCIsInNldCIsIk1hcCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQVNBLE1BQUFBLFUsT0FBQUEsVTtBQUFxQ0MsTUFBQUEsVyxPQUFBQSxXOzs7Ozs7QUFDdENDLE1BQUFBLE8sR0FBc0JGLFUsQ0FBdEJFLE87QUFBU0MsTUFBQUEsUSxHQUFhSCxVLENBQWJHLFE7O3lCQUdKQyxPLFdBRFpGLE9BQU8sQ0FBQyxTQUFELEM7Ozs7Ozs7a0NBNkJLLENBRVIsQyxDQURHO0FBR0o7QUFDQTtBQUNBOzs7O2tDQTlCc0JHLE0sRUFBY0MsTSxFQUFZO0FBQzVDLGdCQUFNQyxJQUFJLEdBQUNGLE1BQU0sQ0FBQ0UsSUFBbEI7QUFDQSxnQkFBSUMsSUFBUyxHQUFHLElBQWhCOztBQUNBLGdCQUFHLEtBQUtDLE1BQUwsQ0FBWUMsR0FBWixDQUFnQkgsSUFBaEIsQ0FBSCxFQUF5QjtBQUNyQkMsY0FBQUEsSUFBSSxHQUFHLEtBQUtDLE1BQUwsQ0FBWUUsR0FBWixDQUFnQkosSUFBaEIsRUFBc0JLLEdBQXRCLEVBQVA7QUFDSCxhQUZELE1BR0E7QUFDSUosY0FBQUEsSUFBSSxHQUFDUCxXQUFXLENBQUNJLE1BQUQsQ0FBaEI7QUFDSDs7QUFDREcsWUFBQUEsSUFBSSxDQUFDSyxTQUFMLENBQWVQLE1BQWY7QUFDQSxtQkFBT0UsSUFBUDtBQUNIOzs7a0NBRXFCTSxNLEVBQVk7QUFDOUIsZ0JBQU1QLElBQUksR0FBQ08sTUFBTSxDQUFDUCxJQUFsQjtBQUNBTyxZQUFBQSxNQUFNLENBQUNSLE1BQVAsR0FBZ0IsSUFBaEI7O0FBQ0EsZ0JBQUcsS0FBS0csTUFBTCxDQUFZQyxHQUFaLENBQWdCSCxJQUFoQixDQUFILEVBQXlCO0FBQ3JCLG1CQUFLRSxNQUFMLENBQVlFLEdBQVosQ0FBZ0JKLElBQWhCLEVBQXNCUSxJQUF0QixDQUEyQkQsTUFBM0I7QUFDSCxhQUZELE1BR0E7QUFDSSxtQkFBS0wsTUFBTCxDQUFZTyxHQUFaLENBQWdCVCxJQUFoQixFQUFxQixDQUFDTyxNQUFELENBQXJCO0FBQ0g7QUFDSjs7OzttQkF4QmNMLE0sR0FBUyxJQUFJUSxHQUFKLEUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBfZGVjb3JhdG9yLCBDb21wb25lbnQsIE5vZGUsIFByZWZhYiwgaW5zdGFudGlhdGUgfSBmcm9tICdjYyc7XHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IF9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzcygnUG9vbE1ncicpXHJcbmV4cG9ydCBjbGFzcyBQb29sTWdyIHtcclxuICAgIFxyXG4gICAgcHJpdmF0ZSBzdGF0aWMgaGFuZGxlID0gbmV3IE1hcDxzdHJpbmcsTm9kZVtdPigpO1xyXG5cclxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0Tm9kZShwZXJmYWI6UHJlZmFiLHBhcmVudDpOb2RlKXtcclxuICAgICAgICBjb25zdCBuYW1lPXBlcmZhYi5uYW1lO1xyXG4gICAgICAgIGxldCBub2RlOk5vZGUgPSBudWxsO1xyXG4gICAgICAgIGlmKHRoaXMuaGFuZGxlLmhhcyhuYW1lKSl7XHJcbiAgICAgICAgICAgIG5vZGUgPSB0aGlzLmhhbmRsZS5nZXQobmFtZSkucG9wKCk7XHJcbiAgICAgICAgfWVsc2VcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIG5vZGU9aW5zdGFudGlhdGUocGVyZmFiKSBhcyBOb2RlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBub2RlLnNldFBhcmVudChwYXJlbnQpO1xyXG4gICAgICAgIHJldHVybiBub2RlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzdGF0aWMgc2V0Tm9kZSh0YXJnZXQ6Tm9kZSl7XHJcbiAgICAgICAgY29uc3QgbmFtZT10YXJnZXQubmFtZTtcclxuICAgICAgICB0YXJnZXQucGFyZW50ID0gbnVsbDtcclxuICAgICAgICBpZih0aGlzLmhhbmRsZS5oYXMobmFtZSkpe1xyXG4gICAgICAgICAgICB0aGlzLmhhbmRsZS5nZXQobmFtZSkucHVzaCh0YXJnZXQpO1xyXG4gICAgICAgIH1lbHNlXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICB0aGlzLmhhbmRsZS5zZXQobmFtZSxbdGFyZ2V0XSk7IFxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgLy8gWW91ciBpbml0aWFsaXphdGlvbiBnb2VzIGhlcmUuXHJcbiAgICB9XHJcblxyXG4gICAgLy8gdXBkYXRlIChkZWx0YVRpbWU6IG51bWJlcikge1xyXG4gICAgLy8gICAgIC8vIFlvdXIgdXBkYXRlIGZ1bmN0aW9uIGdvZXMgaGVyZS5cclxuICAgIC8vIH1cclxufVxyXG4iXX0=