System.register(["cc", "code-quality:cr", "./Constants.js"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Constants, _dec, _class, _class2, _temp, _crd, ccclass, property, ConfigMgr;

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _reportPossibleCrUseOfConstants(extras) {
    _reporterNs.report("Constants", "./Constants", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _class: void 0,
    _class2: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_ConstantsJs) {
      Constants = _ConstantsJs.Constants;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "046091gjZNPmaVSDxUQXp0h", "ConfigMgr", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("ConfigMgr", ConfigMgr = (_dec = ccclass('ConfigMgr'), _dec(_class = (_temp = _class2 = /*#__PURE__*/function () {
        function ConfigMgr() {
          _classCallCheck(this, ConfigMgr);

          this.jsonData = {};
          this.markSave = false;
        }

        _createClass(ConfigMgr, [{
          key: "init",
          value: function init() {
            var localStorage = cc.sys.localStorage.getItem((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).GameConfigID);

            if (localStorage) {
              this.jsonData = JSON.parse(localStorage);
            }

            setInterval(this.scheduleSave.bind(this), 500);
          }
        }, {
          key: "getConfigData",
          value: function getConfigData(key) {
            var data = this.jsonData[key];
            return data || '';
          }
        }, {
          key: "setConfigData",
          value: function setConfigData(key, value) {
            this.jsonData[key] = value;
            this.markSave = true;
          }
        }, {
          key: "scheduleSave",
          value: function scheduleSave() {
            if (!this.markSave) {
              return;
            }

            var data = JSON.stringify(this.jsonData);
            cc.sys.localStorage.setItem((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).GameConfigID, data);
            this.markSave = false;
          }
        }], [{
          key: "instance",
          value: function instance() {
            if (!this._instance) {
              this._instance = new ConfigMgr();
            }

            return this._instance;
          }
        }]);

        return ConfigMgr;
      }(), _class2._instance = null, _temp)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ3JlYXRvci9TcGVlZFRheGkvYXNzZXRzL3NjcmlwdC9kYXRhL0NvbmZpZ01nci50cyJdLCJuYW1lcyI6WyJfZGVjb3JhdG9yIiwiQ29uc3RhbnRzIiwiY2NjbGFzcyIsInByb3BlcnR5IiwiQ29uZmlnTWdyIiwianNvbkRhdGEiLCJtYXJrU2F2ZSIsImxvY2FsU3RvcmFnZSIsImNjIiwic3lzIiwiZ2V0SXRlbSIsIkdhbWVDb25maWdJRCIsIkpTT04iLCJwYXJzZSIsInNldEludGVydmFsIiwic2NoZWR1bGVTYXZlIiwiYmluZCIsImtleSIsImRhdGEiLCJ2YWx1ZSIsInN0cmluZ2lmeSIsInNldEl0ZW0iLCJfaW5zdGFuY2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBU0EsTUFBQUEsVSxPQUFBQSxVOzs7O0FBQ0FDLE1BQUFBLFMsZ0JBQUFBLFM7Ozs7OztBQUNEQyxNQUFBQSxPLEdBQXNCRixVLENBQXRCRSxPO0FBQVNDLE1BQUFBLFEsR0FBYUgsVSxDQUFiRyxROzsyQkFHSkMsUyxXQURaRixPQUFPLENBQUMsV0FBRCxDOzs7O2VBRUlHLFEsR0FBUyxFO2VBQ1RDLFEsR0FBVyxLOzs7OztpQ0FVTjtBQUNULGdCQUFNQyxZQUFZLEdBQUdDLEVBQUUsQ0FBQ0MsR0FBSCxDQUFPRixZQUFQLENBQW9CRyxPQUFwQixDQUE0QjtBQUFBO0FBQUEsd0NBQVVDLFlBQXRDLENBQXJCOztBQUNBLGdCQUFHSixZQUFILEVBQWdCO0FBQ1osbUJBQUtGLFFBQUwsR0FBZ0JPLElBQUksQ0FBQ0MsS0FBTCxDQUFXTixZQUFYLENBQWhCO0FBQ0g7O0FBQ0RPLFlBQUFBLFdBQVcsQ0FBQyxLQUFLQyxZQUFMLENBQWtCQyxJQUFsQixDQUF1QixJQUF2QixDQUFELEVBQThCLEdBQTlCLENBQVg7QUFDSDs7O3dDQUVvQkMsRyxFQUFXO0FBQzVCLGdCQUFNQyxJQUFJLEdBQUcsS0FBS2IsUUFBTCxDQUFjWSxHQUFkLENBQWI7QUFDQSxtQkFBT0MsSUFBSSxJQUFJLEVBQWY7QUFDSDs7O3dDQUVvQkQsRyxFQUFXRSxLLEVBQWE7QUFDekMsaUJBQUtkLFFBQUwsQ0FBY1ksR0FBZCxJQUFtQkUsS0FBbkI7QUFDQSxpQkFBS2IsUUFBTCxHQUFjLElBQWQ7QUFDSDs7O3lDQUVxQjtBQUNsQixnQkFBRyxDQUFDLEtBQUtBLFFBQVQsRUFDQTtBQUNJO0FBQ0g7O0FBQ0QsZ0JBQU1ZLElBQUksR0FBR04sSUFBSSxDQUFDUSxTQUFMLENBQWUsS0FBS2YsUUFBcEIsQ0FBYjtBQUNBRyxZQUFBQSxFQUFFLENBQUNDLEdBQUgsQ0FBT0YsWUFBUCxDQUFvQmMsT0FBcEIsQ0FBNEI7QUFBQTtBQUFBLHdDQUFVVixZQUF0QyxFQUFtRE8sSUFBbkQ7QUFDQSxpQkFBS1osUUFBTCxHQUFnQixLQUFoQjtBQUNIOzs7cUNBakN1QjtBQUNwQixnQkFBRyxDQUFDLEtBQUtnQixTQUFULEVBQW1CO0FBQ2YsbUJBQUtBLFNBQUwsR0FBaUIsSUFBSWxCLFNBQUosRUFBakI7QUFDSDs7QUFDRCxtQkFBTyxLQUFLa0IsU0FBWjtBQUNIOzs7O21CQU5NQSxTLEdBQXNCLEkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBfZGVjb3JhdG9yLCBDb21wb25lbnQsIE5vZGUgfSBmcm9tICdjYyc7XHJcbmltcG9ydCB7IENvbnN0YW50cyB9IGZyb20gJy4vQ29uc3RhbnRzJztcclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gX2RlY29yYXRvcjtcclxuXHJcbkBjY2NsYXNzKCdDb25maWdNZ3InKVxyXG5leHBvcnQgY2xhc3MgQ29uZmlnTWdyIHtcclxuICAgIHByaXZhdGUganNvbkRhdGE9e307XHJcbiAgICBwcml2YXRlIG1hcmtTYXZlID0gZmFsc2U7XHJcblxyXG4gICAgc3RhdGljIF9pbnN0YW5jZTpDb25maWdNZ3IgPSBudWxsO1xyXG4gICAgcHVibGljIHN0YXRpYyBpbnN0YW5jZSgpe1xyXG4gICAgICAgIGlmKCF0aGlzLl9pbnN0YW5jZSl7XHJcbiAgICAgICAgICAgIHRoaXMuX2luc3RhbmNlID0gbmV3IENvbmZpZ01ncigpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5faW5zdGFuY2U7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGluaXQoKXtcclxuICAgICAgICBjb25zdCBsb2NhbFN0b3JhZ2UgPSBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oQ29uc3RhbnRzLkdhbWVDb25maWdJRCk7XHJcbiAgICAgICAgaWYobG9jYWxTdG9yYWdlKXtcclxuICAgICAgICAgICAgdGhpcy5qc29uRGF0YSA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgc2V0SW50ZXJ2YWwodGhpcy5zY2hlZHVsZVNhdmUuYmluZCh0aGlzKSw1MDApXHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldENvbmZpZ0RhdGEoa2V5OnN0cmluZyl7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IHRoaXMuanNvbkRhdGFba2V5XTtcclxuICAgICAgICByZXR1cm4gZGF0YSB8fCAnJztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0Q29uZmlnRGF0YShrZXk6c3RyaW5nLHZhbHVlOnN0cmluZyl7XHJcbiAgICAgICAgdGhpcy5qc29uRGF0YVtrZXldPXZhbHVlO1xyXG4gICAgICAgIHRoaXMubWFya1NhdmU9dHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIHNjaGVkdWxlU2F2ZSgpe1xyXG4gICAgICAgIGlmKCF0aGlzLm1hcmtTYXZlKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBkYXRhID0gSlNPTi5zdHJpbmdpZnkodGhpcy5qc29uRGF0YSk7XHJcbiAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKENvbnN0YW50cy5HYW1lQ29uZmlnSUQsZGF0YSk7XHJcbiAgICAgICAgdGhpcy5tYXJrU2F2ZSA9IGZhbHNlO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==