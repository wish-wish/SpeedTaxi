System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, _dec, _class, _class2, _temp, _crd, ccclass, property, EventName, AudioFiles, CarGroup, CustomerState, Constants;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  _export({
    _dec: void 0,
    _class: void 0,
    _class2: void 0,
    _temp: void 0,
    EventName: void 0,
    AudioFiles: void 0,
    CarGroup: void 0,
    CustomerState: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "5ea42oHCmNPYLLhN6hj6+Li", "Constants", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      (function (EventName) {
        EventName["GREETING"] = "greeting";
        EventName["GOODBYE"] = "goodbyte";
        EventName["FINISHEDWALK"] = "finishedwalk";
        EventName["STARTBREAKING"] = "startbreaking";
        EventName["ENDBREAKING"] = "endbreaking";
        EventName["SHOWCOIN"] = "showcoin";
        EventName["GAMESTART"] = "gamestart";
        EventName["GAMEOVER"] = "gameover";
        EventName["NEWLEVEL"] = "newlevel";
        EventName["SHOWTALK"] = "showtalk";
        EventName["SHOWGUIDE"] = "showguide";
        EventName["UPDATEPROGRESS"] = "updateprogress";
      })(EventName || (EventName = {}));

      (function (AudioFiles) {
        AudioFiles["BG"] = "background";
        AudioFiles["ClICK"] = "click";
        AudioFiles["CRASH"] = "crash";
        AudioFiles["GETMONEY"] = "getMoney";
        AudioFiles["INCAR"] = "inCar";
        AudioFiles["NEWORDER"] = "newOrder";
        AudioFiles["START"] = "start";
        AudioFiles["STOP"] = "stop";
        AudioFiles["TOOTING1"] = "tooting1";
        AudioFiles["TOOTING2"] = "tooting2";
        AudioFiles["WIN"] = "win";
      })(AudioFiles || (AudioFiles = {}));

      (function (CarGroup) {
        CarGroup[CarGroup["NORMAL"] = 1] = "NORMAL";
        CarGroup[CarGroup["MAINCAR"] = 2] = "MAINCAR";
        CarGroup[CarGroup["OTHERCAR"] = 4] = "OTHERCAR";
      })(CarGroup || (CarGroup = {}));

      (function (CustomerState) {
        CustomerState[CustomerState["NONE"] = 0] = "NONE";
        CustomerState[CustomerState["GREETING"] = 1] = "GREETING";
        CustomerState[CustomerState["GOODBYE"] = 2] = "GOODBYE";
      })(CustomerState || (CustomerState = {}));

      _export("Constants", Constants = (_dec = ccclass('Constants'), _dec(_class = (_temp = _class2 = /*#__PURE__*/function (_Component) {
        _inherits(Constants, _Component);

        function Constants() {
          _classCallCheck(this, Constants);

          return _possibleConstructorReturn(this, _getPrototypeOf(Constants).apply(this, arguments));
        }

        _createClass(Constants, [{
          key: "start",
          value: function start() {} // Your initialization goes here.
          // update (deltaTime: number) {
          //     // Your update function goes here.
          // }

        }]);

        return Constants;
      }(Component), _class2.EventName = EventName, _class2.CustomerState = CustomerState, _class2.AudioFiles = AudioFiles, _class2.CarGroup = CarGroup, _class2.talkTable = ["Please hurry up.\n I have a plane to catch", "The most beautiful day \n is not the rainy day"], _class2.UIPage = {
        mainUI: 'mainUI',
        gameUI: 'gameUI',
        resultUI: 'resultUI'
      }, _class2.GameConfigID = 'SpeedTaxi_CACHE', _class2.PlayerConfigID = 'playerInfo', _class2.MaxLevel = 2, _temp)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ3JlYXRvci9TcGVlZFRheGkvYXNzZXRzL3NjcmlwdC9kYXRhL0NvbnN0YW50cy50cyJdLCJuYW1lcyI6WyJfZGVjb3JhdG9yIiwiQ29tcG9uZW50IiwiY2NjbGFzcyIsInByb3BlcnR5IiwiRXZlbnROYW1lIiwiQXVkaW9GaWxlcyIsIkNhckdyb3VwIiwiQ3VzdG9tZXJTdGF0ZSIsIkNvbnN0YW50cyIsInRhbGtUYWJsZSIsIlVJUGFnZSIsIm1haW5VSSIsImdhbWVVSSIsInJlc3VsdFVJIiwiR2FtZUNvbmZpZ0lEIiwiUGxheWVyQ29uZmlnSUQiLCJNYXhMZXZlbCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFTQSxNQUFBQSxVLE9BQUFBLFU7QUFBWUMsTUFBQUEsUyxPQUFBQSxTOzs7Ozs7QUFDYkMsTUFBQUEsTyxHQUFzQkYsVSxDQUF0QkUsTztBQUFTQyxNQUFBQSxRLEdBQWFILFUsQ0FBYkcsUTs7aUJBRVpDLFM7QUFBQUEsUUFBQUEsUztBQUFBQSxRQUFBQSxTO0FBQUFBLFFBQUFBLFM7QUFBQUEsUUFBQUEsUztBQUFBQSxRQUFBQSxTO0FBQUFBLFFBQUFBLFM7QUFBQUEsUUFBQUEsUztBQUFBQSxRQUFBQSxTO0FBQUFBLFFBQUFBLFM7QUFBQUEsUUFBQUEsUztBQUFBQSxRQUFBQSxTO0FBQUFBLFFBQUFBLFM7U0FBQUEsUyxLQUFBQSxTOztpQkFlQUMsVTtBQUFBQSxRQUFBQSxVO0FBQUFBLFFBQUFBLFU7QUFBQUEsUUFBQUEsVTtBQUFBQSxRQUFBQSxVO0FBQUFBLFFBQUFBLFU7QUFBQUEsUUFBQUEsVTtBQUFBQSxRQUFBQSxVO0FBQUFBLFFBQUFBLFU7QUFBQUEsUUFBQUEsVTtBQUFBQSxRQUFBQSxVO0FBQUFBLFFBQUFBLFU7U0FBQUEsVSxLQUFBQSxVOztpQkFjQUMsUTtBQUFBQSxRQUFBQSxRLENBQUFBLFE7QUFBQUEsUUFBQUEsUSxDQUFBQSxRO0FBQUFBLFFBQUFBLFEsQ0FBQUEsUTtTQUFBQSxRLEtBQUFBLFE7O2lCQU1BQyxhO0FBQUFBLFFBQUFBLGEsQ0FBQUEsYTtBQUFBQSxRQUFBQSxhLENBQUFBLGE7QUFBQUEsUUFBQUEsYSxDQUFBQSxhO1NBQUFBLGEsS0FBQUEsYTs7MkJBT1FDLFMsV0FEWk4sT0FBTyxDQUFDLFdBQUQsQzs7Ozs7Ozs7Ozs7a0NBcUJLLENBRVIsQyxDQURHO0FBR0o7QUFDQTtBQUNBOzs7OztRQTFCMkJELFMsV0FDYkcsUyxHQUFZQSxTLFVBQ1pHLGEsR0FBY0EsYSxVQUNkRixVLEdBQVdBLFUsVUFDWEMsUSxHQUFTQSxRLFVBQ1RHLFMsR0FBWSxDQUN0Qiw0Q0FEc0IsRUFFdEIsZ0RBRnNCLEMsVUFLWkMsTSxHQUFPO0FBQ2pCQyxRQUFBQSxNQUFNLEVBQUMsUUFEVTtBQUVqQkMsUUFBQUEsTUFBTSxFQUFDLFFBRlU7QUFHakJDLFFBQUFBLFFBQVEsRUFBQztBQUhRLE8sVUFNUEMsWSxHQUFlLGlCLFVBQ2ZDLGMsR0FBaUIsWSxVQUNqQkMsUSxHQUFXLEMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBfZGVjb3JhdG9yLCBDb21wb25lbnQsIE5vZGUgfSBmcm9tICdjYyc7XHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IF9kZWNvcmF0b3I7XHJcblxyXG5lbnVtIEV2ZW50TmFtZXtcclxuICAgIEdSRUVUSU5HID0gJ2dyZWV0aW5nJyxcclxuICAgIEdPT0RCWUUgPSAnZ29vZGJ5dGUnLFxyXG4gICAgRklOSVNIRURXQUxLID0gJ2ZpbmlzaGVkd2FsaycsXHJcbiAgICBTVEFSVEJSRUFLSU5HID0gJ3N0YXJ0YnJlYWtpbmcnLFxyXG4gICAgRU5EQlJFQUtJTkcgPSAnZW5kYnJlYWtpbmcnLFxyXG4gICAgU0hPV0NPSU4gPSAnc2hvd2NvaW4nLFxyXG4gICAgR0FNRVNUQVJUID0gJ2dhbWVzdGFydCcsXHJcbiAgICBHQU1FT1ZFUiA9ICdnYW1lb3ZlcicsXHJcbiAgICBORVdMRVZFTCA9ICduZXdsZXZlbCcsXHJcbiAgICBTSE9XVEFMSyA9ICdzaG93dGFsaycsXHJcbiAgICBTSE9XR1VJREUgPSAnc2hvd2d1aWRlJyxcclxuICAgIFVQREFURVBST0dSRVNTID0gJ3VwZGF0ZXByb2dyZXNzJyxcclxufVxyXG5cclxuZW51bSBBdWRpb0ZpbGVze1xyXG4gICAgQkc9XCJiYWNrZ3JvdW5kXCIsXHJcbiAgICBDbElDSz0nY2xpY2snLFxyXG4gICAgQ1JBU0g9J2NyYXNoJyxcclxuICAgIEdFVE1PTkVZPSdnZXRNb25leScsXHJcbiAgICBJTkNBUj0naW5DYXInLFxyXG4gICAgTkVXT1JERVIgPSduZXdPcmRlcicsXHJcbiAgICBTVEFSVD0nc3RhcnQnLFxyXG4gICAgU1RPUD0nc3RvcCcsXHJcbiAgICBUT09USU5HMT0ndG9vdGluZzEnLFxyXG4gICAgVE9PVElORzI9J3Rvb3RpbmcyJyxcclxuICAgIFdJTj0nd2luJyxcclxufVxyXG5cclxuZW51bSBDYXJHcm91cHtcclxuICAgIE5PUk1BTCA9IDE8PDAsXHJcbiAgICBNQUlOQ0FSID0gMTw8MSxcclxuICAgIE9USEVSQ0FSID0gMTw8MixcclxufVxyXG5cclxuZW51bSBDdXN0b21lclN0YXRle1xyXG4gICAgTk9ORSxcclxuICAgIEdSRUVUSU5HLFxyXG4gICAgR09PREJZRSxcclxufVxyXG5cclxuQGNjY2xhc3MoJ0NvbnN0YW50cycpXHJcbmV4cG9ydCBjbGFzcyBDb25zdGFudHMgZXh0ZW5kcyBDb21wb25lbnQge1xyXG4gICAgcHVibGljIHN0YXRpYyBFdmVudE5hbWUgPSBFdmVudE5hbWU7XHJcbiAgICBwdWJsaWMgc3RhdGljIEN1c3RvbWVyU3RhdGU9Q3VzdG9tZXJTdGF0ZTtcclxuICAgIHB1YmxpYyBzdGF0aWMgQXVkaW9GaWxlcz1BdWRpb0ZpbGVzO1xyXG4gICAgcHVibGljIHN0YXRpYyBDYXJHcm91cD1DYXJHcm91cDtcclxuICAgIHB1YmxpYyBzdGF0aWMgdGFsa1RhYmxlID0gW1xyXG4gICAgICAgIFwiUGxlYXNlIGh1cnJ5IHVwLlxcbiBJIGhhdmUgYSBwbGFuZSB0byBjYXRjaFwiLFxyXG4gICAgICAgIFwiVGhlIG1vc3QgYmVhdXRpZnVsIGRheSBcXG4gaXMgbm90IHRoZSByYWlueSBkYXlcIixcclxuICAgIF1cclxuXHJcbiAgICBwdWJsaWMgc3RhdGljIFVJUGFnZT17XHJcbiAgICAgICAgbWFpblVJOidtYWluVUknLFxyXG4gICAgICAgIGdhbWVVSTonZ2FtZVVJJyxcclxuICAgICAgICByZXN1bHRVSToncmVzdWx0VUknLFxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzdGF0aWMgR2FtZUNvbmZpZ0lEID0gJ1NwZWVkVGF4aV9DQUNIRSc7XHJcbiAgICBwdWJsaWMgc3RhdGljIFBsYXllckNvbmZpZ0lEID0gJ3BsYXllckluZm8nO1xyXG4gICAgcHVibGljIHN0YXRpYyBNYXhMZXZlbCA9IDI7XHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIC8vIFlvdXIgaW5pdGlhbGl6YXRpb24gZ29lcyBoZXJlLlxyXG4gICAgfVxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZGVsdGFUaW1lOiBudW1iZXIpIHtcclxuICAgIC8vICAgICAvLyBZb3VyIHVwZGF0ZSBmdW5jdGlvbiBnb2VzIGhlcmUuXHJcbiAgICAvLyB9XHJcbn1cclxuIl19