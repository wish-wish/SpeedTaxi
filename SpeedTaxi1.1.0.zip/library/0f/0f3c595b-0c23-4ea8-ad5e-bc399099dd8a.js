System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, LabelComponent, _dec, _class, _temp, _crd, ccclass, property, UpdateLabelValue;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  _export({
    _dec: void 0,
    _class: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      LabelComponent = _cc.LabelComponent;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "0f3c5lbDCNOqK1evDmQmd2K", "UpdateLabelValue", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("UpdateLabelValue", UpdateLabelValue = (_dec = ccclass('UpdateLabelValue'), _dec(_class = (_temp = /*#__PURE__*/function (_LabelComponent) {
        _inherits(UpdateLabelValue, _LabelComponent);

        function UpdateLabelValue() {
          var _getPrototypeOf2;

          var _this;

          _classCallCheck(this, UpdateLabelValue);

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(UpdateLabelValue)).call.apply(_getPrototypeOf2, [this].concat(args)));
          _this.startVal = 0;
          _this.endVal = 0;
          _this.diffVal = 0;
          _this.currTime = 0;
          _this.changeTime = 0;
          _this.isPlaying = false;
          return _this;
        }

        _createClass(UpdateLabelValue, [{
          key: "playUpdateValue",
          value: function playUpdateValue(start, end, changeTime) {
            this.startVal = start;
            this.endVal = end;
            this.diffVal = this.endVal - this.startVal;
            this.currTime = 0;
            this.changeTime = changeTime;

            if (changeTime === 0) {
              this.string = "".concat(this.endVal);
              return;
            }

            this.string = "".concat(this.startVal);
            this.isPlaying = true;
          }
        }, {
          key: "update",
          value: function update(dt) {
            if (!this.isPlaying) {
              return;
            }

            if (this.currTime < this.changeTime) {
              this.currTime += dt;
              var targetVal = this.startVal + Math.floor(this.currTime / this.changeTime * this.diffVal);
              this.string = "".concat(targetVal);
              return;
            }

            this.string = "".concat(this.endVal);
            this.isPlaying = false;
          }
        }]);

        return UpdateLabelValue;
      }(LabelComponent), _temp)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ3JlYXRvci9TcGVlZFRheGkvYXNzZXRzL3NjcmlwdC9kYXRhL1VwZGF0ZUxhYmVsVmFsdWUudHMiXSwibmFtZXMiOlsiX2RlY29yYXRvciIsIkxhYmVsQ29tcG9uZW50IiwiY2NjbGFzcyIsInByb3BlcnR5IiwiVXBkYXRlTGFiZWxWYWx1ZSIsInN0YXJ0VmFsIiwiZW5kVmFsIiwiZGlmZlZhbCIsImN1cnJUaW1lIiwiY2hhbmdlVGltZSIsImlzUGxheWluZyIsInN0YXJ0IiwiZW5kIiwic3RyaW5nIiwiZHQiLCJ0YXJnZXRWYWwiLCJNYXRoIiwiZmxvb3IiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQVNBLE1BQUFBLFUsT0FBQUEsVTtBQUE2QkMsTUFBQUEsYyxPQUFBQSxjOzs7Ozs7QUFDOUJDLE1BQUFBLE8sR0FBc0JGLFUsQ0FBdEJFLE87QUFBU0MsTUFBQUEsUSxHQUFhSCxVLENBQWJHLFE7O2tDQUdKQyxnQixXQURaRixPQUFPLENBQUMsa0JBQUQsQzs7Ozs7Ozs7Ozs7Ozs7O2dCQUdJRyxRLEdBQVcsQztnQkFDWEMsTSxHQUFTLEM7Z0JBQ1RDLE8sR0FBVSxDO2dCQUNWQyxRLEdBQVMsQztnQkFDVEMsVSxHQUFXLEM7Z0JBQ1hDLFMsR0FBWSxLOzs7Ozs7MENBRUdDLEssRUFBYUMsRyxFQUFXSCxVLEVBQWtCO0FBQzdELGlCQUFLSixRQUFMLEdBQWdCTSxLQUFoQjtBQUNBLGlCQUFLTCxNQUFMLEdBQWNNLEdBQWQ7QUFDQSxpQkFBS0wsT0FBTCxHQUFlLEtBQUtELE1BQUwsR0FBWSxLQUFLRCxRQUFoQztBQUNBLGlCQUFLRyxRQUFMLEdBQWdCLENBQWhCO0FBQ0EsaUJBQUtDLFVBQUwsR0FBa0JBLFVBQWxCOztBQUNBLGdCQUFHQSxVQUFVLEtBQUcsQ0FBaEIsRUFBa0I7QUFDZCxtQkFBS0ksTUFBTCxhQUFlLEtBQUtQLE1BQXBCO0FBQ0E7QUFDSDs7QUFDRCxpQkFBS08sTUFBTCxhQUFlLEtBQUtSLFFBQXBCO0FBQ0EsaUJBQUtLLFNBQUwsR0FBaUIsSUFBakI7QUFDSDs7O2lDQUVhSSxFLEVBQVU7QUFDcEIsZ0JBQUcsQ0FBQyxLQUFLSixTQUFULEVBQ0E7QUFDSTtBQUNIOztBQUNELGdCQUFHLEtBQUtGLFFBQUwsR0FBYyxLQUFLQyxVQUF0QixFQUFpQztBQUM3QixtQkFBS0QsUUFBTCxJQUFlTSxFQUFmO0FBQ0Esa0JBQU1DLFNBQVMsR0FBQyxLQUFLVixRQUFMLEdBQWNXLElBQUksQ0FBQ0MsS0FBTCxDQUFZLEtBQUtULFFBQUwsR0FBYyxLQUFLQyxVQUFwQixHQUFnQyxLQUFLRixPQUFoRCxDQUE5QjtBQUNBLG1CQUFLTSxNQUFMLGFBQWVFLFNBQWY7QUFDQTtBQUNIOztBQUNELGlCQUFLRixNQUFMLGFBQWlCLEtBQUtQLE1BQXRCO0FBQ0EsaUJBQUtJLFNBQUwsR0FBaUIsS0FBakI7QUFDSDs7OztRQXBDaUNULGMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBfZGVjb3JhdG9yLCBDb21wb25lbnQsIE5vZGUsIExhYmVsQ29tcG9uZW50IH0gZnJvbSAnY2MnO1xyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBfZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3MoJ1VwZGF0ZUxhYmVsVmFsdWUnKVxyXG5leHBvcnQgY2xhc3MgVXBkYXRlTGFiZWxWYWx1ZSBleHRlbmRzIExhYmVsQ29tcG9uZW50IHtcclxuXHJcbiAgICBwcml2YXRlIHN0YXJ0VmFsID0gMDtcclxuICAgIHByaXZhdGUgZW5kVmFsID0gMDtcclxuICAgIHByaXZhdGUgZGlmZlZhbCA9IDA7XHJcbiAgICBwcml2YXRlIGN1cnJUaW1lPTA7XHJcbiAgICBwcml2YXRlIGNoYW5nZVRpbWU9MDtcclxuICAgIHByaXZhdGUgaXNQbGF5aW5nID0gZmFsc2U7XHJcblxyXG4gICAgcHVibGljIHBsYXlVcGRhdGVWYWx1ZShzdGFydDpudW1iZXIsZW5kOm51bWJlcixjaGFuZ2VUaW1lOm51bWJlcil7XHJcbiAgICAgICAgdGhpcy5zdGFydFZhbCA9IHN0YXJ0O1xyXG4gICAgICAgIHRoaXMuZW5kVmFsID0gZW5kO1xyXG4gICAgICAgIHRoaXMuZGlmZlZhbCA9IHRoaXMuZW5kVmFsLXRoaXMuc3RhcnRWYWw7XHJcbiAgICAgICAgdGhpcy5jdXJyVGltZSA9IDA7XHJcbiAgICAgICAgdGhpcy5jaGFuZ2VUaW1lID0gY2hhbmdlVGltZTtcclxuICAgICAgICBpZihjaGFuZ2VUaW1lPT09MCl7XHJcbiAgICAgICAgICAgIHRoaXMuc3RyaW5nPWAke3RoaXMuZW5kVmFsfWA7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5zdHJpbmc9YCR7dGhpcy5zdGFydFZhbH1gO1xyXG4gICAgICAgIHRoaXMuaXNQbGF5aW5nID0gdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgdXBkYXRlKGR0Om51bWJlcil7XHJcbiAgICAgICAgaWYoIXRoaXMuaXNQbGF5aW5nKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZih0aGlzLmN1cnJUaW1lPHRoaXMuY2hhbmdlVGltZSl7XHJcbiAgICAgICAgICAgIHRoaXMuY3VyclRpbWUrPWR0O1xyXG4gICAgICAgICAgICBjb25zdCB0YXJnZXRWYWw9dGhpcy5zdGFydFZhbCtNYXRoLmZsb29yKCh0aGlzLmN1cnJUaW1lL3RoaXMuY2hhbmdlVGltZSkqdGhpcy5kaWZmVmFsKTtcclxuICAgICAgICAgICAgdGhpcy5zdHJpbmc9YCR7dGFyZ2V0VmFsfWA7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5zdHJpbmcgPSBgJHt0aGlzLmVuZFZhbH1gO1xyXG4gICAgICAgIHRoaXMuaXNQbGF5aW5nID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==