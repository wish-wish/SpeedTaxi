System.register(["cc", "code-quality:cr", "../data/CustomEventListener.js", "../data/Constants.js", "../data/UpdateLabelValue.js"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Component, CustomEventListener, Constants, UpdateLabelValue, _dec, _dec2, _class, _class2, _descriptor, _temp, _crd, ccclass, property, LoadingUI;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfCustomEventListener(extras) {
    _reporterNs.report("CustomEventListener", "../data/CustomEventListener", _context.meta, extras);
  }

  function _reportPossibleCrUseOfConstants(extras) {
    _reporterNs.report("Constants", "../data/Constants", _context.meta, extras);
  }

  function _reportPossibleCrUseOfUpdateLabelValue(extras) {
    _reporterNs.report("UpdateLabelValue", "../data/UpdateLabelValue", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _dec2: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_dataCustomEventListenerJs) {
      CustomEventListener = _dataCustomEventListenerJs.CustomEventListener;
    }, function (_dataConstantsJs) {
      Constants = _dataConstantsJs.Constants;
    }, function (_dataUpdateLabelValueJs) {
      UpdateLabelValue = _dataUpdateLabelValueJs.UpdateLabelValue;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "36ed8aX/1dBfpEiS61V49/P", "LoadingUI", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("LoadingUI", LoadingUI = (_dec = ccclass('LoadingUI'), _dec2 = property({
        type: _crd && UpdateLabelValue === void 0 ? (_reportPossibleCrUseOfUpdateLabelValue({
          error: Error()
        }), UpdateLabelValue) : UpdateLabelValue
      }), _dec(_class = (_class2 = (_temp = /*#__PURE__*/function (_Component) {
        _inherits(LoadingUI, _Component);

        function LoadingUI() {
          var _getPrototypeOf2;

          var _this;

          _classCallCheck(this, LoadingUI);

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(LoadingUI)).call.apply(_getPrototypeOf2, [this].concat(args)));

          _initializerDefineProperty(_this, "progressLabel", _descriptor, _assertThisInitialized(_this));

          _this.progress = 0;
          return _this;
        }

        _createClass(LoadingUI, [{
          key: "onEnable",
          value: function onEnable() {
            (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
              error: Error()
            }), CustomEventListener) : CustomEventListener).on((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).EventName.UPDATEPROGRESS, this.updateProgress, this);
          }
        }, {
          key: "onDisable",
          value: function onDisable() {
            (_crd && CustomEventListener === void 0 ? (_reportPossibleCrUseOfCustomEventListener({
              error: Error()
            }), CustomEventListener) : CustomEventListener).off((_crd && Constants === void 0 ? (_reportPossibleCrUseOfConstants({
              error: Error()
            }), Constants) : Constants).EventName.UPDATEPROGRESS, this.updateProgress, this);
          }
        }, {
          key: "show",
          value: function show() {
            this.node.active = true;
            this.progress = 50; //this.progressLabel.string=`${this.progress}`

            this.progressLabel.playUpdateValue(this.progress, this.progress, 0);
          }
        }, {
          key: "hide",
          value: function hide() {
            this.node.active = false;
          }
        }, {
          key: "start",
          value: function start() {// Your initialization goes here.
          }
        }, {
          key: "update",
          value: function update(deltaTime) {// Your update function goes here.
          }
        }, {
          key: "updateProgress",
          value: function updateProgress(value) {
            //this.progressLabel.string=`${this.progress}`
            this.progressLabel.playUpdateValue(this.progress, this.progress + value, 0.2);
            this.progress += value;
          }
        }, {
          key: "finishLoading",
          value: function finishLoading() {
            this.progressLabel.playUpdateValue(this.progress, 100, 0.2);
            this.progress = 100; //this.progressLabel.string=`${this.progress}`

            this.scheduleOnce(this.close, 0.3);
          }
        }, {
          key: "close",
          value: function close() {
            this.node.active = false;
          }
        }]);

        return LoadingUI;
      }(Component), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "progressLabel", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ3JlYXRvci9TcGVlZFRheGkvYXNzZXRzL3NjcmlwdC91aS9Mb2FkaW5nVUkudHMiXSwibmFtZXMiOlsiX2RlY29yYXRvciIsIkNvbXBvbmVudCIsIkN1c3RvbUV2ZW50TGlzdGVuZXIiLCJDb25zdGFudHMiLCJVcGRhdGVMYWJlbFZhbHVlIiwiY2NjbGFzcyIsInByb3BlcnR5IiwiTG9hZGluZ1VJIiwidHlwZSIsInByb2dyZXNzIiwib24iLCJFdmVudE5hbWUiLCJVUERBVEVQUk9HUkVTUyIsInVwZGF0ZVByb2dyZXNzIiwib2ZmIiwibm9kZSIsImFjdGl2ZSIsInByb2dyZXNzTGFiZWwiLCJwbGF5VXBkYXRlVmFsdWUiLCJkZWx0YVRpbWUiLCJ2YWx1ZSIsInNjaGVkdWxlT25jZSIsImNsb3NlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFTQSxNQUFBQSxVLE9BQUFBLFU7QUFBWUMsTUFBQUEsUyxPQUFBQSxTOzs7O0FBQ1pDLE1BQUFBLG1CLDhCQUFBQSxtQjs7QUFDQUMsTUFBQUEsUyxvQkFBQUEsUzs7QUFDQUMsTUFBQUEsZ0IsMkJBQUFBLGdCOzs7Ozs7QUFDREMsTUFBQUEsTyxHQUFzQkwsVSxDQUF0QkssTztBQUFTQyxNQUFBQSxRLEdBQWFOLFUsQ0FBYk0sUTs7MkJBR0pDLFMsV0FEWkYsT0FBTyxDQUFDLFdBQUQsQyxVQUVIQyxRQUFRLENBQUM7QUFDTkUsUUFBQUEsSUFBSTtBQUFBO0FBQUE7QUFERSxPQUFELEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztnQkFNREMsUSxHQUFTLEM7Ozs7OztxQ0FFQTtBQUNiO0FBQUE7QUFBQSw0REFBb0JDLEVBQXBCLENBQXVCO0FBQUE7QUFBQSx3Q0FBVUMsU0FBVixDQUFvQkMsY0FBM0MsRUFBMEQsS0FBS0MsY0FBL0QsRUFBOEUsSUFBOUU7QUFDSDs7O3NDQUVpQjtBQUNkO0FBQUE7QUFBQSw0REFBb0JDLEdBQXBCLENBQXdCO0FBQUE7QUFBQSx3Q0FBVUgsU0FBVixDQUFvQkMsY0FBNUMsRUFBMkQsS0FBS0MsY0FBaEUsRUFBK0UsSUFBL0U7QUFDSDs7O2lDQUVZO0FBQ1QsaUJBQUtFLElBQUwsQ0FBVUMsTUFBVixHQUFtQixJQUFuQjtBQUNBLGlCQUFLUCxRQUFMLEdBQWdCLEVBQWhCLENBRlMsQ0FHVDs7QUFDQSxpQkFBS1EsYUFBTCxDQUFtQkMsZUFBbkIsQ0FBbUMsS0FBS1QsUUFBeEMsRUFBaUQsS0FBS0EsUUFBdEQsRUFBK0QsQ0FBL0Q7QUFDSDs7O2lDQUVZO0FBQ1QsaUJBQUtNLElBQUwsQ0FBVUMsTUFBVixHQUFtQixLQUFuQjtBQUNIOzs7a0NBRVEsQ0FDTDtBQUNIOzs7aUNBRU9HLFMsRUFBbUIsQ0FDdkI7QUFDSDs7O3lDQUVxQkMsSyxFQUFhO0FBQy9CO0FBQ0EsaUJBQUtILGFBQUwsQ0FBbUJDLGVBQW5CLENBQW1DLEtBQUtULFFBQXhDLEVBQWlELEtBQUtBLFFBQUwsR0FBY1csS0FBL0QsRUFBcUUsR0FBckU7QUFDQSxpQkFBS1gsUUFBTCxJQUFlVyxLQUFmO0FBQ0g7OzswQ0FFcUI7QUFDbEIsaUJBQUtILGFBQUwsQ0FBbUJDLGVBQW5CLENBQW1DLEtBQUtULFFBQXhDLEVBQWlELEdBQWpELEVBQXFELEdBQXJEO0FBQ0EsaUJBQUtBLFFBQUwsR0FBZ0IsR0FBaEIsQ0FGa0IsQ0FHbEI7O0FBQ0EsaUJBQUtZLFlBQUwsQ0FBa0IsS0FBS0MsS0FBdkIsRUFBNkIsR0FBN0I7QUFDSDs7O2tDQUVhO0FBQ1YsaUJBQUtQLElBQUwsQ0FBVUMsTUFBVixHQUFtQixLQUFuQjtBQUNIOzs7O1FBbkQwQmYsUzs7Ozs7aUJBSU0sSSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IF9kZWNvcmF0b3IsIENvbXBvbmVudCwgTm9kZSwgfSBmcm9tICdjYyc7XHJcbmltcG9ydCB7IEN1c3RvbUV2ZW50TGlzdGVuZXIgfSBmcm9tICcuLi9kYXRhL0N1c3RvbUV2ZW50TGlzdGVuZXInO1xyXG5pbXBvcnQgeyBDb25zdGFudHMgfSBmcm9tICcuLi9kYXRhL0NvbnN0YW50cyc7XHJcbmltcG9ydCB7IFVwZGF0ZUxhYmVsVmFsdWUgfSBmcm9tICcuLi9kYXRhL1VwZGF0ZUxhYmVsVmFsdWUnO1xyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBfZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3MoJ0xvYWRpbmdVSScpXHJcbmV4cG9ydCBjbGFzcyBMb2FkaW5nVUkgZXh0ZW5kcyBDb21wb25lbnQge1xyXG4gICAgQHByb3BlcnR5KHtcclxuICAgICAgICB0eXBlOlVwZGF0ZUxhYmVsVmFsdWVcclxuICAgIH0pXHJcbiAgICBwcm9ncmVzc0xhYmVsOlVwZGF0ZUxhYmVsVmFsdWUgPSBudWxsO1xyXG5cclxuXHJcbiAgICBwcml2YXRlIHByb2dyZXNzPTA7XHJcblxyXG4gICAgcHVibGljIG9uRW5hYmxlKCl7XHJcbiAgICAgICAgQ3VzdG9tRXZlbnRMaXN0ZW5lci5vbihDb25zdGFudHMuRXZlbnROYW1lLlVQREFURVBST0dSRVNTLHRoaXMudXBkYXRlUHJvZ3Jlc3MsdGhpcyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uRGlzYWJsZSgpe1xyXG4gICAgICAgIEN1c3RvbUV2ZW50TGlzdGVuZXIub2ZmKENvbnN0YW50cy5FdmVudE5hbWUuVVBEQVRFUFJPR1JFU1MsdGhpcy51cGRhdGVQcm9ncmVzcyx0aGlzKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2hvdygpe1xyXG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMucHJvZ3Jlc3MgPSA1MDtcclxuICAgICAgICAvL3RoaXMucHJvZ3Jlc3NMYWJlbC5zdHJpbmc9YCR7dGhpcy5wcm9ncmVzc31gXHJcbiAgICAgICAgdGhpcy5wcm9ncmVzc0xhYmVsLnBsYXlVcGRhdGVWYWx1ZSh0aGlzLnByb2dyZXNzLHRoaXMucHJvZ3Jlc3MsMCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGhpZGUoKXtcclxuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIC8vIFlvdXIgaW5pdGlhbGl6YXRpb24gZ29lcyBoZXJlLlxyXG4gICAgfVxyXG5cclxuICAgIHVwZGF0ZSAoZGVsdGFUaW1lOiBudW1iZXIpIHtcclxuICAgICAgICAvLyBZb3VyIHVwZGF0ZSBmdW5jdGlvbiBnb2VzIGhlcmUuXHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHVwZGF0ZVByb2dyZXNzKHZhbHVlOm51bWJlcil7XHJcbiAgICAgICAgLy90aGlzLnByb2dyZXNzTGFiZWwuc3RyaW5nPWAke3RoaXMucHJvZ3Jlc3N9YFxyXG4gICAgICAgIHRoaXMucHJvZ3Jlc3NMYWJlbC5wbGF5VXBkYXRlVmFsdWUodGhpcy5wcm9ncmVzcyx0aGlzLnByb2dyZXNzK3ZhbHVlLDAuMik7XHJcbiAgICAgICAgdGhpcy5wcm9ncmVzcys9dmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGZpbmlzaExvYWRpbmcoKXtcclxuICAgICAgICB0aGlzLnByb2dyZXNzTGFiZWwucGxheVVwZGF0ZVZhbHVlKHRoaXMucHJvZ3Jlc3MsMTAwLDAuMik7XHJcbiAgICAgICAgdGhpcy5wcm9ncmVzcyA9IDEwMDtcclxuICAgICAgICAvL3RoaXMucHJvZ3Jlc3NMYWJlbC5zdHJpbmc9YCR7dGhpcy5wcm9ncmVzc31gXHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UodGhpcy5jbG9zZSwwLjMpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBjbG9zZSgpe1xyXG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgIH1cclxufVxyXG4iXX0=